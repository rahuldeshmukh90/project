<?php 

/**
* 
*/
class Users extends CI_Model
{
	
	protected $table_name;
	
	function __construct()
	{
		parent::__construct();
		$this->table_name = "customers";
	}

	function save($data){
     
     $query = $this->db->insert('customers',$data);

     return $id;

	}

	function login($username, $password)
	{

	    $query = $this->db->get_where($this->table_name,array('email'=>$username,'password'=>$password ),1);
		if ($query->num_rows()==1){
			$row = $query->row();
			$this->session->set_userdata('id',$row->id);
			return true;
		}
		return false;
	}

	function is_logged_in()
	{
		
		return $this->session->userdata('id')!=false;
	}

    function get_logged_in_user_info()
	{
		if ($this->is_logged_in()) {
			return $this->get_info($this->session->userdata('id'));
		}
		return false;
	}

	function get_info($user_id)
	{

		$query = $this->db->get_where($this->table_name,array('id'=>$user_id));
		
		if ($query->num_rows()==1) {
			return $query->row();
		} else {
			return $this->get_empty_object($this->table_name);
		}
	}

	function save_customer($data=null){

        $query = $this->db->insert($this->table_name ,$data);    
        if($query){
         $id=$this->db->insert_id();
    	 $this->session->set_userdata('id',$id);
         return true; 
		     }else{
		      return false; 
		  }
    }

	function logout()
	{
		$this->session->sess_destroy();
		redirect('login');
	}

	function check_email_info($emial=null)
	{
        $query = $this->db->get_where($this->table_name,array('email'=>$emial));
		
		if($query->num_rows()>0){
			$row = $query->row();
			$this->session->set_userdata('emailid',$row->id);
			$this->session->set_userdata('addemail',$row->email);
			$this->session->set_userdata('emailname',$row->name);
			return true;
		}else{
			return false;
		}
	}

	function updateCustomerInfo($data=null,$id=''){
        
       $where_condition = array('id' => $id );
       $this->db->where($where_condition);
       if($this->db->update($this->table_name, $data)){ return true; }else{ return false; }
       
	}
}
<?php 
class Cart_model extends CI_Model
{
	protected $bucket_table_name;
	protected $order_table_name;
	protected $whishlist_table_name;
	protected $products_table_name;
	function __construct()
	{
		parent::__construct();
		$this->bucket_table_name = 'ec_buckets';
		$this->order_table_name = 'ec_order';
		$this->whishlist_table_name = 'ec_wishlists';
		$this->products_table_name = 'ec_products';
		
	}

	function update_cart($rowid, $qty, $price, $amount) {
 		
 		$data = array(
			            'rowid'   => $rowid,
			            'qty'     => $qty,
			            'price'   => $price,
			            'amount'  => $amount
		            );
        $this->cart->update($data);
	}

	function get_all_order($user_id ,$limit=false, $offset=false)
	{
		
        $this->db->select('a.*');
        $this->db->from('orders as a');
        $this->db->where('CustomerId', $user_id );
        $this->db->order_by('a.id', 'desc');
        $order =  $this->db->get()->result();
        $array = array();$i=0;
        foreach($order as $val){
       
        $array[$i]['user_id']  = $val->CustomerId;
        $array[$i]['order_id'] = $val->id;
        $array[$i]['order_no'] = $val->Bill_Number;
        
        $this->db->select('b.*,c.*');
        $this->db->from('order_detail as b');
        $this->db->join('products as c',"b.itemId=c.id");
        $this->db->where('b.orderId', $val->id);
        $array[$i]['items']= $this->db->get();
        $i++;
        }
        return $array;
	}
}	
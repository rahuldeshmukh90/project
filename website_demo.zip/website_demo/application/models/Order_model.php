<?php 

/**
* 
*/
class Order_model extends CI_Model
{
	
	protected $table_name;
	protected $order_table_name;
	
	function __construct()
	{
		parent::__construct();
		$this->table_name = "orders";
		$this->order_table_name = "order_detail";
	}

	function save($data){
     
          $query = $this->db->insert($this->table_name,$data);
          return $id = $query['id'];
	}
    function saveitem($data=null){
     
        $query = $this->db->insert('order_detail',$data);
        return $id = $query['id'];
	}

    function UserorderDetail($id=null){
       
       $where_array = array('orderId' => $id );
       return $query = $this->db->get_where($this->order_table_name ,$where_array);
    }

    function getCustomerOrder($CustomerId=null){
     
       $where_array  = array('CustomerId' => $CustomerId );
       $this->db->order_by("id","desc");
       return $query = $this->db->get_where($this->table_name ,$where_array);    

    }
}


?>
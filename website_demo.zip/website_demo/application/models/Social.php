<?php 

/**
* 
*/
class Social extends CI_Model
{
	
	protected $table_name;
	protected $table_link;
	
	
	function __construct()
	{
		parent::__construct();
		$this->table_name = "social_menu";
		$this->table_link = "user_social_link";

	}
function get_empty_object($table_name)
    {   
        $obj = new stdClass();
        
        $fields = $this->db->list_fields($table_name);
        foreach ($fields as $field) {
            $obj->$field = '';
        }
        return $obj;
    }
	
	function getall()
	{
		$this->db->join($this->table_link,$this->table_link.'.social_name='.$this->table_name.'.id','left');
		$query = $this->db->get($this->table_name);
		
		if ($query->num_rows()>0) {
			return $query;
		} else {
			return $query;
		}
	}

	function get_info($id)
	{

		$query = $this->db->get_where($this->table_name,array('id'=>$id));
		
		if ($query->num_rows()>0) {
			return $query->row();
		} else {
			return $this->get_empty_object($this->table_name);
		}
	}

	
}
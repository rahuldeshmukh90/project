<?php 

/**
* 
*/
class Addressbook extends CI_Model
{
	
	protected $table_name;
	
	function __construct()
	{
		parent::__construct();
		$this->table_name = "addressbook";
	}
function get_empty_object($table_name)
    {   
        $obj = new stdClass();
        
        $fields = $this->db->list_fields($table_name);
        foreach ($fields as $field) {
            $obj->$field = '';
        }
        return $obj;
    }
	
	function get_all_byuser($user_id)
	{

		$query = $this->db->get_where($this->table_name,array('user_id'=>$user_id));
		
		if ($query->num_rows()>0) {
			return $query;
		} else {
			return $query;
		}
	}

	function get_info($id)
	{

		$query = $this->db->get_where($this->table_name,array('id'=>$id));
		
		if ($query->num_rows()>0) {
			return $query->row();
		} else {
			return $this->get_empty_object($this->table_name);
		}
	}

	function save_address($data=null){

        $query = $this->db->insert($this->table_name ,$data);    
        if($query){
         $id=$this->db->insert_id();
    	
         return true; 
		     }else{
		      return false; 
		  }
    }

	function deleteaddress($id)
	{
		$this->db->delete($this->table_name,array('id' =>$id));
		return true;
	}

	function updateAddressInfo($data=null,$id=''){
        
       $where_condition = array('id' => $id );
       $this->db->where($where_condition);
       if($this->db->update($this->table_name, $data)){ return true; }else{ return false; }
       
	}
}
<?php

/**
* Product Managment system 
*/
class Product_model extends CI_Model
{
    
    protected $table_name;
    protected $category_table;
    protected $Subcategory_table;
    protected $product_multi_image_table;

	function __construct()
	{
		parent::__construct();
		$this->table_name        = 'products';
		$this->category_table    = 'categories';
		$this->Subcategory_table = 'subcategories';
		$this->product_multi_image_table='product_multi_image';
	}

  /* GET ALL CATEGORY LIST*/
  public function getAllImages($p_id)
  {
  	$this->db->where('productId',$p_id);
  	$this->db->from($this->product_multi_image_table);
  		$this->db->order_by('id','asc');
  		return $this->db->get();
  }
  
	public function getCategoryList()
	{
		$this->db->from($this->category_table);
		$this->db->order_by('id','asc');
		return $this->db->get();
	}
	function getCategoryListlimit($limit=false,$offset=false)
		{
			$this->db->from($this->category_table);
			
			if ($limit) {
				$this->db->limit($limit);
			}

			if ($offset) {
				$this->db->offset($offset);
			}

			$this->db->order_by('id','asc');
			return $this->db->get();
		}

/* SUB-CATEGORY LIST BASED ON CATEGORY ID */
	public function getSubcategoryBycatId($id=null){
        
        $this->db->from($this->Subcategory_table);
        $this->db->where('category_id', $id);
		$this->db->order_by('id','asc');
		return $this->db->get();

	}
	public function get_info_Subcategory($id){
        
        $this->db->from($this->Subcategory_table);
        $this->db->where('id', $id);
        $query= $this->db->get();
		if ($query->num_rows()==1) {
			return $query->row();
		} else {
			return $this->get_empty_object($this->Subcategory_table);
		}
		

	}
	public function get_info_Category($id)
	{
		$this->db->from($this->category_table);
		$this->db->where('id', $id);
        $query= $this->db->get();
		if ($query->num_rows()==1) {
			return $query->row();
		} else {
			return $this->get_empty_object($this->category_table);
		}
	}
/* GET ALL PRODUCT LIST */ 
	public function getAllproduct(){

       $this->db->from($this->table_name);
	   //$this->db->order_by('id','asc');
	   $this->db->order_by('id','DESC');
	   //$this->db->limit(8);
	   return $this->db->get();
    }
/* SHOW PRODUCT DETAIL BY ID*/
    public function productdetailById($id=null){
       
       $this->db->from($this->table_name);
       $this->db->where('id', $id);
       $query = $this->db->get(); 
       return $query->row();
    }
/* GET PRODUCT LIST BASED ON SUB-CATEGORY*/

public function count_allBysubCategoryId($id=null){
      if (!empty($id)){
       
       $this->db->from($this->table_name);
       $this->db->where('subcategory_id', $id);
      
	   return $this->db->get()->num_rows();

      }else{
        
        return false;
      } 
    }

    public function count_allBycolor($subcategory_id='',$color=''){

      if (!empty($subcategory_id)){
       
      $query = $this->db->get_where('product_attributes', array('subcategory_id' => $subcategory_id, 'product_color' => $color));
      
      return $query->num_rows();

      }else{
        
        return false;
      } 
    }

    public function count_allBysize($subcategory_id='',$size=''){

      if (!empty($subcategory_id)){
       
      $query = $this->db->get_where('product_attributes', array('subcategory_id' => $subcategory_id, 'product_size' => $size));
      
      return $query->num_rows();

      }else{
        
        return false;
      } 
    }    

    public function count_allBybrand($subcategory_id='',$brand=''){

      if (!empty($subcategory_id)){
       
      $query = $this->db->get_where('products', array('subcategory_id' => $subcategory_id, 'brand' => $brand));
      
      return $query->num_rows();

      }else{
        
        return false;
      } 
    }    

    public function findProductId($subcategory_id='',$color=''){

      if (!empty($subcategory_id)){
       
      $query = $this->db->get_where('product_attributes', array('subcategory_id' => $subcategory_id, 'product_color' => $color));
      
      //echo $this->db->last_query(); die;
      if($query->num_rows()>0){
        
        return $query->result();

      }
      
      }else{
        
        return false;
      } 
    }

    public function findProductIdbysize($subcategory_id='',$size=''){

      if (!empty($subcategory_id)){
       
      $query = $this->db->get_where('product_attributes', array('subcategory_id' => $subcategory_id, 'product_size' => $size));
      
      //echo $this->db->last_query(); die;
      if($query->num_rows()>0){
        
        return $query->result();

      }
      
      }else{
        
        return false;
      } 
    }    

    public function ProductListBysubCategoryId($id=null,$limit=false,$offset=false){
      
       

      
      if (!empty($id)){
       
       $this->db->from($this->table_name);
       $this->db->where('subcategory_id', $id);
       if ($limit) {
			$this->db->limit($limit);
		}

		if ($offset) {
			$this->db->offset($offset);
		}
	   $this->db->order_by('id','DESC');

     return $this->db->get();

      }else{
        
        return false;
      } 
    }

    public function ProductListBysubCategoryIdandBrand($id=null,$limit=false,$offset=false,$brand=''){
      
       

      
      if (!empty($id)){
       
       $this->db->from($this->table_name);
       $this->db->where(array('subcategory_id' => $id, 'brand' => $brand));
       if ($limit) {
      $this->db->limit($limit);
    }

    if ($offset) {
      $this->db->offset($offset);
    }
     $this->db->order_by('id','DESC');

     return $this->db->get();

      }else{
        
        return false;
      } 
    }    

    public function ProductListBysubCategoryandColor($id=null,$limit=false,$offset=false,$color=''){
      
      if (!empty($id)){
       

      $product = $this->findProductId($id,$color);
      
      foreach ($product as $products) {
          
          $product_id[] = $products->productId;     
      }   

      $this->db->from($this->table_name);
      $this->db->where_in('id',$product_id);
      if ($limit) {

      $this->db->limit($limit);

      }

      if ($offset) {
        $this->db->offset($offset);
      }
      
      $this->db->order_by('id','DESC');

       return $this->db->get();
       
      }else{
        
        return false;
      } 
    }

    public function ProductListBysubCategoryandSize($id=null,$limit=false,$offset=false,$size=''){
      
      if (!empty($id)){
       

      $product = $this->findProductIdbysize($id,$size);
      
      foreach ($product as $products) {
          
          $product_id[] = $products->productId;     
      }   

      $this->db->from($this->table_name);
      $this->db->where_in('id',$product_id);
      if ($limit) {

      $this->db->limit($limit);

      }

      if ($offset) {
        $this->db->offset($offset);
      }
      
      $this->db->order_by('id','DESC');

       return $this->db->get();
       
      }else{
        
        return false;
      } 
    }    
    
    public function ProductListBysubCategoryIdsort($id=null,$sort=false,$limit=false,$offset=false){
      if (!empty($id)){
       
       $this->db->from($this->table_name);
       $this->db->where('subcategory_id', $id);
       if ($limit) {
			$this->db->limit($limit);
		}

		if ($offset) {
			$this->db->offset($offset);
		}
		
		
	   
	   if($sort)
		{
			$this->db->order_by($sort);	
		}
		else
		{
			$this->db->order_by('id','DESC');
		}
	   $data =$this->db->get();
	  
	   return $data;

      }else{
        
        return false;
      } 
    }
    
    public function ProductListBytype($id=null,$limit=false,$offset=false){
      if (!empty($id)){
       
       $this->db->from($this->table_name);
       $this->db->where('type', $id);
	    if ($limit) {
			$this->db->limit($limit);
		}

		if ($offset) {
			$this->db->offset($offset);
		}

	   $this->db->order_by('id','DESC');
	   $data=$this->db->get();
	 
	   return $data;

      }else{
        
        return false;
      } 
    }
    
    public function get_fields_by_product($id=null)
    {
    	if(!empty($id)){

    		$this->db->select('distinct(attribute_key) as attribute');
    		$this->db->from('product_fields_attributes');
    		$this->db->where('productId', $id);
    		return $this->db->get();

    	}

    }

    public function getKey($id=null)
    {
      if(!empty($id)){

        $Query = $this->db->get_where('product_fields_attributes', array('productId' => $id));
        if($Query->num_rows()>0){
         
          return $Query->result();
        }else{

          return false;
        }

      }

    }    

    public function get_cs_attribute($id=null)
    {
    	$this->db->distinct('product_size');
    	$this->db->select('id, product_size');
    	$this->db->from('product_attributes');
    	$this->db->where('productId', $id);
    	$this->db->group_by('product_size');
    	return $this->db->get();
    	
    }
    
    public function getproductColor($size='', $product_id=''){
        
      $this->db->distinct();
    	$this->db->select('id,product_color,product_quantity');
        $query = $this->db->get_where('product_attributes', array('productId' => $product_id, 'product_size' => $size, 'product_quantity'.'>' => 0 ));
        
        if($query->num_rows()>0){

        	return $query->result();
        }else{

            return false; 
        }
    }


    public function get_attribute_by_product($id=null,$attribute=null)
    {
    	if(!empty($id)){
    		
    		$this->db->from('product_fields_attributes');
    		$this->db->where('productId', $id);
    		$this->db->where('attribute_key', $attribute);
    		return $this->db->get();
    	}

    }

    function get_empty_object($table_name)
    {   
        $obj = new stdClass();
        $fields = $this->db->list_fields($table_name);
        foreach ($fields as $field) {
            
            $obj->$field = '';
        }

        return $obj;
    }

    /*================== FOR PRODUCT STOCK QUANTITY ==============*/

    function get_product_attribute_stock($product_id='',$color='', $size=''){
      
      $Query = $this->db->get_where('product_attributes', array('productId' => $product_id, 'product_color' => $color, 'product_size' => $size ),1);

      if($Query->num_rows()>0){
        
        return $Query->row();

      }else{

        return false;
      }
    }

    function updatepAttriQuantity($product_id='',$color='', $size='', $qnty=''){
      
          $data = array('productId' => $product_id, 'product_color' => $color, 'product_size' => $size);
          $this->db->where($data);   
          $Query = $this->db->update('product_attributes', array('product_quantity' => $qnty ) );
          
          if($this->db->affected_rows()>0){
             
            return true;

          }else{
            
            return false;
          }
    
    }

    function updatepQuantity($product_id='', $qnty=''){
      
          $pr_st = $this->productdetailById($product_id);
          $get_q = $pr_st->quantity;
          $quantity = $get_q-$qnty; 

          $data  = array('id' => $product_id);
          $this->db->where($data);   
          $Query = $this->db->update('products', array('quantity' => $quantity ));
          if($this->db->affected_rows()>0){
            
            return true;
          }else{

            return false;
          }
    
    } 

    function getcolorBycategory($subcategory_id=''){
      
      $this->db->select('*');
      $this->db->from('product_attributes');
      $this->db->where('subcategory_id', $subcategory_id);
      $this->db->distinct('product_color');
      $this->db->group_by('product_color');
      $query = $this->db->get();
      return $query->result();
    }

    function getBrands($subcategory_id=''){
      
      $this->db->select('*');
      $this->db->from('products');
      $this->db->where('subcategory_id', $subcategory_id);
      $this->db->distinct('brand');
      $this->db->group_by('brand');
      $query = $this->db->get();
      return $query->result();
    }

    public function getSizes($subcategory_id=null){

      $this->db->distinct('product_size');
      $this->db->select('id, product_size');
      $this->db->from('product_attributes');
      $this->db->where('subcategory_id', $subcategory_id);
      $this->db->group_by('product_size');
      $query = $this->db->get();
      return $query->result();
      
    }    

}
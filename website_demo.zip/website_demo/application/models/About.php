<?php 

/**
* 
*/
class About extends CI_Model
{
	
	protected $table_name;
	
	function __construct()
	{
		parent::__construct();
		$this->table_name = "about_us";
	}
function get_empty_object($table_name)
    {   
        $obj = new stdClass();
        
        $fields = $this->db->list_fields($table_name);
        foreach ($fields as $field) {
            $obj->$field = '';
        }
        return $obj;
    }
	
	function getall()
	{

		$query = $this->db->get_where($this->table_name);
		
		if ($query->num_rows()>0) {
			return $query;
		} else {
			return $query;
		}
	}

	function get_info($id)
	{

		$query = $this->db->get_where($this->table_name,array('id'=>$id));
		
		if ($query->num_rows()>0) {
			return $query->row();
		} else {
			return $this->get_empty_object($this->table_name);
		}
	}

	
}
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
//$route['default_controller'] = 'welcome';

//SET DEFUALT WEBSITE PAGE 

$route['default_controller'] = 'Home';

/*== PRODUCT LIST ACCORDING TO SUB-CATEGORY ==*/
$route['bGlzdC8=LIST']            = 'Product/items_list';
$route['c2VhcmNobGlzdC8=LIST']    = 'Product/items_searchlist';


/*== Single product Detail  ==*/

$route['single_ProductDetailcGQxMjM0_page'] = 'Product/detail';
// $route['quickview_ProductcGQxMjM0_page'] = 'Product/quickview';

$route['Access=login_451bGctMQ==P'] = 'User/loginInUser';
$route['Access=forgot_451ZnAtMQ==Pass'] = 'User/forget_password';
/*=== LOAD ABOUT US PAGE =====*/
$route['about_usYWI=0/1/5']         = 'Home/about_us';
/*=== LOAD Delivery PAGE =====*/
$route['deliveryYWI=0/1/6']         = 'User/delivery';
/*=== LOAD Blog PAGE =====*/
$route['0/6/c/n/1Ymw=blog']         = 'Home/blog';
/*=== LOAD Blog featured =====*/
$route['0/7/f/p/rZnByfeatured']         = 'Product/featured_item';
/*=== LOAD CONTACT US PAGE =====*/

$route['0/6/c/n/1Y24=contact_us']   = 'Home/contact_us';
/*=== LOAD CUSTOMER PROFILE PAGE ===*/
$route['0/index/u/p/1dXA=user/Profile_/22/page/dXJfcHJvZmlsZS8v/Y'] = 'User/C_profile';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

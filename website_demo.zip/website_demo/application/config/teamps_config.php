<?php

/* pagination */
$config['pagination'] = array();

$config['pagination']['per_page'] = 3;
$config['pagination']['num_links'] = 5;
$config['pagination']['full_tag_open'] =  '<ul class="page-list clearfix text-xs-right">';
$config['pagination']['full_tag_close'] = '</ul>';
$config['pagination']['num_tag_open'] = '<li>';
$config['pagination']['num_tag_close'] = '</li>';
$config['pagination']['first_link'] = '&laquo;';
$config['pagination']['first_tag_open'] = '<li>';
$config['pagination']['first_tag_close'] = '</li>';
$config['pagination']['last_link'] = '&raquo;';
$config['pagination']['last_tag_open'] = '<li>';
$config['pagination']['last_tag_close'] = '</li>';
$config['pagination']['next_link'] = '&raquo;';
$config['pagination']['next_tag_open'] = '<li>';
$config['pagination']['next_tag_close'] = '</li>';
$config['pagination']['prev_link'] = '&laquo;';
$config['pagination']['prev_tag_open'] = '<li>';
$config['pagination']['prev_tag_close'] = '</li>';
$config['pagination']['cur_tag_open'] = '<li class="current"><a class="disabled js-search-link">';
$config['pagination']['cur_tag_close'] = '</a></li>';
$config['pagination']['page_query_string']=true;
$config['pagination']['query_string_segment']='GZEP';

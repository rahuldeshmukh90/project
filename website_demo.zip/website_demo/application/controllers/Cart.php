<?php

class Cart extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct('Cart');
		$this->load->library('cart');

	}
/*========ADD PRODUCT INTO CART================*/
	function add(){
		
        $this->load->library('cart');

        if ($this->input->server('REQUEST_METHOD') == 'POST') {

        	$productdeatil=$this->Product_model->productdetailById($this->input->post('p_id'));
			$size=$color='';
			
				
			if($this->input->post('size'))
			{
				$size=$this->input->post('size');
			}
			if($this->input->post('color'))
			{
				$color=$this->input->post('color');
			}
		
            $data = array(
					        'id'              => str_replace(" ","",$productdeatil->id.$size.str_replace("#","",$color)),
            	            //'id'              => $productdeatil->id,    
					        'pro_id'          => $productdeatil->id,
					        'code'			  => $productdeatil->code,
					        'name'            => $productdeatil->name,
					        'price'           => $productdeatil->price,
					        'qty'             => $this->input->post('p_qty'),
					        'category_id'     => $productdeatil->category_id,
					        'image'           => $productdeatil->image,	
					        'totalprice'      => $productdeatil->price*$this->input->post('p_qty'),
					        'size'            => $size,	
					        'color'           => $color	        
					     );
            
            $this->cart->product_name_rules = '[:print:]';
            $save_cart_data   = $this->cart->insert($data);
            
            if($save_cart_data){

			    $this->session->set_flashdata('success','Product is successfully added');
				echo $this->cart->total_items();

		    }else{

		    	echo 0;
			    $this->session->set_flashdata('error','Product is not added');
		        
		    }
		}
	}		
/*========ADD TO CART PRODUCT LIST ================*/
    function view_cart(){
			
           if (!$this->cart->contents()){

			$this->data['message'] = '<p>Your cart is empty!</p>';

			}else{

				$this->data['message'] = $this->session->flashdata('message');
            }

            $this->load->view('common/imt/head'); 
            $this->load->view('cart/view_cart', $this->data);
			
	}
/*========REMOVE PRODUCT INTO CART================*/
	
	function remove($rowid="all"){
		
		if($rowid=="all"){ $this->cart->destroy(); }else{

			$data = array( 'rowid' => $rowid, 'qty' => 0 );
            $this->cart->update($data);
		}
		
		$this->session->set_flashdata('success','Product is successfully remove.');
		redirect('cart/view_cart');
	}

/*========REMOVE Ajax ================*/

	function removeajax($rowid="all"){
		
		if($rowid=="all"){ $this->cart->destroy(); }else{

			$data = array( 'rowid' => $rowid, 'qty' => 0 );
            $this->cart->update($data);
		}
			$arrayName = array('success' => true);
			echo json_encode($arrayName);
			die;
		
	}
	
/*========UPDATE PRODUCT  CART================*/

	function update_cart(){

        foreach($_POST['cart'] as $id => $cart)
		{	echo "qnty".$cart['qty']; 		
			echo $price = "prive".$cart['price'];
			echo $amount = $price * $cart['qty']; die;
			 $this->cart_model->update_cart($cart['rowid'], $cart['qty'], $price, $amount);
		}

		$this->session->set_flashdata('success','Cart is update.');
		redirect('cart/view_cart');
	}
	function update(){
        	//var_dump($this->input->post());die;
        	if($this->input->post('size'))
			{
				$size=$this->input->post('size');
			}
			if($this->input->post('color'))
			{
				$color=$this->input->post('color');
			}		
			 $price = $_POST['price'];
			 $amount = $price * $_POST['qty']; 
			 $data = array( 'rowid' => $_POST['row_id'], 'qty' => $_POST['qty'] ,'size'=>$size,'color'=>$color);
            $this->cart->update($data);
			 $this->cart_model->update_cart($_POST['row_id'], $_POST['qty'], $price, $amount);
			 $code=  array(
			 	        "success"=>true,
			 	        "id_product"=> 2,
			 	        "id_product_attribute"=>56,
			 	        "quantity"=>$_POST['qty'],
			 	        "cart"=>array(
			 	        	"totals"=> array(
                                        "total"=> array(
                                        	"type"=>"total",
								            "label"=>"Total",
								            "amount"=>385.3,
								            "value"=>"$385.30"
								        ),
            							"total_including_tax"=>array(
							              "type"=>"total",
							              "label"=>"Total (tax incl.)",
							              "amount"=> 385.3,
							              "value"=>"$385.30"
							            ),
            							"total_excluding_tax"=> array(
							              "type"=>"total",
							              "label"=>"Total (tax excl.)",
							              "amount"=>385.3,
							              "value"=>"$385.30"
							            )
          							),
          							"subtotals"=>array(
            							"products"=> array(
              								"type"=>"products",
              								"label"=> "Subtotal",
              								"amount"=> 385.3,
              								"value"=>"$385.30"
            							),
            							"discounts"=>null,
            							"shipping"=>array(
							                "type"=>"shipping",
              								"label"=>"Shipping",
              								"amount"=>0,
              								"value"=>"Free"
            							),
            							"tax"=>array(
              								"type"=>"tax",
              								"label"=>"Taxes",
              								"amount"=>0,
              								"value"=>"$0.00"
            							)
          							),
          							"products_count"=>4,
          						    "summary_string"=>"4 items",
          							"labels"=>array(
            									"tax_short"=>"(tax excl.)",
            								"tax_long"=>"(tax excluded)"
          							),
         						   "minimalPurchase"=>0,
          						   "minimalPurchaseRequired"=>""
        						)
							);					 	        
			 echo json_encode($code);
		
	}
	public function checkout(){
		
		 if ($_SERVER['REQUEST_METHOD'] == 'POST') {
		 	if($this->input->post('delivery_option'))
		 	{
		 		$delivery['delivery_option']=$this->input->post('delivery_option');
		 		$delivery['user_id']=$this->input->post('id');
		 		$delivery['delivery_message']=$this->input->post('delivery_message');
		 		$this->session->set_userdata('delivery',$delivery);
		 		$data['step']=4;	
		 	}
		 	

		 	
		 }

      $this->load->view('common/imt/head'); 
      $this->load->view('cart/checkout',$data);
    }

    function detail()
    {
    	$grand_total=0;
    	$lastimg = $lastprice=$lastname=$lastqty=$color=$size='';
    	
    	$preview = '<div id="desktop_cart"><div class="blockcart cart-preview active" data-refresh-url="'.base_url().'Cart/detail"><div class="header blockcart-header dropdown js-dropdown"><a class="shopping-cart" rel="nofollow" href=""  data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span class="hidden-sm-down">Cart</span>
			<span class="cart-products-count">'.$this->cart->total_items().'</span></a>
			<div class="cart_block block exclusive dropdown-menu">
				<div class="block_content">';
				if ($cart = $this->cart->contents()){
				
			$preview .='<div class="cart_block_list">';
				$grand_total = 0; foreach ($cart as $item):  
				$lastimg     = IMAGE_URL.$item['image'];
				$lastprice   = number_format($item['price'],2);
				$lastname    = $item['name'];
				$lastqty     = $item['qty'];
				$size        = $item['size'];
				$color       = $item['color'];

			$preview .='<div class="cart-item"><div class="cart-image"><a href="#"><img src="'.IMAGE_URL.$item['image'].'" alt="'.$item['name'].'" style="width:85px;"></a></div><div class="cart-info"><span class="product-quantity">'.$item['qty'].'</span>x<span class="product-name"><a href="#">'.$item['name'].'</a></span><span class="product-price">₹ '.number_format($item['price'],2).'</span><a class = "remove-from-cart" rel= "nofollow" href= "'.base_url().'Cart/removeajax/'.$item['rowid'].'" data-link-action= "delete-from-cart" data-id-product= "'.$item['pro_id'].'" data-id-product-attribute = "'.$item['rowid'].'" ta-id-customization= "">&nbsp;</a></div></div>';
			    
			    // $grand_total = $grand_total + $item['subtotal']; 
			    $grand_total = $item['subtotal']; 

			    endforeach;            

			$preview .='</div><div class="card cart-summary"><div class="card-block"><div class="cart-summary-line" id="cart-subtotal-products"><span class="label js-subtotal">'.$this->cart->total_items().' items</span><span class="value">₹'.number_format($grand_total,2).'</span></div><div class="cart-summary-line" id="cart-subtotal-shipping"><span class="label">Shipping</span><span class="value">Free</span><div><small class="value"></small></div></div></div><div class="card-block"><div class="cart-summary-line cart-total"><span class="label">Total (tax excl.)</span><span class="value">₹ '.number_format($grand_total,2).'</span></div><div class="cart-summary-line"><small class="label">Taxes</small><small class="value">$0.00</small></div></div></div><div class="checkout card-block"><a rel="nofollow" href="'.base_url().'Cart/view_cart" class="viewcart">
							<button type="button" class="btn btn-primary">View Cart</button>
							</a>
						</div>';
						} else {
           $preview .='       <span class="no-items">There are no more items in your cart</span>
               ';
               }
				 $preview .='</div>
			</div>
		</div>
		</div>
		</div>';
		
		// $model='<div id="blockcart-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true"><div class="modal-dialog" role="document"><div class="modal-content"><div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button><h4 class="modal-title h6 text-xs-center" id="myModalLabel">Product successfully added to your shopping cart</h4></div><div class="modal-body"><div class="row"><div class="col-md-6 divide-right"><div class="row"><div class="col-md-6"><img class="product-image" src="'.$lastimg.'" alt="" title="" itemprop="image"></div><div class="col-md-6"><h6 class="h6 product-name">'.$lastname.'</h6><p>₹ '.$lastprice.'</p>';
		// 	if($size!=''){

		// 		$model.='<span><strong>Size</strong>: '.$size.'</span><br>';
		// 	}
		// 	if($color!=''){
		// 		$model.='<span><strong>Color</strong>:<span class="color" style="background-color:  '.$color.';margin-bottom: 0px; "></span></span>';
		// 	}

		$model='<div id="blockcart-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true"><div class="modal-dialog" role="document"><div class="modal-content"><div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button><h4 class="modal-title h6 text-xs-center" id="myModalLabel">Product successfully added to your shopping cart</h4></div><div class="modal-body"><div class="row"><div class="col-md-6 divide-right"><div class="row"><div class="col-md-6"><img class="product-image" src="'.$lastimg.'" alt="" title="" itemprop="image"></div><div class="col-md-6"> <h6 class="h6 product-name">'.$lastname.'</h6><p>₹ '.$lastprice.'</p>';
			
			if($size!=''){

				$model.='<div class="col-md-12" ><div class="col-md-6" ><span><strong>Size</strong></div><div class="col-md-6" >: '.$size.'</div></div>';
				
			}

			if($color!=''){
				
				$model.='<div class="col-md-12" ><div class="col-md-6" ><span><strong>Color</strong></div><div class="col-md-6" >: <span class="color" style="background-color:  '.$color.';margin-bottom: 0px; "></span></div></div>';
			}

		// $model.='<br><p><strong>Quantity:</strong>&nbsp;'.$lastqty.'</p></div></div></div><div class="col-md-6"><div class="cart-content"><p class="cart-products-count">There are '.$this->cart->total_items().' items in your cart.</p><p><strong>Total products:</strong>&nbsp;'.$this->cart->total_items().'</p><p><strong>Total shipping:</strong>&nbsp;Free </p><p><strong>Taxes</strong>&nbsp;₹ 0.00</p><p><strong>Total:</strong>&nbsp;₹ '.number_format($grand_total,2).'(tax excl.)</p><button type="button" class="btn btn-secondary" data-dismiss="modal">Continue shopping</button><a href="'.base_url().'Cart/view_cart" class="btn btn-primary">Proceed to checkout</a></div></div></div></div></div></div></div>';
        
		$model.='<br><div class="col-md-12" ><div class="col-md-6" ><span><strong>Quantity</strong></div><div class="col-md-6" >: '.$lastqty.'</div></div></div></div></div><div class="col-md-6"><div class="cart-content"><p class="cart-products-count">There are '.$this->cart->total_items().' items in your cart.</p><table class="table" ><tr><td> Total products <td><td>: '.$this->cart->total_items().' <td></tr><tr><td> Total Shipping <td><td>: Free <td></tr><tr><td> Total <td><td>: ₹ '.number_format($grand_total,2).' <td></tr></table><button type="button" class="btn btn-secondary" data-dismiss="modal">Continue shopping</button><a href="'.base_url().'Cart/view_cart" class="btn btn-primary">Proceed to checkout</a></div></div></div></div></div></div></div>';

	    $data=array( "modal" => $model, "preview"=>$preview );
	    echo json_encode($data);
    }

    

}
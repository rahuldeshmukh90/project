<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once('Access.php');
class Order extends Access{
/*=============INDEX FUNCTION===============*/  
	public function index()
	{
	    if (!$this->Users->is_logged_in()){
       	   
       	   redirect('User/loginInUser');
      }else{

         $last_url = $_SERVER['HTTP_REFERER'];   
         redirect($last_url);
      }
	}
/*=============SET DEFAULT TIME ZONE===============*/  	
  public function default_datetime_zone($date=null)
      {
           date_default_timezone_set("Asia/Kolkata");
           return $today_date=date("Y-m-d G:i:s");
      }
/*=============PROCCESS TO CHECKOUT ORDER===============*/  
	function checkout_order(){

    $onDate  = $this->default_datetime_zone();	
	  $user_id = $this->session->userdata('id');
    $cart    = $this->cart->contents();

    $payment_option=$this->input->post('payment-option');
    $this->cart->destroy();
    
    if(count($cart)>0){ $total=$item=0;
        foreach($cart as $val){
          $total=$total+$val['subtotal'];
          $item++;
        }

        $delivery = $this->session->userdata('delivery');
        $data     = array( 
                         
                          'CustomerId'       => $user_id,
                          'TotalPrice'       => $total,
                          'TotalQty'         => $item,
                          'Bill_Number'      => "IMT-".time(),
                          'OrderDate'        => $onDate,
                          'delivery_option'  => $delivery['delivery_option'],
                          'delivery_message' => $delivery['delivery_message'],
                          'payment_option'   => $payment_option,
                          'status'           => "1"  

                        );

        $this->Order_model->save($data);
        $this->session->unset_userdata('delivery');
        $order_id = $this->db->insert_id(); 

        foreach($cart as $val){
        
        $product_id = $val['pro_id']; 
        $color      = ($val['color'])?$val['color']:'';  
        $size       = ($val['size'])?$val['size']:'';  
        
        $sale_qty   = $val['qty'];
        $PO_Qty     = $this->Product_model->get_product_attribute_stock($product_id,$color,$size); 
        $prodctO    = $PO_Qty->product_quantity; 
        $prodctN    = $prodctO-$val['qty'];
        
        if($this->Product_model->updatepQuantity($product_id,$sale_qty)){
          
          $this->Product_model->updatepAttriQuantity($product_id,$color,$size,$prodctN);   
          $total = ($val['price'])*($val['qty']);
          $data1 = array( 'orderId'   =>$order_id, 'ItemId'=>$val['pro_id'], 'price'=> $val['price'],'quantity'=>$val['qty'],'gross_total'=>$total);
          $this->Order_model->saveitem($data1); 

        }
        
      }
      
      }
      if(!empty($order_id)) {
        $datar['orders'] = $this->Order_model->getCustomerOrder($user_id);
        $this->load->view('common/imt/head'); 
        $this->load->view('cart/order_histry',$datar); 			

      }else{
        $datar['orders'] = $this->Order_model->getCustomerOrder($user_id);
        $this->load->view('common/imt/head'); 
        $this->load->view('cart/order_histry',$datar);
                
        // $last_url = $_SERVER['HTTP_REFERER'];   
        // redirect($last_url); 
      }
    }
    public function order_details()
      {
            $this->load->view('common/imt/head'); 
        $this->load->view('order/order_details');
      }

}


<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {
    

    function __construct()
	{
		parent::__construct();
		//$this->load->library('uploader');
		$this->load->library('email',array(

			'mailtype'=> 'html',
			'newline'=>'\r\n'
		));
	}
    /* ================FOR USER INDEX============== */    
	public function index()
	{
        if (!$this->Users->is_logged_in()){
        	
       	   redirect('User/loginInUser');
        }else{

           $last_url = $_SERVER['HTTP_REFERER'];   
           redirect($last_url);
        }
	}
    /* ================FOR USER LOGIN============== */    
    public function loginInUser(){
     
       if ($this->Users->is_logged_in()) {
       	   
       	   $last_url = $_SERVER['HTTP_REFERER'];   
           redirect($last_url);
		}
		else
		{
			$set_url  = $this->session->userdata('last_url'); 
			$last_url = $_SERVER['HTTP_REFERER'];
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                 
                $username = $this->input->post('username');  
				$password = md5($this->input->post('password')); 
                if($this->Users->login($username,$password)){
                    if($this->session->userdata('id')){
						    if(isset($set_url)) {
                 redirect($set_url); 
               }else{

                if($last_url!= base_url().'Access=login_451'.base64_encode('lg-1').'P') 
                  {
                  redirect($last_url);
                  }
                  else{
                    redirect(site_url()); 
                  }
                 
              }
					}else{ redirect($last_url); }
				}else{
					    
					    $this->session->set_flashdata('error','Email ID and Password not match');
						redirect($last_url);
			    } 
            }else{ 
            	 $this->load->view('common/imt/head'); 
            	$this->load->view('user/login'); 
            }
		}		
    }

    /* ================FOR USER LOGIN============== */    
    public function forget_password(){
     
       if ($this->Users->is_logged_in()) {
       	   
       	   $last_url = $_SERVER['HTTP_REFERER'];   
           redirect($last_url);
		}
		else
		{
			$set_url  = $this->session->userdata('last_url'); 
			$last_url = $_SERVER['HTTP_REFERER'];
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                 
                $username = $this->input->post('username');  
				
                if($this->Users->check_email_info($username,$password)){
                    if($this->session->userdata('emailid')){
                    	$id=$this->session->userdata('emailid');
                    	$base_url1 = "http://".$_SERVER['HTTP_HOST'];
					$base_url  = $base_url1."/website_demo/forgot_pass.php?user_id=".base64_encode($id); 
					
					$sender_email = $this->config->item('sender_email'); 
					$sender_name  = $this->config->item('sender_name');
					$to = $this->session->userdata('addemail');
							
					$sub = "Forgot Password";
					$msg = "<p>Hi,".$this->session->userdata('emailname')."</p>".
								"<p>Please click the following link to rest your Passsword<br/>".
								"<a href='".$base_url."'>Click Here</a></p>".
								"<p>Best Regards,<br/>".$sender_name."</p>";
					
					$headers  = 'MIME-Version: 1.0' . "\r\n";
					$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
					$headers .=  "From: info@impetrosys.com";
							$this->sendmail($to,$sub,$msg);
							redirect($last_url);
					}else{ redirect($last_url); }
				}else{
					    
					    $this->session->set_flashdata('error','Email ID not match');
						redirect($last_url);
			    } 
            }else{ 
            	 $this->load->view('common/imt/head'); 
            	$this->load->view('user/forget_password'); 
            }
		}		
    }


/* ================FOR SEND EMAIL============== */        

    public function sendmail($to,$subject,$html )
        {

          $sender_email = 'info@impetrosys.com'; //$this->config->item('sender_email');
	      $sender_name  = 'ImpetroStock'; //$this->config->item('sender_name');
          $this->email->set_mailtype("html");
		  $this->email->set_newline("\r\n");
		  $this->email->from($sender_email,$sender_name);
		  $this->email->to($to); 
		  $this->email->subject($subject);
		  $this->email->message($html);	
		  $this->email->send();
		//echo $this->email->print_debugger();die;
		 
        }

/* ================FOR USER REGISTRATION============== */    
   public function registration(){
       
        if ($this->Users->is_logged_in()) {
       	   
       	   $last_url = $_SERVER['HTTP_REFERER'];   
           redirect($last_url);
		}
		else
		{
			$set_url  = $this->session->userdata('last_url'); 
			$last_url = $_SERVER['HTTP_REFERER'];
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
		
		     $name  = $this->input->post('name');
	       $email = $this->input->post('email'); 

	       $contact  = $this->input->post('contact');
	       $password = md5($this->input->post('password')); 

	       $city  = $this->input->post('city');
	       $state = $this->input->post('state'); 

	       $postal_code  = $this->input->post('postal_code');
	       $country      = $this->input->post('country'); 

	       $address  = $this->input->post('address');
	       
	       $data = array('name'        => $name,
	                     'email'       => $email,
	                     'password'    => $password,
	                     'phone'       => $contact,
	                     'address'     => $address,
	                     'city'        => $city,
	                     'state'       => $state,
	                     'country'     => $country,
	                     'postal_code' => $postal_code,
	                    );
	        $value = $this->Users->check_email_info($email);


	        if($value){ 
	             
	             $this->session->set_flashdata('success','This Email is Already Exists');
				 redirect(site_url('User/registration'));
	        	
	        }else{ 
	       

	         $saveCustomer = $this->Users->save_customer($data); 
		       if($saveCustomer){
		       	    
		      $id = "16";
          $base_url1 = "https://".$_SERVER['HTTP_HOST'];
					$base_url  = $base_url1."/website_demo/verify_email.php?user_id=".base64_encode($id); 
					
					$sender_email = $this->config->item('sender_email'); 
					$sender_name  = $this->config->item('sender_name');
					$to = 'rhldshmkh91@gmail.com';
							
					$sub = "Account Verify";
					$msg = "<p>Hi,".$name."</p>".
								"<p>Please click the following link to Verify your account<br/>".
								"<a href='".$base_url."'>Click Here</a></p>".
								"<p>Best Regards,<br/>".$sender_name."</p>";
					
					$headers  = 'MIME-Version: 1.0' . "\r\n";
					$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
					$headers .=  "From: info@impetrosys.com";
					//mail($to,$sub,$msg,$headers);

					$this->sendmail($to,$sub,$msg);
					// if($emailvarification){
					// 	echo "success"; die;
					// }else{
                    // echo "fail"; die;
					// }

	                $data1['mailmsg']="success";
					

		       	    $this->session->set_flashdata('success','User Registration is Successfully');

					 if($this->session->userdata('id')){
						    if(isset($set_url)) { 
						    	redirect($set_url); 
						    	// echo $set_url;die;
						    }else{
						    //echo site_url();die;
							    if($last_url!=site_url('User/registration')) 
							    {
									redirect($last_url);
							    }
							    else{
							    	redirect(site_url()); 
							    }
						    }

						    
					}else{  //echo $last_url;die;
					 redirect($last_url);
					 }

		       }else{

		            $this->session->set_flashdata('error','Email ID and Password not match');
					redirect(site_url('User/registration'));
		       } 
	        	
	        } 
	       	

		}else{
			 $this->load->view('common/imt/head'); 
           $this->load->view('user/registration');
		}
	}
       
   }

/* ================FOR LOGOUT USER============== */    

   public function C_profile(){

        if (!$this->Users->is_logged_in()){
        	
       	   redirect('User/login');

        }else{

           if($_SERVER['REQUEST_METHOD'] == 'POST'){

            $customer_id = $this->input->post('id');
            if($this->input->post('name')){ $data['name'] = $this->input->post('name'); }
            if($this->input->post('email')){ $data['email'] = $this->input->post('email');}
            if($this->input->post('contact')){ $data['phone'] = $this->input->post('contact');}
            if($this->input->post('address')){ $data['address'] = $this->input->post('address');}
            if($this->input->post('city')){ $data['city'] = $this->input->post('city');}
            if($this->input->post('state')){ $data['state'] = $this->input->post('state');}
            if($this->input->post('country')){ $data['country'] = $this->input->post('country');}
            
            if($this->Users->updateCustomerInfo($data,$customer_id)){

            	$this->session->set_flashdata('success','Profile is Successfully Updated');
			    redirect(site_url('0/index/u/p/1dXA=user/Profile_/22/page/dXJfcHJvZmlsZS8v/Y'));

            }else{

                $this->session->set_flashdata('error','Failled');
				redirect(site_url('0/index/u/p/1dXA=user/Profile_/22/page/dXJfcHJvZmlsZS8v/Y'));
            }

           }else{

                $this->load->view('user/profile');
           } 
           
        }
     
   }

   public function personal_info(){

        if (!$this->Users->is_logged_in()){
        	
       	   redirect('User/login');

        }else{

           if($_SERVER['REQUEST_METHOD'] == 'POST'){

            $customer_id = $this->input->post('id');
            if($this->input->post('name')){ $data['name'] = $this->input->post('name'); }
            if($this->input->post('email')){ $data['email'] = $this->input->post('email');}
            if($this->input->post('contact')){ $data['phone'] = $this->input->post('contact');}
            if($this->input->post('address')){ $data['address'] = $this->input->post('address');}
            if($this->input->post('city')){ $data['city'] = $this->input->post('city');}
            if($this->input->post('state')){ $data['state'] = $this->input->post('state');}
            if($this->input->post('country')){ $data['country'] = $this->input->post('country');}
            
            if($this->Users->updateCustomerInfo($data,$customer_id)){

            	$this->session->set_flashdata('success','Profile is Successfully Updated');
			    redirect(site_url('user/personal_info'));

            }else{

              ///  $this->session->set_flashdata('error','Failled');
				//redirect(site_url('0/index/u/p/1dXA=user/Profile_/22/page/dXJfcHJvZmlsZS8v/Y'));
            }

           }else{
               $this->load->view('common/imt/head'); 
                $this->load->view('user/personal_info');
           } 
           
        }
     
   }
  public function add_address()
  {
  	 if (!$this->Users->is_logged_in()){
        	
       	   redirect('User/login');

        }else{
        	$last_url = $_SERVER['HTTP_REFERER'];
           if($_SERVER['REQUEST_METHOD'] == 'POST'){

            $customer_id = $this->input->post('id');
            if($this->input->post('name')){ $data['name'] = $this->input->post('name'); }
            if($this->input->post('email')){ $data['email'] = $this->input->post('email');}
            if($this->input->post('contact')){ $data['phone'] = $this->input->post('contact');}
            if($this->input->post('address')){ $data['address'] = $this->input->post('address');}
            if($this->input->post('city')){ $data['city'] = $this->input->post('city');}
            if($this->input->post('state')){ $data['state'] = $this->input->post('state');}
            if($this->input->post('country')){ $data['country'] = $this->input->post('country');}
             if($this->input->post('company')){ $data['company'] = $this->input->post('company');}
             if($this->input->post('postal_code')){ $data['postal_code'] = $this->input->post('postal_code');}
            
            if($this->Users->updateCustomerInfo($data,$customer_id)){
            	$data['user_id']=$customer_id;
            	$data['type']='shipping';
            	$this->addressbook->save_address($data);
            	$this->session->set_flashdata('success','Profile is Successfully Updated');
			    redirect($last_url);

            }else{

              ///  $this->session->set_flashdata('error','Failled');
				//redirect(site_url('0/index/u/p/1dXA=user/Profile_/22/page/dXJfcHJvZmlsZS8v/Y'));
            }

           }else{

                echo $this->load->view('cart/add_address',$data,true);
           } 
           
        }
  }

  public function add_address_1()
  {
     if (!$this->Users->is_logged_in()){
          
           redirect('User/login');

        }else{
          $last_url = $_SERVER['HTTP_REFERER'];
           if($_SERVER['REQUEST_METHOD'] == 'POST'){

            $customer_id = $this->input->post('id');
            if($this->input->post('name')){ $data['name'] = $this->input->post('name'); }
            if($this->input->post('email')){ $data['email'] = $this->input->post('email');}
            if($this->input->post('contact')){ $data['phone'] = $this->input->post('contact');}
            if($this->input->post('address')){ $data['address'] = $this->input->post('address');}
            if($this->input->post('city')){ $data['city'] = $this->input->post('city');}
            if($this->input->post('state')){ $data['state'] = $this->input->post('state');}
            if($this->input->post('country')){ $data['country'] = $this->input->post('country');}
            if($this->input->post('company')){ $data['company'] = $this->input->post('company');}
            if($this->input->post('postal_code')){ $data['postal_code'] = $this->input->post('postal_code');}
            
            if($this->Users->updateCustomerInfo($data,$customer_id)){
              $data['user_id']=$customer_id;
              $data['type']='shipping';
              $this->addressbook->save_address($data);
              $this->session->set_flashdata('success','Profile is Successfully Updated');
          redirect($last_url);

            }else{

              ///  $this->session->set_flashdata('error','Failled');
        //redirect(site_url('0/index/u/p/1dXA=user/Profile_/22/page/dXJfcHJvZmlsZS8v/Y'));
            }

           }else{

                //$customer_id = $this->session->userdata('id'); 
                $this->load->view('common/imt/head'); 
                $this->load->view('user/add_address',$data);
           } 
           
        }
  }
  public function delete_address($address_id)
  {	
  	if (!$this->Users->is_logged_in()){
        	
       	  echo false;

        }else{
        	$this->addressbook->deleteaddress($address_id);
        	echo true;
        }


  }
  public function edit_address($address_id)
  {
  	 if (!$this->Users->is_logged_in()){
        	
       	  echo false;

        }else{

        	$last_url = $_SERVER['HTTP_REFERER'];
           if($_SERVER['REQUEST_METHOD'] == 'POST'){

            $customer_id = $this->input->post('id');
            if($this->input->post('name')){ $data['name'] = $this->input->post('name'); }
            if($this->input->post('email')){ $data['email'] = $this->input->post('email');}
             if($this->input->post('company')){ $data['company'] = $this->input->post('company');}
             if($this->input->post('postal_code')){ $data['postal_code'] = $this->input->post('postal_code');}
            if($this->input->post('contact')){ $data['phone'] = $this->input->post('contact');}
            if($this->input->post('address')){ $data['address'] = $this->input->post('address');}
            if($this->input->post('city')){ $data['city'] = $this->input->post('city');}
            if($this->input->post('state')){ $data['state'] = $this->input->post('state');}
            if($this->input->post('country')){ $data['country'] = $this->input->post('country');}

            
            if($this->Users->updateCustomerInfo($data,$customer_id)){
            	$data['user_id']=$customer_id;
            	$data['type']='shipping';
            	$this->addressbook->updateAddressInfo($data,$address_id);
            	$this->session->set_flashdata('success','Profile is Successfully Updated');
			    redirect($last_url);

            }else{

              ///  $this->session->set_flashdata('error','Failled');
				//redirect(site_url('0/index/u/p/1dXA=user/Profile_/22/page/dXJfcHJvZmlsZS8v/Y'));
            }

           }else{
           	 
           		$data['id_address']=$address_id;
                echo $this->load->view('cart/edit_address',$data,true);
           } 
           
        }
  }
/* ================FOR LOGOUT USER============== */    

	public function logout(){
	 
	   $this->session->sess_destroy();
	   redirect('Home');

	}   
	 public function delivery(){
        
        $data['product'] = $this->Product_model->ProductListBytype('1');
        $this->load->view('common/imt/head'); 
        $this->load->view('user/delivery',$data);
    }

}






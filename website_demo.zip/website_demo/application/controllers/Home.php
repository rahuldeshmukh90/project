<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function index()
	{
		
        $data['product'] = $this->Product_model->getAllproduct();
        //var_dump($data['product']->num_rows());die;
        $data['slider']=$this->db->get('sliderImages')->result();
        if($data['product']->num_rows()){
          
          $this->load->view('common/imt/head'); 
		      $this->load->view('index' ,$data);

        }else{
          
          redirect('Product');      
        }
	}

/*========= FOR ABOUT US =========*/ 	

    public function about_us(){
       $data['product'] = $this->Product_model->ProductListBytype('1');
 $this->load->view('common/imt/head'); 
      $this->load->view('page/about',$data);
    }

/*========= FOR ABOUT US =========*/ 	

    public function contact_us(){
      $data['contact']=$this->db->get('contact_info')->row();
      $this->load->view('common/imt/head'); 
      $this->load->view('page/contact',$data);
      
    }   
     public function blog(){
       $data['product'] = $this->Product_model->ProductListBytype('1');
       $this->load->view('common/imt/head'); 

      $this->load->view('page/blog',$data);
      
    }    
}

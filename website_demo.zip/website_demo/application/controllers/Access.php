<?php
/**
 * @author panacea-soft
 */
class Access extends CI_Controller
{
	function __construct($module_name = null)
	{
		
		parent::__construct();
		//If user has no permission, redirect to login.
		if (!$this->Users->is_logged_in()){ redirect(site_url('User')); }
		
		$logged_in_user_info = $this->Users->get_logged_in_user_info();
        $data['user_info'] = $logged_in_user_info;
        $this->load->vars($data);

	}
	
}
?>
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_Controller {

	public function index()
	{
		$this->load->view('common/imt/head');  
		$this->load->view('index');
	}

	public function items_list(){

       $getvalue = $_GET['D'];

       $filtterproduct = base64_decode($getvalue);
       $data['sucategory']=$sucategory=$this->Product_model->get_info_Subcategory($filtterproduct);
       $data['category']=$this->Product_model->get_info_Category($sucategory->category_id);
       $pag = $this->config->item('pagination');
       $pag['base_url'] = site_url('bGlzdC8=LIST?D='.$getvalue);
       $pag['total_rows'] = $this->Product_model->count_allBysubCategoryId($filtterproduct);
       $data['subproduct'] = $this->Product_model->ProductListBysubCategoryId($filtterproduct, $pag['per_page'], $_GET['GZEP']);
       $data['pag'] = $pag;
      
       
       if($data['subproduct']){
          
          $data['category_id']    = $sucategory->category_id;
          $data['subcategory_id'] = $filtterproduct;
          $data['color']         = $this->Product_model->getcolorBycategory($filtterproduct);
          $this->load->view('common/imt/head');  
          $this->load->view('product/items_list' ,$data);    	

       }else{
          
          redirect('Product');      
       }
	   

	}

  public function search_items(){
       
       
       $cid   = $_GET['cid'];
       $sid   = $_GET['sid']; 
       $color = $_GET['color']; 

       $getvalue = $_GET['D'];
       $filtterproduct = base64_decode($getvalue);

       $categoryId    = base64_decode($cid);
       $subcategoryId = base64_decode($sid);
       
       $data['sucategory']=$sucategory=$this->Product_model->get_info_Subcategory($subcategoryId);
       $data['category']=$this->Product_model->get_info_Category($sucategory->category_id);
       $pag = $this->config->item('pagination');
       $pag['base_url'] = site_url('bGlzdC8=LIST?D='.$sid);
       $pag['total_rows']  = $this->Product_model->count_allBycolor($subcategoryId,$color);

       $data['subproduct'] = $this->Product_model->ProductListBysubCategoryandColor($subcategoryId, $pag['per_page'], $_GET['GZEP'],$color);
       
       $data['pag'] = $pag;
      
      // echo "<pre>";
      // print_r($data); die;
       
       if($data['subproduct']){
          
          $data['category_id']    = $sucategory->category_id;
          $data['subcategory_id'] = $subcategoryId;
          $data['color']         = $this->Product_model->getcolorBycategory($subcategoryId);
           
          $this->load->view('common/imt/head');  
          $this->load->view('product/items_list' ,$data);     

       }else{
          
          redirect('Product');      
       }
     

  }

  public function filtter_brand(){
       
       
       $cid   = $_GET['cid'];
       $sid   = $_GET['sid']; 
       $brand = $_GET['brand']; 

       $getvalue = $_GET['D'];
       $filtterproduct = base64_decode($getvalue);

       $categoryId    = base64_decode($cid);
       $subcategoryId = base64_decode($sid);
       
       $data['sucategory']=$sucategory=$this->Product_model->get_info_Subcategory($subcategoryId);
       $data['category']=$this->Product_model->get_info_Category($sucategory->category_id);
       $pag = $this->config->item('pagination');
       $pag['base_url'] = site_url('bGlzdC8=LIST?D='.$sid);
       $pag['total_rows']  = $this->Product_model->count_allBybrand($subcategoryId,$brand);

       $data['subproduct'] = $this->Product_model->ProductListBysubCategoryIdandBrand($subcategoryId, $pag['per_page'], $_GET['GZEP'],$brand);
       
       $data['pag'] = $pag;
      
      // echo "<pre>";
      // print_r($data); die;
       
       if($data['subproduct']){
          
          $data['category_id']    = $sucategory->category_id;
          $data['subcategory_id'] = $subcategoryId;
          $data['color']         = $this->Product_model->getcolorBycategory($subcategoryId);
          $data['brand_v']       = $brand;
          $this->load->view('common/imt/head');  
          $this->load->view('product/items_list' ,$data);     

       }else{
          
          redirect('Product');      
       }
     

  }

  public function fiter_X_size(){
       
       
       $cid   = $_GET['cid'];
       $sid   = $_GET['sid']; 
       $size  = $_GET['size']; 

       $getvalue = $_GET['D'];
       $filtterproduct = base64_decode($getvalue);

       $categoryId    = base64_decode($cid);
       $subcategoryId = base64_decode($sid);
       
       $data['sucategory']=$sucategory=$this->Product_model->get_info_Subcategory($subcategoryId);
       $data['category']=$this->Product_model->get_info_Category($sucategory->category_id);
       $pag = $this->config->item('pagination');
       $pag['base_url'] = site_url('bGlzdC8=LIST?D='.$sid);
       $pag['total_rows']  = $this->Product_model->count_allBysize($subcategoryId,$size);

       $data['subproduct'] = $this->Product_model->ProductListBysubCategoryandSize($subcategoryId, $pag['per_page'], $_GET['GZEP'],$size);
       
       $data['pag'] = $pag;
      
      // echo "<pre>";
      // print_r($data); die;
       
       if($data['subproduct']){
          
          $data['category_id']    = $sucategory->category_id;
          $data['subcategory_id'] = $subcategoryId;
          $data['color']          = $this->Product_model->getcolorBycategory($subcategoryId);
          $data['size_v']         = $size; 
          $this->load->view('common/imt/head');  
          $this->load->view('product/items_list' ,$data);     

       }else{
          
          redirect('Product');      
       }
     

  }    

  public function items_searchlist(){
        
       $getvalue   = $_GET['D'];
       $sortname   = $_GET['SNA'];
       $sortprice  = $_GET['SPA'];
       $filtterproduct = base64_decode($getvalue);

       $data['sucategory'] = $sucategory=$this->Product_model->get_info_Subcategory($filtterproduct);
       $data['category']   = $this->Product_model->get_info_Category($sucategory->category_id);
       $pag = $this->config->item('pagination');
       $pag['base_url'] = site_url('c2VhcmNobGlzdC8=LIST?D='.$getvalue);
       $pag['total_rows'] = $this->Product_model->count_allBysubCategoryId($filtterproduct);
     if($sortname)
     {
        $sort='name '.base64_decode($sortname);
         $pag['base_url'] = site_url('c2VhcmNobGlzdC8=LIST?D='.$getvalue.'&SNA='.$sortname);
        if(base64_decode($sortname)=='asc')
          $data['sort']='Name, A to Z';
        else
          $data['sort']='Name, Z to A';
          $data['subproduct'] = $this->Product_model->ProductListBysubCategoryIdsort($filtterproduct,$sort, $pag['per_page'], $_GET['GZEP']);
     }
     elseif($sortprice)
     {
        $sort = 'price '.base64_decode($sortprice);
         $pag['base_url'] = site_url('c2VhcmNobGlzdC8=LIST?D='.$getvalue.'&SPA='.$sortprice);
         if(base64_decode($sortprice)=='asc')
          $data['sort']='Price, low to high';
         else
          
          $data['sort']='Price, high to low';
          $data['subproduct'] = $this->Product_model->ProductListBysubCategoryIdsort($filtterproduct,$sort, $pag['per_page'], $_GET['GZEP']);
     
     }else{

        $data['subproduct'] = $this->Product_model->ProductListBysubCategoryId($filtterproduct, $pag['per_page'], $_GET['GZEP']);
     }
   
    $data['pag'] = $pag;
      
       
       if($data['subproduct']){
          
          $this->load->view('common/imt/head');  
          $this->load->view('product/items_list' ,$data);     

       }else{
          
          redirect('Product');      
       }
     

  }

  public function featured_item(){
    
     
 
       $data['subproduct'] = $this->Product_model->ProductListBytype('2'); 
 
       if($data['subproduct']){
          
          $this->load->view('common/imt/head');  
          $this->load->view('product/items_list' ,$data);     

       }else{
          
          redirect('Product');      
       }
     

  }



	public function detail(){

    $productId         =  $_GET['ee'];
    $GetvalueofProduct = base64_decode($productId); 
    $data['product'] = $this->Product_model->getAllproduct();
    $data['row_data']  = $this->Product_model->productdetailById($GetvalueofProduct); 
    if($data['row_data']){
    	
       $this->load->view('common/imt/head');  	
       $this->load->view('product/detail',$data);	
    }else{
    	redirect('Product');   
    }
    }
      public function quickview(){

    $productId         =  $_GET['ee'];
    $GetvalueofProduct = base64_decode($productId); 
        
    $data['row_data']  = $this->Product_model->productdetailById($GetvalueofProduct); 
    if($data['row_data']){
      
      echo $this->load->view('common/imt/model',$data,true);    
      // $this->load->view('product/detail',$data); 
    }else{
      redirect('Product');   
    }
    }
  
  function getproduct_color(){

    $size       = $this->input->post('size');
    $product_id = $this->input->post('p_id');
    $colorData  = $this->Product_model->getproductColor($size,$product_id);
    echo json_encode($colorData); die;   
    
  
  }

  }

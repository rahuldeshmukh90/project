
    <div class="header-top">
        <div class="container">
            <div class="header_logo">
                <a href="<?php echo base_url();?>">
                <img class="logo img-responsive" src="<?php echo base_url(); ?>assets/img/websit.png" alt="Fashcod - Apparel Store">
                </a>
            </div>

            <div id="desktop_cart">
  <div class="blockcart cart-preview active" data-refresh-url="<?php echo base_url().'Cart/detail'; ?>">
    <div class="header blockcart-header dropdown js-dropdown">
      <a class="shopping-cart" rel="nofollow" href=""  data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <span class="hidden-sm-down">Cart</span>
        <span class="cart-products-count">
          <?php echo $this->cart->total_items(); ?>
        </span>
      </a>
      <div class="cart_block block exclusive dropdown-menu">
        <div class="block_content">
        <?php if ($cart = $this->cart->contents()){ ?>
          <div class="cart_block_list">
        <?php $grand_total=0; foreach ($cart as $item): ?> 
            <div class="cart-item">
              <div class="cart-image">
                <a href="#">
                  <img src="<?php echo IMAGE_URL; ?><?php echo $item['image']; ?>" alt="<?php echo $item['name']; ?>" style="width:85px;">
                </a>
              </div>
              <div class="cart-info">
                <span class="product-quantity"><?php echo $item['qty']; ?>
                  
                </span>x
                <span class="product-name">
                  <a href="#"><?php echo $item['name']; ?></a>
                </span>
                <span class="product-price">$<?php echo number_format($item['price'],2); ?></span>
                <a class = "remove-from-cart" rel= "nofollow" href= "<?php echo base_url();?>Cart/removeajax/<?php echo $item['rowid']; ?>" data-link-action= "delete-from-cart" data-id-product= "<?php echo $item['id']; ?>" data-id-product-attribute = "<?php echo $item['rowid']; ?>" ta-id-customization= "">&nbsp;</a></div></div>
                <?php $grand_total = $grand_total + $item['subtotal']; ?>
                      <?php endforeach; ?>         
                      </div>
                      <div class="card cart-summary">
                        <div class="card-block">
                          <div class="cart-summary-line" id="cart-subtotal-products">
                            <span class="label js-subtotal"> <?php echo $this->cart->total_items(); ?>items</span><span class="value">₹ <?php echo $grand_total; ?></span></div><div class="cart-summary-line" id="cart-subtotal-shipping"><span class="label">Shipping</span><span class="value">Free</span><div><small class="value"></small></div></div></div><div class="card-block"><div class="cart-summary-line cart-total"><span class="label">Total (tax excl.)</span><span class="value">₹ <?php echo $grand_total; ?></span></div><div class="cart-summary-line"><small class="label">Taxes</small><small class="value">₹ 0.00</small></div></div></div><div class="checkout card-block"><a rel="nofollow" href="<?php echo base_url();?>Cart/view_cart" class="viewcart">
              <button type="button" class="btn btn-primary">View Cart</button>
              </a>
            </div>
            <?php } else { ?>
                      <span class="no-items">There are no more items in your cart</span>
              
              <?php } ?>
          </div>
      </div>
    </div>
    </div>
  </div>
  <div class="user-info dropdown js-dropdown">
    <span class="user-info-title expand-more _gray-darker" data-toggle="dropdown"><span class="account_text">My Account</span></span>
    <ul class="dropdown-menu">
      <?php if($this->Users->is_logged_in()){ ?>
          <li>
              <a class="dropdown-item" href="<?php echo base_url(); ?>0/index/u/p/1dXA=user/Profile_/22/page/dXJfcHJvZmlsZS8v/Y" title="Log in to your customer account" rel="nofollow" > <span>Profile</span> </a>
          </li>
          <li>
            <a class="dropdown-item" href="<?php echo base_url(); ?>User/logout" title="Log in to your customer account" rel="nofollow" > <span>Sign out</span> </a>
          </li>
      <?php }else{ ?>
         <li>
              <a class="dropdown-item" href="<?php echo base_url(); ?>Access=login_451<?php echo base64_encode('lg-1'); ?>P" title="Log in to your customer account" rel="nofollow" > <span>Sign in</span> </a>
          </li>
          <li>
            <a class="dropdown-item" href="<?php echo base_url(); ?>User/registration" title="Log in to your customer account" rel="nofollow" > <span>Sign up</span> </a>
          </li>
      <?php } ?>     

        </ul>
  </div><!-- Block search module TOP -->
<div id="search_widget" class="col-lg-4 col-md-5 col-sm-12 search-widget" data-search-controller-url="#">
    <span class="search_button"></span>
    <div class="search_toggle">
        <form method="get" action="#">
            <input type="hidden" name="controller" value="search">
            <input type="text" name="s" value="" placeholder="Search our catalog">
            <button type="submit">
            </button>
        </form>
    </div>
</div>
<!-- /Block search module TOP -->
                    
        </div>
        
        
    </div>  
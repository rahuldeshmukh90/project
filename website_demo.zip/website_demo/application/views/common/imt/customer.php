<!-- The Modal -->
<div class="modal fade quickview" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
       <button type="button" class="close" data-dismiss="modal" aria-label="Close">
         <span aria-hidden="true">×</span>
       </button>
      </div>
      <div class="modal-body" >
        <div class="row">
          <div class="col-md-6 col-sm-6 hidden-xs-down">
            <div class="images-container">
              <div class="product-cover">
                <a href="#">
                  <img class="js-qv-product-cover product-image" src="" alt="" title="" style="width:100%;" itemprop="image">
                </a>
                <div class="layer hidden-sm-down" data-toggle="modal" data-target="#product-modal">
                  <i class="fa fa-arrows-alt zoom-in"></i>
                </div>
              </div>
               <div class="js-qv-mask mask additional_slider">     
                <ul class="cz-carousel product_list additional-carousel owl-carousel owl-theme" style="opacity: 1; display: block;">

                 <div class="owl-wrapper-outer">
                  <div class="owl-wrapper more_img" style="width: 1260px; left: 0px; display: block; transition: all 0ms ease;">
                    
              </div>
              </div>
              
              </ul>

                <div class="customNavigation">
                  <a class="btn prev additional_prev">&nbsp;</a>
                  <a class="btn next additional_next">&nbsp;</a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-6 col-sm-6">
            <h1 class="h1 product-name"></h1>
            <div class="product-prices">
              <div class="product-price h5 " itemprop="offers" itemscope="" itemtype="https://schema.org/Offer">
                <link itemprop="availability" href="#">
                <meta itemprop="priceCurrency" content="USD">
                <div class="current-price">
                  <span itemprop="price" class="pro_price" content="">₹</span>
                </div>
              </div>
              <div class="tax-shipping-delivery-label">
              </div>
            </div>
            <div id="product-description-short" itemprop="description"><p id="product_description"></p></div>
            <div class="product-actions">
              <form action="https://codezeel.com/prestashop/PRS06/PRS060129/index.php?controller=cart" method="post" id="add-to-cart-or-refresh">
                <input type="hidden" name="token" value="f6ea937a766343139d0cc27dc915cb03">
                <input type="hidden" name="id_product" value="1" id="product_page_product_id">
                <input type="hidden" name="id_customization" value="0" id="product_customization_id">
                <div class="product-variants">
                  <div class="clearfix product-variants-item">
                    <span class="control-label">Size</span>
                    <select id="group_1" data-product-attribute="1" name="group[1]">
                      <option value="1" title="S" selected="selected">S</option>
                      <option value="2" title="M">M</option>
                      <option value="3" title="L">L</option>
                    </select>
                  </div>
                  <div class="clearfix product-variants-item">
                    <span class="control-label">Color</span>
                    <ul id="group_3">
                      <li class="pull-xs-left input-container">
                        <input class="input-color" type="radio" data-product-attribute="3" name="group[3]" value="13" checked="checked">
                        <span class="color" style="background-color: #F39C11"><span class="sr-only">Orange</span></span>
                      </li>
                      <li class="pull-xs-left input-container">
                        <input class="input-color" type="radio" data-product-attribute="3" name="group[3]" value="15">
                        <span class="color" style="background-color: #A0D468"><span class="sr-only">Green</span></span>
                      </li>
                    </ul>
                  </div>
                </div>
                <div class="product-add-to-cart">
                  <div class="product-quantity">
                    <div class="qty">
                      <div class="input-group bootstrap-touchspin">
                        <span class="input-group-addon bootstrap-touchspin-prefix" style="display: none;"></span>
                        <input type="text" name="qty" id="quantity_wanted" value="1" class="input-group form-control" min="1" aria-label="Quantity" style="display: block;">
                        <span class="input-group-addon bootstrap-touchspin-postfix" style="display: none;"></span>
                        <span class="input-group-btn-vertical">
                          <button class="btn btn-touchspin js-touchspin bootstrap-touchspin-up" type="button">
                            <i class="material-icons touchspin-up"></i>
                          </button>
                          <button class="btn btn-touchspin js-touchspin bootstrap-touchspin-down" type="button"><i class="material-icons touchspin-down"></i>
                          </button>
                        </span>
                      </div>
                    </div>
                    <div class="add">
                      <button class="btn btn-primary add-to-cart" data-button-action="add-to-cart" type="submit">
                      Add to cart
                      </button>
                    </div>
                  </div>
                  <div class="clearfix"></div>
                  <p class="product-minimal-quantity">
                  </p>
                </div>
                <input class="product-refresh" data-url-update="false" name="refresh" type="submit" value="Refresh" hidden="">
              </form>
            </div>
            <div class="modal-footer">
              <div class="social-sharing">
                <span>Share</span>
                <ul>
                  <li class="facebook icon-gray"><a href="#" class="" title="Share" target="_blank">&nbsp;</a></li>
                  <li class="twitter icon-gray"><a href="#" class="" title="Tweet" target="_blank">&nbsp;</a></li>
                  <li class="googleplus icon-gray"><a href="#" class="" title="Google+" target="_blank">&nbsp;</a></li>
                  <li class="pinterest icon-gray"><a href="#" class="" title="Pinterest" target="_blank">&nbsp;</a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>            

    

<!-- The Modal -->
<div class="modal fade" id="blockcart-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  
    

      <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <a href="" class="close">
          <span aria-hidden="true">×</span>
        </a>
        <h4 class="modal-title h6 text-xs-center" id="myModalLabel">Product successfully added to your shopping cart</h4>
      </div>
      <div class="modal-body">
        <div class="row">
          <div class="col-md-6 divide-right">
            <div class="row">
              <div class="col-md-6">
                <img class="product-image" src="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/2/4/24-home_default.jpg" alt="" title="" itemprop="image">
              </div>
              <div class="col-md-6">
                <h6 class="h6 product-name">Consectetur Hampden</h6>
                <p >$<span class="pro_price">98.00</span></p>
                
                                  <span><strong>Size</strong>: S</span><br>
                                  <span><strong>Color</strong>: Orange</span><br>
                                <p><strong>Quantity:</strong>&nbsp;1</p>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="cart-content">
                              <p class="cart-products-count">There is 1 item in your cart.</p>
                            <p><strong>Total products:</strong>&nbsp;$<span class="pro_price">98.00</span></p>
              <p><strong>Total shipping:</strong>&nbsp;Free </p>
                                <p><strong>Taxes</strong>&nbsp;$0.00</p>
                            <p><strong>Total:</strong>&nbsp;$<span class="pro_price"></span> (tax excl.)</p>
              <!-- <a href="#" class="btn btn-secondary" data-dismiss="modal">Continue shopping</button> -->
              <a href="" class="btn btn-secondary">Continue shopping</a>
              <a href="#" class="btn btn-primary">Proceed to checkout</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

   
  
</div>


<div class="modal fade js-product-images-modal" id="product-modal">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-body">
                <figure>
          <img class="js-modal-product-cover product-cover-modal" width="701" src="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/3/0/30-large_default.jpg" alt="" title="" itemprop="image">
          <figcaption class="image-caption">
          
            <div id="product-description-short" itemprop="description"><p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias.</p></div>
          
        </figcaption>
        </figure>
        <aside id="thumbnails" class="thumbnails js-thumbnails text-xs-center">
          
            <div class="js-modal-mask mask ">
              <ul class="product-images js-modal-product-images" style="transform: translateY(-166.104px);">
                                  <li class="thumb-container">
                    <img data-image-large-src="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/3/1/31-large_default.jpg" class="thumb js-modal-thumb" src="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/3/1/31-home_default.jpg" alt="" title="" width="277" itemprop="image">
                  </li>
                                  <li class="thumb-container">
                    <img data-image-large-src="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/3/0/30-large_default.jpg" class="thumb js-modal-thumb" src="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/3/0/30-home_default.jpg" alt="" title="" width="277" itemprop="image">
                  </li>
                                  <li class="thumb-container">
                    <img data-image-large-src="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/3/2/32-large_default.jpg" class="thumb js-modal-thumb" src="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/3/2/32-home_default.jpg" alt="" title="" width="277" itemprop="image">
                  </li>
                                  <li class="thumb-container">
                    <img data-image-large-src="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/3/3/33-large_default.jpg" class="thumb js-modal-thumb" src="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/3/3/33-home_default.jpg" alt="" title="" width="277" itemprop="image">
                  </li>
                                  <li class="thumb-container">
                    <img data-image-large-src="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/3/4/34-large_default.jpg" class="thumb js-modal-thumb" src="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/3/4/34-home_default.jpg" alt="" title="" width="277" itemprop="image">
                  </li>
                                  <li class="thumb-container">
                    <img data-image-large-src="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/3/6/36-large_default.jpg" class="thumb js-modal-thumb" src="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/3/6/36-home_default.jpg" alt="" title="" width="277" itemprop="image">
                  </li>
                              </ul>
            </div>
          
                      <div class="arrows js-modal-arrows">
              <i class="material-icons arrow-up js-modal-arrow-up" style="opacity: 1;"></i>
              <i class="material-icons arrow-down js-modal-arrow-down" style="opacity: 0.2;"></i>
            </div>
                  </aside>
      </div>
    </div><!-- /.modal-content -->
  </div>
</div>

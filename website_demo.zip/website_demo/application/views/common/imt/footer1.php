<footer id="footer">
        
          <div class="footer-before">
    <div class="container">
        
            
<div class="block_newsletter links block" id="block_newsletter">
    <div class="container">
    <h4 class="title"><span class="news1">Subscribe to our newsletter and join our 23 subscribers.</span></h4>  

    <div class="block_content">
      <form action="" method="post">
          <div class="newsletter-form">
            <input
              class="btn btn-primary pull-xs-right hidden-xs-down"
              name="submitNewsletter"
              type="submit"
              value="Subscribe"
            >
            <input
              class="btn btn-primary pull-xs-right hidden-sm-up"
              name="submitNewsletter"
              type="submit"
              value="OK"
            >
            <div class="input-wrapper">
              <input
                name="email"
                type="text"
                value=""
                placeholder="Your email address"
              >
            </div>
            <input type="hidden" name="action" value="0">
            <div class="clearfix"></div>
          </div>
                  
            <div class="newsletter-message">
                            <p>You may unsubscribe at any moment. For that purpose, please find our contact info in the legal notice.</p>
                      </div>
      </form>
    </div>
    </div>
</div>

        
    </div>
</div>
<div class="footer-container">
  <div class="container">
    <div class="row footer">
        
            
<!-- Block payment logo module -->

<div class="block-social">
  <h3 class="block-social-title title"><span>Social</span></h3>
    <ul>
      <?php $social=$this->Social->getall(); 
      //var_dump($social->result()); ?>
      <?php foreach($social->result() as $val){?>
        <li <?php echo $val->icon; ?> ><a href="<?php echo $val->link; ?>" target="_blank"><span><?php echo $val->name; ?></span></a></li>
      <?php } ?>
             <!--  <li class="twitter"><a href="#" target="_blank"><span>Twitter</span></a></li>
              <li class="youtube"><a href="#" target="_blank"><span>YouTube</span></a></li>
              <li class="googleplus"><a href="#" target="_blank"><span>Google +</span></a></li>
              <li class="instagram"><a href="#" target="_blank"><span>Instagram</span></a></li> -->
          </ul>
  </div>
<!-- /Block payment logo module -->

  <div id="payement_logo_block_left" class="payement_logo_block">
    <!-- <h3 class="payement_logo title"><span>
        Payement
    </span></h3> -->
    <a href="">
        <img src="" alt="" width="" height="" />
        <img src="" alt="" width="" height="" />
        <img src="" width="" height="" />
        <img src="" width="" height="" />
        <img src="" alt="" width="" height="" />
        
    </a>
</div>

<div class="col-md-4 links block">
      <h3 class="h3 hidden-md-down">Products</h3>
            <div class="title h3 block_title hidden-lg-up" data-target="#footer_sub_menu_64988" data-toggle="collapse">
        <span class="">Products</span>
        <span class="pull-xs-right">
          <span class="navbar-toggler collapse-icons">
            <i class="fa-icon add"></i>
            <i class="fa-icon remove"></i>
          </span>
        </span>
      </div>
      <ul id="footer_sub_menu_64988" class="collapse block_content">
      
                  <li>
            <a
                id="link-product-page-new-products-1"
                class="cms-page-link"
                href="index6237.html?controller=new-products"
                title="Our new products">
              New products
            </a>
          </li>
                  <li>
            <a
                id="link-product-page-best-sales-1"
                class="cms-page-link"
                href="index7e4b.html?controller=best-sales"
                title="Our best sales">
              Best sales
            </a>
          </li>
                 <li>
            <a
                id="link-product-page-best-sales-1"
                class="cms-page-link"
                href="index7e4b.html?controller=best-sales"
                title="Our best sales">
              Featured
            </a>
          </li>

          <li>
            <a
                id="link-product-page-best-sales-1"
                class="cms-page-link"
                href="index7e4b.html?controller=best-sales"
                title="Our best sales">
              New Arrival
            </a>
          </li>

          <li>
            <a
                id="link-product-page-best-sales-1"
                class="cms-page-link"
                href="index7e4b.html?controller=best-sales"
                title="Our best sales">
              Best seller
            </a>
          </li>

          <li>
            <a
                id="link-product-page-best-sales-1"
                class="cms-page-link"
                href="index7e4b.html?controller=best-sales"
                title="Our best sales">
              Special Products </a>
          </li>

          

        
              </ul>
</div>
<div class="col-md-4 links block">
      <h3 class="h3 hidden-md-down">Our company</h3>
            <div class="title h3 block_title hidden-lg-up" data-target="#footer_sub_menu_51618" data-toggle="collapse">
        <span class="">Our company</span>
        <span class="pull-xs-right">
          <span class="navbar-toggler collapse-icons">
            <i class="fa-icon add"></i>
            <i class="fa-icon remove"></i>
          </span>
        </span>
      </div>
      <ul id="footer_sub_menu_51618" class="collapse block_content">
                  <li>
            <a
                id="link-cms-page-1-2"
                class="cms-page-link"
                href="<?php echo base_url(); ?>delivery<?php echo base64_encode('ab');?>0/1/6"
                title="Our terms and conditions of delivery">
              Delivery
            </a>
          </li>
                  <!-- <li>
            <a
                id="link-cms-page-2-2"
                class="cms-page-link"
                href="index0913.html?id_cms=2&amp;controller=cms&amp;id_lang=1"
                title="Legal notice">
              Legal Notice
            </a>
          </li> -->
                  <li>
            <a
                id="link-cms-page-4-2"
                class="cms-page-link"
                href="<?php echo base_url(); ?>about_us<?php echo base64_encode('ab');?>0/1/5"
                title="Learn more about us">
              About us
            </a>
          </li>
                  <!-- <li>
            <a
                id="link-cms-page-5-2"
                class="cms-page-link"
                href="indexac7f.html?id_cms=5&amp;controller=cms&amp;id_lang=1"
                title="Our secure payment method">
              Secure payment
            </a>
          </li> -->
                  <li>
            <a
                id="link-static-page-contact-2"
                class="cms-page-link"
                href="<?php echo base_url(); ?>0/6/c/n/1<?php echo base64_encode('cn');?>contact_us"
                title="Use our form to contact us">
              Contact us
            </a>
          </li>
              </ul>
</div>

<div class="block-contact col-md-4 links wrapper">

        <h3 class="text-uppercase block-contact-title hidden-sm-down"><a href="index11f6.html?controller=stores">Contact</a></h3>
      
        <div class="title clearfix hidden-md-up" data-target="#block-contact_list" data-toggle="collapse">
          <span class="h3">Store information</span>
          <span class="pull-xs-right">
              <span class="navbar-toggler collapse-icons">
                <i class="fa-icon add"></i>
                <i class="fa-icon remove"></i>
              </span>
          </span>
        </div>

       <ul id="block-contact_list" class="collapse">
      <li>
        <i class="fa fa-map-marker"></i>
        <span> S-2 Second Floor,Yashwant Plaza Opp.Railway station,Indore(M.P.)</span>
      </li>
              <li>
        <i class="fa fa-phone"></i>
        
        <span>0731 - 4281571</span>
        </li>
                    
                    <li>
        <i class="fa fa-envelope-o"></i>
        
        <span>info@impetrosys.com</span>
        </li>
          </ul>
  
</div>
        
    </div>      
    </div>
  </div>
</div>

<div class="footer-after">
  <div class="container">
  

    
    <div class="copyright">
      
          <a class="_blank" href="" target="_blank">
            © 2018 - Ecommerce
          </a>
      
    </div>
    
  </div>
</div>

<a class="top_button" href="#" style="">
    <i class="fa fa-angle-up" aria-hidden="true"></i>
</a>
        
      </footer>

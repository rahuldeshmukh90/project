 <div class="header-top-inner">
        <div class="container"> 
            
                

<div class="menu-wrapper">
    <div class="text-xs-left mobile hidden-lg-up mobile-menu">
        <div class="menu-icon">
            <div class="cat-title">Menu</div>         
        </div>
        
        <div id="mobile_top_menu_wrapper" class="row hidden-lg-up">
            <div class="mobile-menu-inner">
                <div class="menu-icon">
                    <div class="cat-title">Menu</div>         
                </div>
                <div class="js-top-menu mobile" id="_mobile_main_menu"></div>
                <div class="js-top-menu mobile" id="_mobile_top_menu"></div>
            </div>
        </div>
    </div>
    
     
    <div class="menu horizontal-menu col-lg-12 js-top-menu position-static hidden-md-down" id="_desktop_main_menu">
                  <ul class="top-menu  container" id="top-menu" data-depth="0">
                    <li class="link " id="lnk-home">
                          <a
                class="dropdown-item"
                href="<?php echo site_url(); ?>" data-depth="0"
                              >
                                Home
              </a>
                          </li>
                    <li class="cms-page " id="cms-page-1">
                          <a
                class="dropdown-item"
                href="<?php echo base_url(); ?>delivery<?php echo base64_encode('ab');?>0/1/6" data-depth="0"
                              >
                                Delivery
              </a>
                          </li>
                    <li class="cms-page " id="cms-page-4">
                          <a
                class="dropdown-item"
                href="<?php echo base_url(); ?>about_us<?php echo base64_encode('ab');?>0/1/5" data-depth="0"
                              >
                                About us
              </a>
                          </li>
                    <li class="link " id="lnk-blog">
                          <a
                class="dropdown-item"
                href="<?php echo base_url(); ?>0/6/c/n/1<?php echo base64_encode('bl');?>blog" data-depth="0"
                              >
                                Blog
              </a>
                          </li>
                    <li class="category " id="category-17">
                          <a
                class="dropdown-item"
                href="<?php echo base_url(); ?>0/7/f/p/r<?php echo base64_encode('fpr');?>featured" data-depth="0"
                              >
                                Featured
              </a>
                          </li>
                          <li class="category " id="category-17">
                          <a
                class="dropdown-item"
                href="<?php echo base_url(); ?>0/6/c/n/1<?php echo base64_encode('cn');?>contact_us" data-depth="0"
                              >
                               Contact
              </a>
                          </li>
                    
              </ul>
    
    </div>
</div>


<div class="menu vertical-menu js-top-menu position-static hidden-md-down">
    <div id="czverticalmenublock" class="block verticalmenu-block">        
        <h4 class="expand-more title h3 block_title" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" id="verticalmenu-dropdown">
            All Categories
            <span class="dropdown-arrow"></span>
        </h4>
        <div class="block_content verticalmenu_block dropdown-menu" aria-labelledby="verticalmenu-dropdown" id="_desktop_top_menu">
          <?php $category = $this->Product_model->getCategoryListlimit('50');  
       
                     foreach ($category->result() as $menus) { ?>
              <ul class="top-menu" id="top-menu" data-depth="0">
                <li class="category" id="czcategory-3">
                  <?php $subcategory = $this->Product_model->getSubcategoryBycatId($menus->id); 
              $value = sizeof($subcategory->result());  ?>

                  <a href="#" class="dropdown-item" data-depth="0" >
                     <?php if (($value)!=0) { ?>
                    <span class="pull-xs-right hidden-lg-up">
                      <span data-target="#top_sub_menu_98303" data-toggle="collapse" class="navbar-toggler collapse-icons">
                        <i class="fa-icon add">&nbsp;</i>
                        <i class="fa-icon remove">&nbsp;</i>
                      </span>
                    </span>
                    <span class="pull-xs-right sub-menu-arrow"></span>
                    <?php  } ?>
                     <?php echo $menus->name; ?>
                  </a>
                   <?php if (($value)!=0) { ?>
                  <div  class="popover sub-menu js-sub-menu collapse" id="top_sub_menu_98303"> 
                    <ul class="top-menu"  data-depth="1">
                        <?php foreach ($subcategory->result() as $subcatList) { ?>
                      <li class="category" id="czcategory-4">
                        <a href="<?php echo base_url(); ?><?php echo base64_encode('list/')?>LIST?D=<?php echo base64_encode($subcatList->id); ?>" class="" data-depth="1" >
                         <?php echo $subcatList->name; ?>
                        </a>
                        
                      </li>
                      <?php } ?> 
                      <!-- <li class="category" id="czcategory-5">
                        <a href="index3520.html?id_category=5&amp;controller=category&amp;id_lang=1" class="dropdown-item" data-depth="1" >Ethnic Wear
                        </a>
                      </li>
                      <li class="category" id="czcategory-6">
                        <a href="index7104.html?id_category=6&amp;controller=category&amp;id_lang=1" class="dropdown-item" data-depth="1" >Sports Wear
                        </a>
                      </li>
                      <li class="category" id="czcategory-7">
                        <a href="index5f1d.html?id_category=7&amp;controller=category&amp;id_lang=1" class="dropdown-item" data-depth="1" >Loungewear
                        </a>
                      </li>
                      <li class="category" id="czcategory-18">
                        <a href="index6c57.html?id_category=18&amp;controller=category&amp;id_lang=1" class="dropdown-item" data-depth="1" >Trousers
                        </a>
                      </li> -->
                     
                    </ul>
                   <!--  <div class="menu-images-container">
                      <img src="<?php echo base_url(); ?>assets/img/c/3-0_thumb.jpg">
                    </div> -->
                  </div>
                   <?php  } ?>
                </li>
               <!--  <li class="category" id="czcategory-12">
                  <a href="indexe734.html?id_category=12&amp;controller=category&amp;id_lang=1" class="dropdown-item" data-depth="0" >Electronics
                  </a>
                </li>
                <li class="category" id="czcategory-13">
                  <a href="indexd9ce.html?id_category=13&amp;controller=category&amp;id_lang=1" class="dropdown-item" data-depth="0" >Baby &amp; Kids</a>
                </li>
                <li class="category" id="czcategory-14">
                  <a href="indexf052.html?id_category=14&amp;controller=category&amp;id_lang=1" class="dropdown-item" data-depth="0" >Automobiles
                  </a>
                </li>
                <li class="category" id="czcategory-15">
                  <a href="indexb34f.html?id_category=15&amp;controller=category&amp;id_lang=1" class="dropdown-item" data-depth="0" >Jewellery
                  </a>
                </li>
                <li class="category" id="czcategory-16">
                  <a href="index63be.html?id_category=16&amp;controller=category&amp;id_lang=1" class="dropdown-item" data-depth="0" >Furniture
                  </a>
                </li>
                <li class="category" id="czcategory-9">
                  <a href="index038a.html?id_category=9&amp;controller=category&amp;id_lang=1" class="dropdown-item" data-depth="0" >Luggage &amp; Travel</a>
                </li>
                <li class="category" id="czcategory-11">
                  <a href="index9f26.html?id_category=11&amp;controller=category&amp;id_lang=1" class="dropdown-item" data-depth="0" >Handbags
                  </a>
                </li>
                <li class="category" id="czcategory-21">
                  <a href="indexd081.html?id_category=21&amp;controller=category&amp;id_lang=1" class="dropdown-item" data-depth="0" >Formal Shoes
                  </a>
                </li>
                <li class="category" id="czcategory-23">
                  <a href="index8447.html?id_category=23&amp;controller=category&amp;id_lang=1" class="dropdown-item" data-depth="0" >Sandles
                  </a>
                </li>
                <li class="category" id="czcategory-5">
                  <a href="index3520.html?id_category=5&amp;controller=category&amp;id_lang=1" class="dropdown-item" data-depth="0" >Ethnic Wear
                  </a>
                </li>
                <li class="category" id="czcategory-6">
                  <a href="index7104.html?id_category=6&amp;controller=category&amp;id_lang=1" class="dropdown-item" data-depth="0" >Sports Wear
                  </a>
                </li> -->
              </ul>
            <?php } ?>
        </div>
    </div>
</div>

            </div>
        </div>

<script src="<?php echo base_url(); ?>assets/themes/Fashcod/assets/cache/imagezoom.js"></script>

<script type="text/javascript" src="<?php echo base_url(); ?>assets/themes/Fashcod/assets/cache/bottom-9149e8.js" ></script>

<style type="text/css">
      
.thumb-image { width: 500px; }

.thumb-image > img { width: 100%; }

    </style>
      
<div class="row">
          <div class="col-md-6 col-sm-6 hidden-xs-down">
            <div class="images-container">
              <div class="product-cover">
                <a href="<?php echo IMAGE_URL; ?><?php echo $row_data->image; ?>">
                  <img class="js-qv-product-cover" src="<?php echo IMAGE_URL; ?><?php echo $row_data->image; ?>" alt="" title="" style="width:100%;" itemprop="image">
                </a>
                <div class="layer hidden-sm-down" data-toggle="modal" data-target="#product-modal">
                  <i class="fa fa-arrows-alt zoom-in"></i>
                </div>
              </div>
              <div class="js-qv-mask mask additional_slider">     
                <ul class="cz-carousel product_list additional-carousel owl-carousel owl-theme" style="opacity: 1; display: block;">

                 <div class="owl-wrapper-outer">
                  <div class="owl-wrapper" style="width: 1260px; left: 0px; display: block; transition: all 0ms ease;">
                    <div class="owl-item" style="width: 105px;">
                      <li class="thumb-container item">
                        <img class="thumb js-thumb selected " data-image-medium-src="<?php echo IMAGE_URL; ?><?php echo $row_data->image; ?>" data-image-large-src="<?php echo IMAGE_URL; ?><?php echo $row_data->image; ?>" src="<?php echo IMAGE_URL; ?><?php echo $row_data->image; ?>" alt="" title="" width="95" itemprop="image">
                      </li>
                    </div>
                    <?php $images=$this->Product_model->getAllImages($row_data->id); ?>
          <?php  foreach($images->result() as $img){?>
                    <div class="owl-item" style="width: 105px;">
                      <li class="thumb-container item">
                        <img class="thumb js-thumb " data-image-medium-src="<?php echo IMAGE_URL; ?><?php echo $img->image; ?>" data-image-large-src="<?php echo IMAGE_URL; ?><?php echo $img->image; ?>" src="<?php echo IMAGE_URL; ?><?php echo $img->image; ?>" alt="" title="" width="95" itemprop="image">
                      </li>
                    </div>
                    <?php } ?>
                    <!-- <div class="owl-item" style="width: 105px;">
                      <li class="thumb-container item">
                        <img class="thumb js-thumb  selected " data-image-medium-src="<?php echo IMAGE_URL; ?><?php echo $row_data->image; ?>" data-image-large-src="<?php echo IMAGE_URL; ?><?php echo $row_data->image; ?>" src="<?php echo IMAGE_URL; ?><?php echo $row_data->image; ?>" alt="" title="" width="95" itemprop="image">
                      </li>
                    </div>
                    <div class="owl-item" style="width: 105px;">
                      <li class="thumb-container item">
                        <img class="thumb js-thumb  selected " data-image-medium-src="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/2/4/24-medium_default.jpg" data-image-large-src="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/2/4/24-large_default.jpg" src="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/2/4/24-home_default.jpg" alt="" title="" width="95" itemprop="image">
                      </li>
                    </div>
                    <div class="owl-item" style="width: 105px;">
                      <li class="thumb-container item">
                        <img class="thumb js-thumb " data-image-medium-src="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/2/6/26-medium_default.jpg" data-image-large-src="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/2/6/26-large_default.jpg" src="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/2/6/26-home_default.jpg" alt="" title="" width="95" itemprop="image">
                      </li>
                    </div>
                    <div class="owl-item" style="width: 105px;">
                      <li class="thumb-container item">
                        <img class="thumb js-thumb " data-image-medium-src="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/2/8/28-medium_default.jpg" data-image-large-src="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/2/8/28-large_default.jpg" src="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/2/8/28-home_default.jpg" alt="" title="" width="95" itemprop="image">
                      </li>
                    </div>
                    <div class="owl-item" style="width: 105px;">
                      <li class="thumb-container item">
                        <img class="thumb js-thumb " data-image-medium-src="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/2/7/27-medium_default.jpg" data-image-large-src="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/2/7/27-large_default.jpg" src="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/2/7/27-home_default.jpg" alt="" title="" width="95" itemprop="image">
                      </li>
                    </div>
                    <div class="owl-item" style="width: 105px;">
                      <li class="thumb-container item">
                      <img class="thumb js-thumb " data-image-medium-src="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/2/9/29-medium_default.jpg" data-image-large-src="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/2/9/29-large_default.jpg" src="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/2/9/29-home_default.jpg" alt="" title="" width="95" itemprop="image">
                    </li>
                  </div> -->
                </div>
              </div>





                <div class="owl-controls clickable"><div class="owl-pagination"><div class="owl-page active"><span class=""></span></div><div class="owl-page"><span class=""></span></div></div></div></ul>

                <div class="customNavigation">
                  <a class="btn prev additional_prev">&nbsp;</a>
                  <a class="btn next additional_next">&nbsp;</a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-6 col-sm-6">
            <h1 class="h1"><?php echo $row_data->name; ?></h1>
            <div class="product-prices">
              <div class="product-price h5 " itemprop="offers" itemscope="" itemtype="https://schema.org/Offer">
                <link itemprop="availability" href="#">
                <meta itemprop="priceCurrency" content="USD">
                <div class="current-price">
                  <span itemprop="price" content="<?php echo $row_data->price; ?>">₹<?php echo $row_data->price; ?></span>
                </div>
              </div>
              <div class="tax-shipping-delivery-label">
              </div>
            </div>
            <div id="product-description-short" itemprop="description"><p><?php echo $row_data->description; ?></p></div>
            <div class="product-actions">
              <form action="https://codezeel.com/prestashop/PRS06/PRS060129/index.php?controller=cart" method="post" id="add-to-cart-or-refresh">
                <input type="hidden" name="token" value="f6ea937a766343139d0cc27dc915cb03">
                <input type="hidden" name="id_product" value="1" id="product_page_product_id">
                <input type="hidden" name="id_customization" value="0" id="product_customization_id">
                <div class="product-variants">
                  <div class="clearfix product-variants-item">
                    <span class="control-label">Size</span>
                    <select id="group_1" data-product-attribute="1" name="group[1]">
                      <option value="1" title="S" selected="selected">S</option>
                      <option value="2" title="M">M</option>
                      <option value="3" title="L">L</option>
                    </select>
                  </div>
                  <div class="clearfix product-variants-item">
                    <span class="control-label">Color</span>
                    <ul id="group_3">
                      <li class="pull-xs-left input-container">
                        <input class="input-color" type="radio" data-product-attribute="3" name="group[3]" value="13" checked="checked">
                        <span class="color" style="background-color: #F39C11"><span class="sr-only">Orange</span></span>
                      </li>
                      <li class="pull-xs-left input-container">
                        <input class="input-color" type="radio" data-product-attribute="3" name="group[3]" value="15">
                        <span class="color" style="background-color: #A0D468"><span class="sr-only">Green</span></span>
                      </li>
                    </ul>
                  </div>
                </div>
                <div class="product-add-to-cart">
                  <div class="product-quantity">
                    <div class="qty">
                      <div class="input-group bootstrap-touchspin">
                        <span class="input-group-addon bootstrap-touchspin-prefix" style="display: none;"></span>
                        <input type="text" name="qty" id="quantity_wanted" value="1" class="input-group form-control" min="1" aria-label="Quantity" style="display: block;">
                        <span class="input-group-addon bootstrap-touchspin-postfix" style="display: none;"></span>
                        <span class="input-group-btn-vertical">
                          <button class="btn btn-touchspin js-touchspin bootstrap-touchspin-up" type="button">
                            <i class="material-icons touchspin-up"></i>
                          </button>
                          <button class="btn btn-touchspin js-touchspin bootstrap-touchspin-down" type="button"><i class="material-icons touchspin-down"></i>
                          </button>
                        </span>
                      </div>
                    </div>
                    <div class="add">
                      <button class="btn btn-primary add-to-cart" data-button-action="add-to-cart" type="submit"> Add to cart </button>
                    </div>
                  </div>
                  <div class="clearfix"></div>
                  <p class="product-minimal-quantity">
                  </p>
                </div>
                <input class="product-refresh" data-url-update="false" name="refresh" type="submit" value="Refresh" hidden="">
              </form>
            </div>
            <div class="modal-footer">
              <div class="social-sharing">
                <span>Share</span>
                <ul>
                  <li class="facebook icon-gray"><a href="#" class="" title="Share" target="_blank">&nbsp;</a></li>
                  <li class="twitter icon-gray"><a href="#" class="" title="Tweet" target="_blank">&nbsp;</a></li>
                  <li class="googleplus icon-gray"><a href="#" class="" title="Google+" target="_blank">&nbsp;</a></li>
                  <li class="pinterest icon-gray"><a href="#" class="" title="Pinterest" target="_blank">&nbsp;</a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
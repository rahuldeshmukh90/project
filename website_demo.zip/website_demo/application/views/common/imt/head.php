<!doctype html>
<html lang="en">

  
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>
    
      
<meta charset="utf-8">


<meta http-equiv="x-ua-compatible" content="ie=edge">



  <title>Nexus - sales</title>
  <meta name="description" content="E-commerce">
  <meta name="keywords" content="">
    


<meta name="viewport" content="width=device-width, initial-scale=1">


<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="icon" type="<?php echo base_url(); ?>assets/image/vnd.microsoft.icon" href="img/favicon.png">
<link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url(); ?>assets/img/favicon.png">


<!-- Codezeel added -->
<link href="http://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800" rel="stylesheet">


    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/themes/Fashcod/assets/cache/theme-dc30fa.css" type="text/css" media="all">




  

  <script type="text/javascript">
        var ecommerce = {"cart":{"products":[],"totals":{"total":{"type":"total","label":"Total","amount":0,"value":"$0.00"},"total_including_tax":{"type":"total","label":"Total (tax incl.)","amount":0,"value":"$0.00"},"total_excluding_tax":{"type":"total","label":"Total (tax excl.)","amount":0,"value":"$0.00"}},"subtotals":{"products":{"type":"products","label":"Subtotal","amount":0,"value":"$0.00"},"discounts":null,"shipping":{"type":"shipping","label":"Shipping","amount":0,"value":"Free"},"tax":{"type":"tax","label":"Taxes","amount":0,"value":"$0.00"}},"products_count":0,"summary_string":"0 items","labels":{"tax_short":"(tax excl.)","tax_long":"(tax excluded)"},"id_address_delivery":0,"id_address_invoice":0,"is_virtual":false,"vouchers":{"allowed":0,"added":[]},"discounts":[],"minimalPurchase":0,"minimalPurchaseRequired":""},"currency":{"name":"US Dollar","iso_code":"USD","iso_code_num":"840","sign":"$"},"customer":{"lastname":null,"firstname":null,"email":null,"last_passwd_gen":null,"birthday":null,"newsletter":null,"newsletter_date_add":null,"ip_registration_newsletter":null,"optin":null,"website":null,"company":null,"siret":null,"ape":null,"outstanding_allow_amount":0,"max_payment_days":0,"note":null,"is_guest":0,"id_shop":null,"id_shop_group":null,"id_default_group":1,"date_add":null,"date_upd":null,"reset_password_token":null,"reset_password_validity":null,"id":null,"is_logged":false,"gender":{"type":null,"name":null,"id":null},"risk":{"name":null,"color":null,"percent":null,"id":null},"addresses":[]},"language":{"name":"English (English)","iso_code":"en","locale":"en-US","language_code":"en-us","is_rtl":"0","date_format_lite":"m\/d\/Y","date_format_full":"m\/d\/Y H:i:s","id":1},"page":{"title":"","canonical":null,"meta":{"title":"Fashcod - Apparel Store","description":"Shop powered by PrestaShop","keywords":"","robots":"index"},"page_name":"index","body_classes":{"lang-en":true,"lang-rtl":false,"country-US":true,"currency-USD":true,"layout-full-width":true,"page-index":true,"tax-display-disabled":true},"admin_notifications":[]},"shop":{"name":"Fashcod - Apparel Store","email":"sales@yourcompany.com","registration_number":"","long":false,"lat":false,"logo":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/img\/fashcod-apparel-store-logo-1530875978.jpg","stores_icon":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/img\/logo_stores.png","favicon":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/img\/favicon.ico","favicon_update_time":"1530875978","address":{"formatted":"Fashcod - Apparel Store<br>United States","address1":"","address2":"","postcode":"","city":"","state":null,"country":"United States"},"phone":"000-000-0000","fax":"123456"},"urls":{"base_url":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/","current_url":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/index.php","shop_domain_url":"","img_ps_url":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/img\/","img_cat_url":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/img\/c\/","img_lang_url":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/img\/l\/","img_prod_url":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/img\/p\/","img_manu_url":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/img\/m\/","img_sup_url":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/img\/su\/","img_ship_url":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/img\/s\/","img_store_url":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/img\/st\/","img_col_url":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/img\/co\/","img_url":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/themes\/Fashcod\/assets\/img\/","css_url":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/themes\/Fashcod\/assets\/css\/","js_url":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/themes\/Fashcod\/assets\/js\/","pic_url":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/upload\/","pages":{"address":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/index.php?controller=address","addresses":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/index.php?controller=addresses","authentication":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/index.php?controller=authentication","cart":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/index.php?controller=cart","category":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/index.php?controller=category","cms":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/index.php?controller=cms","contact":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/index.php?controller=contact","discount":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/index.php?controller=discount","guest_tracking":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/index.php?controller=guest-tracking","history":"<?php echo base_url(); ?>","identity":"<?php echo base_url(); ?>","index":"<?php echo base_url(); ?>","my_account":"<?php echo base_url(); ?>","order_confirmation":"<?php echo base_url(); ?>","order_detail":"<?php echo base_url(); ?>","order_follow":"<?php echo base_url(); ?>","order":"<?php echo base_url(); ?>","order_return":"<?php echo base_url(); ?>","order_slip":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/index.php?controller=order-slip","pagenotfound":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/index.php?controller=pagenotfound","password":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/index.php?controller=password","pdf_invoice":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/index.php?controller=pdf-invoice","pdf_order_return":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/index.php?controller=pdf-order-return","pdf_order_slip":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/index.php?controller=pdf-order-slip","prices_drop":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/index.php?controller=prices-drop","product":"<?php echo base_url(); ?>","search":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/index.php?controller=search","sitemap":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/index.php?controller=sitemap","stores":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/index.php?controller=stores","supplier":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/index.php?controller=supplier","register":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/index.php?controller=authentication&create_account=1","order_login":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/index.php?controller=order&login=1"},"theme_assets":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/themes\/Fashcod\/assets\/","actions":{"logout":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/index.php?mylogout="}},"configuration":{"display_taxes_label":false,"low_quantity_threshold":3,"is_b2b":false,"is_catalog":false,"show_prices":true,"opt_in":{"partner":true},"quantity_discount":{"type":"discount","label":"Discount"},"voucher_enabled":0,"return_enabled":0,"number_of_days_for_return":14},"field_required":[],"breadcrumb":{"links":[{"title":"Home","url":"<?php echo base_url(); ?>assets\/ecommerce\/PRS06\/PRS060129\/index.php"}],"count":1},"link":{"protocol_link":"<?php echo base_url(); ?>","protocol_content":""},"time":1531841710,"static_token":"f6ea937a766343139d0cc27dc915cb03","token":"3bb425fee4477aaf55481f1f6ccd1ec1"};
      </script>



  
  



    
  <meta property="og:type" content="product">
  <meta property="og:url" content="#">
  <meta property="og:title" content="Exercitat Virginia">
  <meta property="og:site_name" content="Fashcod - Apparel Store">
  <meta property="og:description" content="At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias.">
  <meta property="og:image" content="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/3/0/30-large_default.jpg">
  <meta property="product:pretax_price:amount" content="82.65">
  <meta property="product:pretax_price:currency" content="USD">
  <meta property="product:price:amount" content="82.65">
  <meta property="product:price:currency" content="USD">
  



    
  </head>

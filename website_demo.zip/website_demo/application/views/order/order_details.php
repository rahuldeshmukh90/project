<style type="text/css">
   .awidth{padding: 5px 15px;
    margin-bottom: 10px;
    text-decoration: none;
    width: 100%!important;}
   .info1{display: block;
    background: #fff;
    padding: 15px 20px;
    border: 1px solid #e5e5e5;}
</style>
<?php $this->load->view('common/imt/head'); ?>
<body id="order-detail" class="lang-en country-us currency-usd layout-full-width page-order-detail tax-display-disabled">
<main id="page">
<header id="header">
      <div class="header-banner">
      </div>
      <nav class="header-nav">
        <div class="container">
          <div class="left-nav">
          </div>
          <div class="right-nav">
          </div>
        </div>
      </nav>
      <!-- header-bot -->
      <?php $this->load->view('common/imt/header'); ?>
      <!-- //header-bot -->
      <!-- banner -->
      <?php $this->load->view('common/imt/navbar'); ?>
    </header>
    <aside id="notifications">
      <div class="container">
      </div>
    </aside>
    <nav data-depth="1" class="breadcrumb">
      <div class="container">
        <ol itemscope itemtype="#">
          
          <li itemprop="itemListElement" itemscope itemtype="#">
            <a itemprop="item" href="index.html">
              <span itemprop="name">Home</span>
            </a>
            <meta itemprop="position" content="1">
          </li>
          
        </ol>
      </div>
    </nav>


<section id="wrapper">
		 
		<div class="container">
		  <div id="columns_inner">
			  

			  
  <div id="content-wrapper">
    
    

  <section id="main">

    
      
        <header class="page-header">
          <h1>
  Order details
</h1>
        </header>
      
    

    
  <section id="content" class="page-content">
    
      
        
<aside id="notifications">
  <div class="container">
    
    
    
      </div>
</aside>
      
    
    
  
    <div id="order-infos">
      <div class="box">
          <div class="row">
            <div class="col-xs-9">
              <strong>
                Order Reference KIQELIOQM - placed on 08/11/2018
              </strong>
            </div>
                          <div class="col-xs-3 text-xsright">
                <a href="#" class="button-primary">Reorder</a>
              </div>
                        <div class="clearfix"></div>
          </div>
      </div>

      <div class="box">
          <ul>
            <li><strong>Carrier</strong> My carrier</li>
            <li><strong>Payment method</strong> Cash on delivery (COD)</li>

                          <li>
                <a href="#">
                  Download your invoice as a PDF file.
                </a>
              </li>
            
            
                      </ul>
      </div>
    </div>
  

  
    <section id="order-history" class="box">
      <h3>Follow your order's status step-by-step</h3>
      <table class="table table-striped table-bordered table-labeled hidden-xs-down">
        <thead class="thead-default">
          <tr>
            <th>Date</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
                      <tr>
              <td>08/11/2018</td>
              <td>
                <span class="label label-pill dark" style="background-color:#FF8C00">
                  Processing in progress
                </span>
              </td>
            </tr>
                  </tbody>
      </table>
      <div class="hidden-sm-up history-lines">
                  <div class="history-line">
            <div class="date">08/11/2018</div>
            <div class="state">
              <span class="label label-pill dark" style="background-color:#FF8C00">
                Processing in progress
              </span>
            </div>
          </div>
              </div>
    </section>
  

  
  
    <div class="addresses">
              <div class="col-lg-6 col-md-6 col-sm-6">
          <article id="delivery-address" class="box">
            <h4>Delivery address My Address</h4>
            <address>minakshi kumrawat<br>impetrosys<br>s-2 yashwant plaza indore<br>Indore, Alaska 45601<br>United States<br>8956325610</address>
          </article>
        </div>
      
      <div class="col-lg-6 col-md-6 col-sm-6">
        <article id="invoice-address" class="box">
          <h4>Invoice address My Address</h4>
          <address>minakshi kumrawat<br>impetrosys<br>s-2 yashwant plaza indore<br>Indore, Alaska 45601<br>United States<br>8956325610</address>
        </article>
      </div>
      <div class="clearfix"></div>
    </div>
  

  

  
          
  <div class="box hidden-sm-down">
    <table id="order-products" class="table table-bordered">
      <thead class="thead-default">
        <tr>
          <th>Product</th>
          <th>Quantity</th>
          <th>Unit price</th>
          <th>Total price</th>
        </tr>
      </thead>
              <tbody><tr>
          <td>
            <strong>
              <a>
                Consectetur Hampden - Size : S- Color : Orange
              </a>
            </strong><br>
                          Reference: product1<br>
                                  </td>
          <td>
                          1
                      </td>
          <td class="text-xsright">$98.00</td>
          <td class="text-xsright">$98.00</td>
        </tr>
            </tbody><tfoot>
                              <tr class="text-xsright line-products">
              <td colspan="3">Subtotal</td>
              <td>$98.00</td>
            </tr>
                                        <tr class="text-xsright line-shipping">
              <td colspan="3">Shipping and handling</td>
              <td>Free</td>
            </tr>
                                            <tr class="text-xsright line-total">
          <td colspan="3">Total</td>
          <td>$98.00</td>
        </tr>
      </tfoot>
    </table>
  </div>

  <div class="order-items hidden-md-up box">
          <div class="order-item">
        <div class="row">
          <div class="col-sm-5 desc">
            <div class="name">Consectetur Hampden - Size : S- Color : Orange</div>
                          <div class="ref">Reference: product1</div>
                                  </div>
          <div class="col-sm-7 qty">
            <div class="row">
              <div class="col-xs-4 text-smleft text-xsleft">
                $98.00
              </div>
              <div class="col-xs-4">
                                  1
                              </div>
              <div class="col-xs-4 text-xsright">
                $98.00
              </div>
            </div>
          </div>
        </div>
      </div>
      </div>
  <div class="order-totals hidden-md-up box">
                  <div class="order-total row">
          <div class="col-xs-8"><strong>Subtotal</strong></div>
          <div class="col-xs-4 text-xsright">$98.00</div>
        </div>
                        <div class="order-total row">
          <div class="col-xs-8"><strong>Shipping and handling</strong></div>
          <div class="col-xs-4 text-xsright">Free</div>
        </div>
                        <div class="order-total row">
      <div class="col-xs-8"><strong>Total</strong></div>
      <div class="col-xs-4 text-xsright">$98.00</div>
    </div>
  </div>

      

  
          <div class="box">
        <table class="table table-striped table-bordered hidden-sm-down">
          <thead class="thead-default">
            <tr>
              <th>Date</th>
              <th>Carrier</th>
              <th>Weight</th>
              <th>Shipping cost</th>
              <th>Tracking number</th>
            </tr>
          </thead>
          <tbody>
                          <tr>
                <td>08/11/2018</td>
                <td>My carrier</td>
                <td>-</td>
                <td>Free</td>
                <td>-</td>
              </tr>
                      </tbody>
        </table>
        <div class="hidden-md-up shipping-lines">
                      <div class="shipping-line">
              <ul>
                <li>
                  <strong>Date</strong> 08/11/2018
                </li>
                <li>
                  <strong>Carrier</strong> My carrier
                </li>
                <li>
                  <strong>Weight</strong> -
                </li>
                <li>
                  <strong>Shipping cost</strong> Free
                </li>
                <li>
                  <strong>Tracking number</strong> -
                </li>
              </ul>
            </div>
                  </div>
      </div>
      

  
    
  


  <section class="order-message-form box">
    <form action="#" method="post">

      <header>
        <h3>Add a message</h3>
        <p>If you would like to add a comment about your order, please write it in the field below.</p>
      </header>

      <section class="form-fields">

        <div class="form-group row">
          <label class="col-md-3 form-control-label">Product</label>
          <div class="col-md-5">
            <select name="id_product" class="form-control form-control-select">
              <option value="0">-- please choose --</option>
                              <option value="1">Consectetur Hampden - Size : S- Color : Orange</option>
                          </select>
          </div>
        </div>

        <div class="form-group row">
          <label class="col-md-3 form-control-label"></label>
          <div class="col-md-9">
            <textarea rows="3" name="msgText" class="form-control"></textarea>
          </div>
        </div>

      </section>

      <footer class="form-footer text-sm-center">
        <input type="hidden" name="id_order" value="13">
        <button type="submit" name="submitMessage" class="btn btn-primary form-control-submit">
          Send
        </button>
      </footer>

    </form>
  </section>

  

  </section>


    
      <footer class="page-footer">
        
  
    
  <a href="#" class="account-link">
    <i class="material-icons"></i>
    <span>Back to your account</span>
  </a>
  <a href="#" class="account-link">
    <i class="material-icons"></i>
    <span>Home</span>
  </a>

  

      </footer>
    

  </section>


    
  </div>


			  
		  </div>
        </div>

      </section>
      <?php $this->load->view('common/imt/footer1'); ?>

<script type="text/javascript" src="<?php echo base_url(); ?>assets/themes/Fashcod/assets/cache/bottom-9149e8.js" ></script>

<?php $this->load->view('common/imt/customer'); ?>
</main>
</body>

</html>

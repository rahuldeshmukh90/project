<body id="category" class="lang-en country-us currency-usd layout-left-column page-category tax-display-disabled category-id-5 category-ethnic-wear category-id-parent-4 category-depth-level-4">
<style type="text/css">ul li { display: inline; } #left-column a, #right-column a { color: black; }</style> 
    <main id="page">
        <header id="header">
            <div class="header-banner">
            </div>
            <nav class="header-nav">
                <div class="container">
                    <div class="left-nav">
                    </div>
                    <div class="right-nav">
                    </div>
                </div>
            </nav>
            <!-- header-bot -->
            <?php $this->load->view('common/imt/header'); ?>
            <!-- //header-bot -->
            <!-- banner -->
            <?php $this->load->view('common/imt/navbar'); ?>
        </header>
        <aside id="notifications">
            <div class="container">
            </div>
        </aside>
        <nav data-depth="4" class="breadcrumb">
            <div class="container">
                <ol itemscope itemtype="#">
                    <li itemprop="itemListElement" itemscope itemtype="#">
                        <a itemprop="item" href="<?php echo base_url(); ?>">
							<span itemprop="name">Home</span>
						</a>
                        <meta itemprop="position" content="1">
                    </li>
                    <li itemprop="itemListElement" itemscope itemtype="#">
                        <a itemprop="item" href="#">
							<span itemprop="name"><?php echo $category->name; ?></span>
						</a>
                        <meta itemprop="position" content="2">
                    </li>
                    <li itemprop="itemListElement" itemscope itemtype="#">
                        <a itemprop="item" href="#">
							<span itemprop="name"><?php echo $sucategory->name; ?></span>
						</a>
                        <meta itemprop="position" content="3">
                    </li>
                   <!--  <li itemprop="itemListElement" itemscope itemtype="#">
                        <a itemprop="item" href="#">
							<span itemprop="name">Ethnic Wear</span>
						</a>
                        <meta itemprop="position" content="4">
                    </li> -->
                </ol>
            </div>
        </nav>
        <section id="wrapper">
            <div class="container">
                <div id="columns_inner">
                    <div id="left-column" class="col-xs-12" style="width:24.4%">
                        <div class="block-categories block">
                            <h4 class="block_title hidden-md-down">
								<a href="#"><?php echo $sucategory->name; ?></a>
							</h4>
                            <h4 class="block_title hidden-lg-up" data-target="#block_categories_toggle" data-toggle="collapse">
								<a href="#"><?php echo $sucategory->name; ?></a>
								<span class="pull-xs-right">
									<span class="navbar-toggler collapse-icons">
										<i class="fa-icon add"></i>
										<i class="fa-icon remove"></i>
									</span>
								</span>
							</h4>
                            <div id="block_categories_toggle" class="block_content collapse">
                                <ul class="category-top-menu">
                                    <li> </li>
                                </ul>
                            </div>
                        </div>
                        <div id="search_filters_wrapper" class="hidden-md-down block">
                            <!-- hidden-sm-down -->
                            <div id="search_filter_controls" class="hidden-lg-up">
                                <!--  -->
                                <span id="_mobile_search_filters_clear_all"></span>
                                <button class="btn btn-secondary ok">
                                    <i class="material-icons">&#xE876;</i> OK
                                </button>
                            </div>
                            <div id="search_filters">
                                <h4 class="block_title"><?php if(!empty($color)){ echo "Filter By"; } ?></h4>
                                <div class="block_content">
                                    <div id="_desktop_search_filters_clear_all" class="hidden-md-down clear-all-wrapper">
                                        <!-- <button data-search-url="#">
                                            <i class="material-icons">&#xE14C;</i> Clear all
                                        </button> -->
                                    </div>
                                    <section class="facet">
                                        <?php $brand = $this->Product_model->getBrands($subcategory_id); ?>
                                        <?php if(!empty($brand)){ ?>
                                        <h1 class="h6 facet-title hidden-md-down">Brand <?php echo $brand_v; ?></h1>
                                        <div class="title hidden-lg-up" data-target="#facet_24736" data-toggle="collapse">
                                            <h1 class="h6 facet-title">Brand <?php echo $brand_v; ?></h1>
                                            <span class="pull-xs-right">
												<span class="navbar-toggler collapse-icons">
													<i class="fa-icon add"></i>
													<i class="fa-icon remove"></i>
												</span>
                                            </span>
                                        </div>
                                        
                                        <ul id="facet_24736" class="collapse">
                                            <?php foreach ( $brand as $brands ) { ?>
                                            
                                            <li>
                                                <label class="facet-label" for="facet_input_24736_5" style="background: #f2f2f2;padding: 0px 8px;">
                                                    
                                                    <a href="<?php echo base_url(); ?>product/filtter_brand?cid=<?php echo base64_encode($category_id);?>&sid=<?php echo base64_encode($subcategory_id); ?>&brand=<?php echo $brands->brand; ?>">

                                                    <span class="custom-radio">
                                                        <input type="radio" name="filtter_brand" <?php if(!empty($brand_v)){ if ($brand_v == $brands->brand ) { echo "checked"; }}?>
                                                        >
                                                        <span  class="ps-shown-by-js" ></span>
                                                    </span>
                                                    <?php echo $brands->brand; ?></a>
                                                </label>
                                            </li>

                                            <?php } ?>
                                        </ul>
                                        <?php } ?>
                                    </section>
                                    <section class="facet">
                                        <?php $size = $this->Product_model->getSizes($subcategory_id); ?>

                                        <?php if(!empty($size)){ ?>
                                        <h1 class="h6 facet-title hidden-md-down">Size</h1>
                                        <div class="title hidden-lg-up" data-target="#facet_24736" data-toggle="collapse">
                                            <h1 class="h6 facet-title">Size</h1>
                                            <span class="pull-xs-right">
                                                <span class="navbar-toggler collapse-icons">
                                                    <i class="fa-icon add"></i>
                                                    <i class="fa-icon remove"></i>
                                                </span>
                                            </span>
                                        </div>
                                        
                                        <ul id="facet_24736" class="collapse">
                                            <?php foreach ( $size as $sizes ) { ?>
                                            
                                            <li>
                                                <label class="facet-label" for="facet_input_24736_5" style="background: #f2f2f2;padding: 0px 8px;border-radius: 16px;">
                                                    
                                                    <a href="<?php echo base_url(); ?>product/fiter_X_size?cid=<?php echo base64_encode($category_id);?>&sid=<?php echo base64_encode($subcategory_id); ?>&size=<?php echo $sizes->product_size; ?>">

                                                    <span class="custom-radio">
                                                        <input type="radio" name="filtter_brand" <?php if(!empty($sizes)){ if ($size_v == $sizes->product_size ) { echo "checked"; }}?>
                                                        >
                                                        <span  class="ps-shown-by-js" ></span>
                                                    </span>
                                                    <?php echo $sizes->product_size; ?></a>
                                                </label>
                                            </li>

                                            <?php } ?>
                                        </ul>
                                        <?php } ?>
                                    </section>
                                    <section class="facet">
                                        <?php if(!empty($color)){ ?>
                                        <h1 class="h6 facet-title hidden-md-down">Color</h1>
                                        <div class="title hidden-lg-up" data-target="#facet_95632" data-toggle="collapse">
                                            <h1 class="h6 facet-title">Color</h1>
                                            <span class="pull-xs-right">
												<span class="navbar-toggler collapse-icons">
													<i class="fa-icon add"></i>
													<i class="fa-icon remove"></i>
												</span>
                                            </span>
                                        </div>
                                        <ul >
                                            <?php foreach($color as $colors ){ ?> 
                                            <li>
                                                
                                                    <span class="custom-checkbox">
                                                        <a href="<?php echo base_url(); ?>product/search_items?cid=<?php echo base64_encode($category_id);?>&sid=<?php echo base64_encode($subcategory_id); ?>&color=<?php echo $colors->product_color; ?>"><input id="facet_input_95632_6" data-search-url="#" type="checkbox"></a> 
                                                        <span class="color" style="background-color:<?php echo $colors->product_color; ?>"></span>
                                                        
                                                    </span>
                                                    
                                                
                                            </li>
                                            <?php }?>
                                            
                                        </ul>
                                        <?php } ?>        
                                    </section>
                                </div>
                            </div>
                        </div>
                        <div id="newproduct_block" class="block products-block">
                            <h4 class="block_title hidden-md-down">
								New products
							</h4>
                            <h4 class="block_title hidden-lg-up" data-target="#newproduct_block_toggle" data-toggle="collapse">
								New products
								<span class="pull-xs-right">
									<span class="navbar-toggler collapse-icons">
										<i class="fa-icon add"></i>
										<i class="fa-icon remove"></i>
									</span>
								</span>
							</h4>
                            <div id="newproduct_block_toggle" class="block_content  collapse">
                                <ul class="products">
                             <?php $i=-1;
                                $product= $this->Product_model->ProductListBytype('1');
                               foreach($product->result() as $products){  $i++; if($i<=3){?>
                            <li class="product_item">

                                <div class="product-miniature js-product-miniature" data-id-product="15" data-id-product-attribute="268" itemscope itemtype="#">
                                    <div class="product_thumbnail">

                                        <a href="<?php echo base_url(); ?>single_ProductDetail<?php echo base64_encode('pd1234'); ?>_page?ee=<?php echo base64_encode($products->id); ?>" class="thumbnail product-image">
                                            <img style="width:70px; height:55px;"
                                            src = "<?php echo IMAGE_URL; ?><?php echo $products->image; ?>"
                                            alt = "<?php echo $products->name; ?>"
                                            >
                                        </a>

                                    </div>

                                    <div class="product-info">
                                        <h1 class="h3 product-title" itemprop="name"><a href="<?php echo base_url(); ?>single_ProductDetail<?php echo base64_encode('pd1234'); ?>_page?ee=<?php echo base64_encode($products->id); ?>"><?php echo $products->name; ?></a></h1>
                                        <div class="product-price-and-shipping">
                                            <span itemprop="price" class="price">₹<?php echo $products->price; ?></span>
                                        </div>
                                        <div class="comments_note">
                                            <div class="product-reference">
                                            <label class="label">Product code: </label>
                                            <span itemprop="sku"><?php echo $products->code; ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>  
                            </li>
                            <?php } }?>
                        </ul>
                    </div>
                </div>
                <!-- Block categories module -->
                <div id="categories_blog_menu" class="block blog-menu">
                    <h4 class="block_title hidden-md-down">
					Blog Categories		</h4>
                    <h4 class="block_title hidden-lg-up" data-target="#categories_blog_toggle" data-toggle="collapse">
						Blog Categories			<span class="pull-xs-right">
							<span class="navbar-toggler collapse-icons">
								<i class="fa-icon add"></i>
								<i class="fa-icon remove"></i>
							</span>
						</span>
					</h4>
                    <div id="categories_blog_toggle" class="block_content  collapse">
                        <ul class="level1 tree dhtml ">
                            <li id="list_3" class=" ">
                                <a href="#">
									<span>Vestibulum consequat</span>
								</a>
                                <ul class="level2 ">
                                    <li id="list_4" class=" ">
                                        <a href="#">
											<span>Pellentesque condimentum</span>
										</a>
                                    </li>
                                    <li id="list_5" class=" ">
                                        <a href="#">
											<span>Suspendisse turpis</span>
										</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- /Block categories module -->
            </div>
                    <div id="content-wrapper" class="left-column col-xs-12 col-sm-8 col-md-9" style="width:75.6%">
                        <section id="main">
                            <input id="getCartLink" name="getCartLink" value="<?php echo base_url(); ?>Cart/add" type="hidden">
                            <input id="getTokenId" name="getTokenId" value="f6ea937a766343139d0cc27dc915cb03" type="hidden">
                            
                            <section id="products">
                                <div id="">
                                    <div id="js-product-list-top" class="products-selection">
                                        <div class="col-md-6 hidden-md-down total-products">
                                            <ul class="display hidden-xs grid_list">
                                                <li id="grid"><a href="#" title="Grid">Grid</a></li>
                                                <li id="list"><a href="#" title="Lista">Lista</a></li>
                                            </ul>
                                            <p>There are <?php echo $pag['total_rows']; ?>  products.</p>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="row sort-by-row">
                                                <span class="col-sm-3 col-md-3 hidden-sm-down sort-by">Sort by:</span>
                                                <div class="col-sm-9 col-xs-8 col-md-9 products-sort-order dropdown">
                                                    <a class="select-title" rel="nofollow" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        <?php if(isset($sort)){
                                                            echo $sort;
                                                        }else{ echo 'Relevance'; } ?>
													<i class="material-icons pull-xs-right">&#xE5C5;</i>
													</a>
                                                    <div class="dropdown-menu">
                                                        <a rel="nofollow" href="<?php echo base_url(); ?><?php echo base64_encode('searchlist/')?>LIST?D=<?php echo base64_encode($sucategory->id); ?>" class="select-list <?php if(!isset($sort)){ ?> current <?php } ?> ">
															Relevance
														</a>
                                                        <a rel="nofollow" href="<?php echo base_url(); ?><?php echo base64_encode('searchlist/')?>LIST?D=<?php echo base64_encode($sucategory->id); ?>&SNA=<?php echo base64_encode('asc')?>" class="select-list <?php if(isset($sort)){ if($sort=='Name, A to Z'){ ?> current <?php  } }  ?> ">
															Name, A to Z
														</a>
                                                        <a rel="nofollow" href="<?php echo base_url(); ?><?php echo base64_encode('searchlist/')?>LIST?D=<?php echo base64_encode($sucategory->id); ?>&SNA=<?php echo base64_encode('desc')?>" class="select-list <?php if(isset($sort)){ if($sort=='Name, Z to A'){ ?> current <?php  } }  ?> ">
															Name, Z to A
														</a>
                                                        <a rel="nofollow" href="<?php echo base_url(); ?><?php echo base64_encode('searchlist/')?>LIST?D=<?php echo base64_encode($sucategory->id); ?>&SPA=<?php echo base64_encode('asc')?>" class="select-list <?php if(isset($sort)){ if($sort=='Price, low to high'){ ?> current <?php  } }  ?>">
															Price, low to high
														</a>
                                                        <a rel="nofollow" href="<?php echo base_url(); ?><?php echo base64_encode('searchlist/')?>LIST?D=<?php echo base64_encode($sucategory->id); ?>&SPA=<?php echo base64_encode('desc')?>" class="select-list <?php if(isset($sort)){ if($sort=='Price, high to low'){ ?> current <?php  } }  ?>">
															Price, high to low
														</a>
                                                    </div>
                                                </div>
                                                <div class="col-sm-3 col-xs-4 hidden-lg-up filter-button">
                                                    <button id="search_filter_toggler" class="btn btn-secondary">
                                                        Filter
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-12 hidden-lg-up showing">
                                            Showing 1-12 of <?php echo $pag['total_rows']; ?>  item(s)
                                        </div>
                                    </div>
                                </div>
                                <div id="" class="hidden-sm-down">
                                    <section id="js-active-search-filters" class="hide">
                                    </section>
                                </div>
                                <div id="">
                                    <div id="js-product-list">
                                        <div class="products row">
                                            <ul class="product_list grid gridcount">
                                                <!-- removed product_grid-->
    <?php foreach ($subproduct->result() as $p_value) { ?>
    <li class="product_item col-xs-12 col-sm-6 col-md-6 col-lg-4">
    <div class="product-miniature js-product-miniature" data-id-product="12" data-id-product-attribute="220" itemscope itemtype="#">
    <div class="thumbnail-container">
    <a href="<?php echo base_url(); ?>single_ProductDetail<?php echo base64_encode('pd1234'); ?>_page?ee=<?php echo base64_encode($p_value->id); ?>" class="thumbnail product-thumbnail">
    <img
    src = "<?php echo IMAGE_URL; ?><?php echo $p_value->image; ?>"
    alt = "Reprehenderit aliquam"
    data-full-size-image-url = "<?php echo base_url(); ?>assets/img/p/9/2/92-large_default.jpg"
    >

    <img class="fliper_image img-responsive" src="<?php echo IMAGE_URL; ?><?php echo $p_value->image; ?>" data-full-size-image-url="<?php echo base_url(); ?>assets/img/p/9/2/92-large_default.jpg" alt="" />

    </a>
    <!-- <ul class="product-flags">
    <li class="new" style="background:#1d9dff;">New</li>
    </ul> -->
    <div class="outer-functional">
    <div class="functional-buttons">
    <a href="<?php echo base_url(); ?>single_ProductDetail<?php echo base64_encode('pd1234'); ?>_page?ee=<?php echo base64_encode($p_value->id); ?>" class="quick-view"  >
    <i class="material-icons search">&#xE417;</i> Quick view
    </a>
    <!-- <div class="product-actions">
    <form action="<?php echo base_url(); ?>Cart/add" method="post" class="add-to-cart-or-refresh">
    <input type="hidden" name="p_id" value="<?php echo $p_value->id; ?>" > 
    <input type="hidden" name="p_name" value="<?php echo $p_value->name; ?>" > 
    <input type="hidden" name="p_category" value="<?php echo $p_value->category_id; ?>" > 
    <input type="hidden" name="p_subcategoryId" value="<?php echo $p_value->subcategory_id; ?>" > 
    <input type="hidden" name="p_qty" value="1" > 
    <input type="hidden" name="p_price" value="<?php echo $p_value->price; ?>" >
    <input type="hidden" name="p_image" value="<?php echo $p_value->image; ?>" > 
    <?php $total_price = ($p_value->price)*(1); ?>
    <input type="hidden" name="p_total" value="<?php echo $total_price; ?>" > 
    <button class="btn btn-primary add-to-cart" data-button-action="add-to-cart" type="submit" >
    <span>Add to cart</span>
    </button>
    </form>
    </div> -->
    </div>
    </div>
    </div>
    <div class="product-description">
    <h3 class="h3 product-title" itemprop="name"><a href="<?php echo base_url(); ?>single_ProductDetail<?php echo base64_encode('pd1234'); ?>_page?ee=<?php echo base64_encode($p_value->id); ?>"><?php echo $p_value->name; ?></a></h3 >



    <div class="product-price-and-shipping">



    <span itemprop="price" class="price">₹<?php echo $p_value->price; ?></span>




    </div>




    <div class="product-detail" itemprop="description"><p><?php echo $p_value->description; ?></p></div>
    <div class="comments_note">
    <div class="product-reference">
    <label class="label">Product code: </label>
    <span itemprop="sku"><?php echo $p_value->code;?></span>
    </div>
    </div>

    <div class="highlighted-informations hidden-sm-down">


    <div class="variant-links">
    <a href="#"
    class="color"
    title="Black"

    style="background-color: #434A54" ><span class="sr-only">Black</span></a>
    <a href="#"
    class="color"
    title="Blue"

    style="background-color: #5D9CEC" ><span class="sr-only">Blue</span></a>
    <a href="#"
    class="color"
    title="Green"

    style="background-color: #A0D468" ><span class="sr-only">Green</span></a>
    <span class="js-count count"></span>
    </div>



    <span class="product-availability">
    <span class="product-available">
    <i class="material-icons">&#xE5CA;</i>
    In stock
    </span>
    </span>

    </div>

    </div>
    </div>
    </li>

    <?php } ?>
    <!-- <li class="product_item col-xs-12 col-sm-6 col-md-6 col-lg-4">

    <div class="product-miniature js-product-miniature" data-id-product="13" data-id-product-attribute="241" itemscope itemtype="http://schema.org/Product">
    <div class="thumbnail-container">

    <a href="index9863.html?id_product=13&amp;id_product_attribute=241&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/1-size-s/8-color-white" class="thumbnail product-thumbnail">
    <img
    src = "<?php echo base_url(); ?>assets/img/p/9/6/96-home_default.jpg"
    alt = "Laudant doloremque"
    data-full-size-image-url = "<?php echo base_url(); ?>assets/img/p/9/6/96-large_default.jpg"
    >

    <img class="fliper_image img-responsive" src="<?php echo base_url(); ?>assets/img/p/9/9/99-home_default.jpg" data-full-size-image-url="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/9/9/99-large_default.jpg" alt="" />

    </a>



    <ul class="product-flags">
    <li class="on-sale">On sale!</li>
    <li class="new">New</li>
    </ul>


    <div class="outer-functional">
    <div class="functional-buttons">

    <a href="#" class="quick-view" data-link-action="quickview">
    <i class="material-icons search">&#xE417;</i> Quick view
    </a>



    <div class="product-actions">
    <form action="https://codezeel.com/prestashop/PRS06/PRS060129/index.php?controller=cart" method="post" class="add-to-cart-or-refresh">
    <input type="hidden" name="token" id="tokenId" value="f6ea937a766343139d0cc27dc915cb03">
    <input type="hidden" name="id_product" value="13" class="product_page_product_id">
    <input type="hidden" name="id_customization" value="0" class="product_customization_id">
    <input type="hidden" name="qty" value="1">
    <button class="btn btn-primary add-to-cart" data-button-action="add-to-cart" type="submit" >
    <span>Add to cart</span>
    </button>
    </form>
    </div>


    </div>
    </div>
    </div>

    <div class="product-description">

    <h3 class="h3 product-title" itemprop="name"><a href="index9863.html?id_product=13&amp;id_product_attribute=241&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/1-size-s/8-color-white">Laudant doloremque</a></h3 >



    <div class="product-price-and-shipping">


    <span class="regular-price">$91.00</span>



    <span itemprop="price" class="price">$85.00</span>




    </div>




    <div class="product-detail" itemprop="description"><p>The brand offers feminine designs delivering stylish separates and statement dresses which has since evolved</p></div>



    <div class="comments_note">
    <div class="star_content clearfix">
    <div class="star"></div>
    <div class="star"></div>
    <div class="star"></div>
    <div class="star"></div>
    <div class="star"></div>
    </div>
    <span class="total-rating">0 Review(s)&nbsp</span>
    </div>

    <div class="highlighted-informations hidden-sm-down">


    <div class="variant-links">
    <a href="index7222.html?id_product=13&amp;id_product_attribute=235&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/3-size-l/8-color-white"
    class="color"
    title="White"

    style="background-color: #ffffff"           ><span class="sr-only">White</span></a>
    <a href="indexf601.html?id_product=13&amp;id_product_attribute=236&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/3-size-l/14-color-blue"
    class="color"
    title="Blue"

    style="background-color: #5D9CEC"           ><span class="sr-only">Blue</span></a>
    <a href="indexef55.html?id_product=13&amp;id_product_attribute=237&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/3-size-l/15-color-green"
    class="color"
    title="Green"

    style="background-color: #A0D468"           ><span class="sr-only">Green</span></a>
    <span class="js-count count"></span>
    </div>



    <span class="product-availability">
    <span class="product-available">
    <i class="material-icons">&#xE5CA;</i>
    In stock
    </span>
    </span>

    </div>

    </div>
    </div>
    </li> -->

    </ul>
    </div>



    <nav class="pagination">
    <div class="col-md-4">

    Showing 1-12 of <?php echo $pag['total_rows']; ?> item(s)

    </div>
    <div class="col-md-8">

    <!--<ul class="page-list clearfix text-xs-right">

    <li >
    <a
    rel="prev"
    href="#"
    class="previous disabled js-search-link"
    >
    <i class="fa fa-long-arrow-left"></i>
    </a>
    </li>

    <li  class="current" >
    <a
    rel="nofollow"
    href="#"
    class="disabled js-search-link"
    >
    1
    </a>
    </li>

    <li >
    <a
    rel="nofollow"
    href="#"
    class="js-search-link"
    >
    2
    </a>
    </li>

    <li >
    <a
    rel="next"
    href="#"
    class="next js-search-link"
    >
    <i class="fa fa-long-arrow-right"></i>
    </a>
    </li>
    </ul>
    -->
    <?php 

                $this->pagination->initialize($pag);

                echo $this->pagination->create_links();
            ?>
											</div>

										</nav>
									</div>

								</div>

								<div id="js-product-list-bottom">

									<div id="js-product-list-bottom"></div>

								</div>

							</section>

						</section>


					</div>



				</div>
			</div>

		</section>

<!-- footer -->
<?php $this->load->view('common/imt/footer1'); ?>
<!-- //footer -->
	</main>

	<script type="text/javascript" src="<?php echo base_url(); ?>assets/themes/Fashcod/assets/cache/bottom-9149e8.js" ></script>

	<?php $this->load->view('common/imt/customer'); ?>
</body>
</html>

<script src="<?php echo base_url(); ?>assets/themes/Fashcod/assets/cache/imagezoom.js"></script>
  <body id="product" class="lang-en country-us currency-usd layout-full-width page-product tax-display-disabled product-id-2 product-exercitat-virginia product-id-category-7 product-id-manufacturer-2 product-id-supplier-1 product-on-sale product-available-for-order" >

    <style type="text/css">
      .thumb-image { width: 500px; }

      .thumb-image > img { width: 100%; }
    </style>
    <main id="page">
      <header id="header">
        <div class="header-banner">
        </div>
        <nav class="header-nav">
  	      <div class="container">
            <div class="left-nav">
  				  </div>
  			    <div class="right-nav">
  			   	</div>
  		    </div>
        </nav>
        <!-- header-bot -->
        <?php $this->load->view('common/imt/header'); ?>
        <!-- //header-bot -->
        <!-- banner -->
        <?php $this->load->view('common/imt/navbar'); ?>
    
      </header>
      <aside id="notifications">
        <div class="container">
        </div>
      </aside>
      <nav data-depth="5" class="breadcrumb">
         <div class="container">
          <ol itemscope itemtype="#">
            <li itemprop="itemListElement" itemscope itemtype="#">
              <a itemprop="item" href="<?php echo base_url(); ?>">
                <span itemprop="name">Home</span>
              </a>
              <meta itemprop="position" content="1">
            </li>
            <li itemprop="itemListElement" itemscope itemtype="#">
              <a itemprop="item" href="#">
                <span itemprop="name"><?php echo $this->Product_model->get_info_Category($row_data->category_id)->name; ?></span>
              </a>
              <meta itemprop="position" content="2">
            </li>
            <li itemprop="itemListElement" itemscope itemtype="#">
              <a itemprop="item" href="#">
                <span itemprop="name"><?php echo $this->Product_model->get_info_Subcategory($row_data->subcategory_id)->name; ?></span>
              </a>
              <meta itemprop="position" content="3">
            </li>
            <li itemprop="itemListElement" itemscope itemtype="#">
              <a itemprop="item" href="#">
                <span itemprop="name"><?php echo $row_data->name; ?></span>
              </a>
              <meta itemprop="position" content="4">
            </li>
          </ol>
        </div>
      </nav>
<section id="wrapper">
	<div class="container">
	  <div id="columns_inner">
      <div id="content-wrapper">
        <section id="main" itemscope itemtype="#">
          <meta itemprop="url" content="#">
            <div class="row">
              <div class="pp-left-column col-xs-12 col-sm-5 col-md-5">
                <section class="page-content" id="content">
                  <div class="product-leftside">
			              <div class="images-container">
                      <div class="product-cover">
                        <a href='<?php echo IMAGE_URL; ?><?php echo $row_data->image; ?>'>
	                        <img class="js-qv-product-cover" src="<?php echo IMAGE_URL; ?><?php echo $row_data->image; ?>" alt="" title="" style="width:100%;max-height: 380px" itemprop="image" >
                        </a>
	                      <div class="layer hidden-sm-down" 
                            data-toggle="modal" data-target="#product-modal">
                          <i class="fa fa-arrows-alt zoom-in"></i>
                        </div>
                      </div>
                      <!-- Define Number of product for SLIDER -->
		                  <div class="js-qv-mask mask additional_slider">		
					              <ul class="cz-carousel product_list additional-carousel">
			                    <li class="thumb-container item">
                            <img class="thumb js-thumb selected"
                              data-image-medium-src="<?php echo IMAGE_URL; ?><?php echo $row_data->image; ?>"
                              data-image-large-src="<?php echo IMAGE_URL; ?><?php echo $row_data->image; ?>"
                              src="<?php echo IMAGE_URL; ?><?php echo $row_data->image; ?>" alt="" title=""
                              itemprop="image" style="min-width: 95px;min-height: 70px;max-width: 95px;max-height: 70px;" >
                          </li>
                          <?php $images=$this->Product_model->getAllImages($row_data->id); ?>
                          <?php  foreach($images->result() as $img){?>
                          <li class="thumb-container item">
                            <img class="thumb js-thumb"     data-image-medium-src="<?php echo IMAGE_URL; ?>   <?php echo "multiimage/".$img->image; ?>"
                              data-image-large-src="<?php echo IMAGE_URL; ?><?php echo "multiimage/".$img->image; ?>"
                              src="<?php echo IMAGE_URL; ?><?php echo "multiimage/".$img->image; ?>" alt=""
                              title="" width="95" itemprop="image" style="min-width: 95px;min-height: 70px;max-width: 95px;max-height: 70px;" >
                          </li>
                          <?php } ?>
                          
                        </ul>
	                      <div class="customNavigation">
                      	  <a class="btn prev additional_prev">&nbsp;</a>
                      		<a class="btn next additional_next">&nbsp;</a>
		                    </div>
	  	                </div>
                    </div>
              
            
			            </div>
                </section>
              </div>
		          <div class="pp-right-column col-xs-12  col-sm-7 col-md-7">
                <h1 class="h1 productpage_title" itemprop="name"><?php echo $row_data->name; ?></h1>
                   <!-- Codezeel added -->
		            <div class="product-reference">
                  <table>
                    <?php if(!empty($row_data->code)){ ?>
                    <tr>
                      <td style="min-width: 200px" ><label class="label"> Product code </label></td><td> :  <?php echo $row_data->code; ?></td>  
                    </tr>
                    <?php } ?>
                    
                    <?php if(!empty($row_data->brand)){ ?>
                    <tr>
                      <td style="min-width: 200px" ><label class="label"> Product Brand </label></td><td> : <?php echo $row_data->brand; ?></td>  
                    </tr>
                    <?php } ?>

                  </table> 
                </div>
                
			  		    <div class="product-information">
                  
                  <?php if(!empty($row_data->description)){ ?>
                  <div id="product-description-short-1" itemprop="description">
                    <label class="label"> Product Description: </label>
                    <p><?php echo substr($row_data->description,0,200); ?><a href="#description" data-toggle="tab"> More Detail</a></p>
                  </div>
                  <?php } ?>

                  <div class="product-actions">
                    <form action="<?php echo base_url(); ?>Cart/add" method="post" id="add-to-cart-or-refresh">
                      <input type="hidden" name="token" value="f6ea937a766343139d0cc27dc915cb03">
                      <input type="hidden" name="id_product" value="1" id="product_page_product_id">
                      <input type="hidden" name="id_customization" value="0" id="product_customization_id">
                      
                      <?php $atr = $this->Product_model->get_cs_attribute($row_data->id);?>
                      <?php if(!empty($atr)){ ?>
                      
                      <div style="max-width: 200px" >
                        
                          <label class="label"> Size </label>
                          <select class="form-control" name="size" id="size" onchange="getcolorv()">
                            
                            <option value="" >Select</option>
                            <?php foreach($atr->result() as $sizea ){ if ($sizea->product_size == "None" ) continue; ?> 
                            <option value="<?php echo $sizea->product_size; ?>"> <?php echo $sizea->product_size; ?></option><?php }?>

                          </select>     
                        
                      </div>
                      <br>
                      <?php } ?>
                      
                      <div id="color_fields" ></div>
                      <!-- <?php $fields = $this->Product_model->get_fields_by_product($row_data->id);?>
                      <div class="product-variants">
                          
                        <?php foreach($fields->result() as $attr){ ?>
                        <?php if($attr->attribute){?>
                        <div class="clearfix product-variants-item">
                            <span class="control-label"><?php echo $attr->attribute; ?></span>
                            <select  data-product-attribute="<?php echo $row_data->id; ?>" name="size">
                              <?php $attribute=$this->Product_model->get_attribute_by_product($row_data->id,$attr->attribute);?>
                              <?php foreach($attribute->result() as $attr1){
                                 ?>
                              <option value="<?php echo $attr1->attribute_value; ?>" title="<?php echo $attr1->attribute_value; ?>" selected="selected"><?php echo $attr1->attribute_value; ?></option>
                              <?php } ?>
                            </select>
                        </div>
                        <?php } else if($attr->attribute=='color'){?>
                        <div class="clearfix product-variants-item">
                          <span class="control-label">Color</span>
                          <ul >
                            <?php $attribute=$this->Product_model->get_attribute_by_product($row_data->id,$attr->attribute);?>
                            <?php foreach($attribute->result() as $attr1){
                                 ?>
                            <li class="pull-xs-left input-container">
                              <input class="input-color" type="radio" data-product-attribute="3" name="color" value="<?php echo $attr1->attribute_value; ?>" >
                              <span class="color" style="background-color: <?php echo $attr1->attribute_value; ?>">
                                <span class="sr-only">Orange</span>
                              </span>
                            </li>
                            <?php } ?>
                          </ul>
                        </div>
                        <?php } } ?>
                      </div> -->

                      <section class="product-discounts"></section>
                      <div class="product-prices">
                        <div class="product-price h5 " itemprop="offers" itemscope itemtype="#" >
                          <link itemprop="availability" href="#"/>
                            <meta itemprop="priceCurrency" content="USD">
                            <div class="current-price">
                              <span itemprop="price" content="<?php echo $row_data->price; ?>">₹<?php echo $row_data->price; ?></span>
                            </div>
                        </div>
                        <div class="tax-shipping-delivery-label"></div>
                      </div>
                      <div class="product-add-to-cart">
                        <!-- <span class="control-label">Quantity</span>-->
                        <div class="product-quantity">
                          <div class="qty">
                            <input type="text" name="p_qty" id="quantity_wanted" value="1" class="input-group" min="1"      aria-label="Quantity">
                          </div>
                          <div class="add">
                            <?php if(($row_data->quantity)>0){ ?> 

                            <input type="hidden" name="p_id" id="p_id" value="<?php echo $row_data->id; ?>" > 
                            <input type="hidden" name="p_name" value="<?php echo $row_data->name; ?>" > 
                            <input type="hidden" name="p_category" value="<?php echo $row_data->category_id; ?>" > 
                            <input type="hidden" name="p_subcategoryId" value="<?php echo $row_data->subcategory_id; ?>" > 
                            <input type="hidden" name="p_qty1" value="1" > 
                            <input type="hidden" name="p_price" value="<?php echo $row_data->price; ?>" > 
                            
                            <button class="btn btn-primary add-to-cart" data-button-action="add-to-cart" type="submit" > Add To Cart </button>
                            <?php }else{ ?> 
                              <a href="#" class="btn btn-danger" type="button" disabled>Out of stock </a>
                            <?php } ?>  
                          </div>
                        </div>
                        <div class="clearfix"></div>
                        <p class="product-minimal-quantity"></p>
                      </div>
                      <div class="product-additional-info">
                        <div class="social-sharing">
                          <span>Share</span>
                          <ul>
                            <li class="facebook icon-gray">
                              <a href="">&nbsp;</a>
                            </li>
                            <li class="twitter icon-gray">
                              <a href="#">&nbsp;</a>
                            </li>
                            <li class="googleplus icon-gray">
                              <a href="#">&nbsp;</a>
                            </li>
                            <li class="pinterest icon-gray">
                              <a href="#">&nbsp;</a>
                            </li>
                          </ul>
                        </div>
                      </div>
                      <input class="product-refresh ps-hidden-by-js" name="refresh" type="submit" value="Refresh">
                    </form>  
                  </div>

            
            	  

 			
        </div>
      </div>
    </div>
	
	
	  <section class="product-tabcontent">	
		  <div class="tabs">
        <ul class="nav nav-tabs">
          <li class="nav-item">
            <a class="nav-link active" data-toggle="tab" href="#description">Description</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#product-details">Product Details</a>
          </li>
        </ul>
        <div class="tab-content" id="tab-content">
          <div class="tab-pane fade in active" id="description">
            <div class="product-description"><p><b>Description :</b></p>
            <p><?php echo $row_data->description; ?></p></div>
          </div>
          
          <div class="tab-pane fade" id="product-details" data-product="">  
              <table class="table">
                 
              <?php $kk = $this->Product_model->getKey($row_data->id); ?>
              <?php foreach ($kk as $value) { ?>
                <tr>
                  <td><label class="label"><?php echo $value->attribute_key; ?></label></td><td><span itemprop="sku">: <?php echo $value->attribute_value; ?></span></td>
                </tr> 
              <?php } ?>
                <tr>
                  <td><label class="label">Product Type</label></td><td><span> : <?php if($row_data->type == "1"){ echo "New Arrival"; } if($row_data->type == "2"){ echo "Featured"; } if($row_data->type == "3"){ echo "Best Seller"; } ?>  </span>
                  </td>  
                </tr>
              </table>             
		            
          </div>

        </div>
      </div>
 	  </section>
	
    
               <!-- Define Number of product for SLIDER -->
				
		
          

    
      <section class="productscategory-products clearfix">
	<h2 class="h1 products-section-title text-uppercase">
			Other Products in the same category:
		</h2>
  	<div class="productscategory-wrapper">
	<div class="products">
		 <!-- Define Number of product for SLIDER -->
			<ul id="productscategory-carousel" class="cz-carousel product_list">
			  <?php  foreach($product->result() as $products){ ?>
                         
          <li class="item">

            <div class="product-miniature js-product-miniature" data-id-product="3" data-id-product-attribute="64" itemscope itemtype="#">
              <div class="thumbnail-container">

                <a href="<?php echo base_url(); ?>single_ProductDetail<?php echo base64_encode('pd1234'); ?>_page?ee=<?php echo base64_encode($products->id); ?>" class="thumbnail product-thumbnail">
                  <img
                  src = "<?php echo IMAGE_URL; ?><?php echo $products->image; ?>"
                  alt = "Accusantium doloremque"
                  data-full-size-image-url = "<?php echo base_url(); ?>assets/img/p/3/5/35-large_default.jpg"
                  >

                  <img class="fliper_image img-responsive" src="<?php echo IMAGE_URL; ?><?php echo $products->image; ?>" data-full-size-image-url="<?php echo base_url(); ?>assets/img/p/3/5/35-large_default.jpg" alt="" />

                </a>



                


                <div class="outer-functional">
                 <div class="functional-buttons">

                   <a href="<?php echo base_url(); ?>single_ProductDetail<?php echo base64_encode('pd1234'); ?>_page?ee=<?php echo base64_encode($products->id); ?>" class="quick-view" >
                    <i class="material-icons search" >&#xE417;</i> Quick view
                  </a>



                  <div class="">
                   
               </div>


             </div>
           </div>	
         </div>

         <div class="product-description">

          <span class="h3 product-title" itemprop="name"><a href="<?php echo base_url(); ?>single_ProductDetail<?php echo base64_encode('pd1234'); ?>_page?ee=<?php echo base64_encode($products->id); ?>"><?php echo $products->name; ?></a></span>



          <div class="product-price-and-shipping">



            <span itemprop="price" class="price">₹<?php echo $products->price; ?></span>

            

            
          </div>




           <div class="comments_note">
             <div class="product-reference">
        <label class="label">Product code: </label>
        <span itemprop="sku"><?php echo $products->code; ?></span>
        </div>
            
          </div> 

          <div class="highlighted-informations hidden-sm-down">


            <div class="variant-links">
              <a href="#"
              class="color"
              title="Black"

              style="background-color: #434A54"  ><span class="sr-only">Black</span></a>
              <a href="#"
              class="color"
              title="Blue"

              style="background-color: #5D9CEC"  ><span class="sr-only">Blue</span></a>
              <a href="#" class="color" title="Green" style="background-color: #A0D468"  ><span class="sr-only">Green</span></a>
              <span class="js-count count"></span>
            </div>

          </div>
        </div>
      </div>

    </li>
    <?php } ?>
  </ul>
		
			<div class="customNavigation">
				<a class="btn prev productscategory_prev">&nbsp;</a>
				<a class="btn next productscategory_next">&nbsp;</a>
			</div>
				
	</div>
	</div>
</section>

<script type="text/javascript">
    var productcomments_controller_url = 'index0260.html?fc=module&amp;module=productcomments&amp;controller=default&amp;id_lang=1';
    var confirm_report_message = 'Are you sure that you want to report this comment?';
    var secure_key = 'f64af7569159c3d66b6e6b39f929d309';
    var productcomments_url_rewrite = '0';
    var productcomment_added = 'Your comment has been added!';
    var productcomment_added_moderation = 'Your comment has been submitted and will be available once approved by a moderator.';
    var productcomment_title = 'New comment';
    var productcomment_ok = 'OK';
    var moderation_active = 1;
</script>


    

    
      <div class="modal fade js-product-images-modal" id="product-modal">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-body">
                <figure>
                <img class="js-modal-product-cover product-cover-modal" width="701" src="<?php echo IMAGE_URL; ?><?php echo $row_data->image; ?>" alt="" title="" itemprop="image">
                <figcaption class="image-caption">
                
                  <div id="product-description-short" itemprop="description"><p><?php echo $row_data->description; ?></p></div>
                </figcaption>
                </figure>
                <aside id="thumbnails" class="thumbnails js-thumbnails text-xs-center">
                    <div class="js-modal-mask mask ">
                      <ul class="product-images js-modal-product-images">
                          <li class="thumb-container">
                            <img data-image-large-src="<?php echo IMAGE_URL; ?><?php echo $row_data->image; ?>" class="thumb js-modal-thumb" src="<?php echo IMAGE_URL; ?><?php echo $row_data->image; ?>" alt="" title="" width="277" itemprop="image">
                          </li>
                          <?php $images=$this->Product_model->getAllImages($row_data->id); ?>
                          <?php  foreach($images->result() as $img){?>
                            <li class="thumb-container">
                              <img data-image-large-src="<?php echo IMAGE_URL; ?><?php echo "multiimage/".$img->image; ?>" class="thumb js-modal-thumb" src="<?php echo IMAGE_URL; ?><?php echo "multiimage/".$img->image; ?>" alt="" title="" width="277" itemprop="image">
                            </li>
                          <?php } ?> 
                      </ul>
                    </div>
                    <div class="arrows js-modal-arrows">
                      <i class="material-icons arrow-up js-modal-arrow-up">&#xE5C7;</i>
                      <i class="material-icons arrow-down js-modal-arrow-down">&#xE5C5;</i>
                    </div>
                </aside>
            </div>
          </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
      </div><!-- /.modal -->
    
</section>

</div>

</div>
        </div>

    </section>
    <?php $this->load->view('common/imt/footer1'); ?>
    </main>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/themes/Fashcod/assets/cache/bottom-9149e8.js" ></script>
    <?php $this->load->view('common/imt/customer'); ?>
    <script type="text/javascript">
       
       function getcolorv(){
       
       var size = $('#size').val();
       var p_id = $('#p_id').val(); 
           

          $.ajax({    
            
            type     : "POST",
            url      : "<?php echo base_url(); ?>product/getproduct_color",
            data: {'size':size,'p_id': p_id },             
            dataType : "json",   
            success: function(response){ 

                var html =''; 
                for(x in response){
                   
                  html +='<span style="border:1px solid grey;padding:9px;background-color:'+response[x].product_color+';margin-left:1px"><span class="color" style="border: 1px solid '+response[x].product_color+';background-color:'+response[x].product_color+'"></span><input id="color" name="color" value="'+response[x].product_color+'" type="radio"></span>&nbsp;&nbsp;';
                }
                
                $('body #color_fields').html(html);
            }

          });
          
       }

    </script>
  </body>



</html>
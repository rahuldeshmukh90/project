
<body id="authentication" class="lang-en country-us currency-usd layout-left-column page-authentication tax-display-disabled page-customer-account">





  <main id="page">



    <header id="header">


      <div class="header-banner">

      </div>



      <nav class="header-nav">
        <div class="container">


          <div class="left-nav">

          </div>

          <div class="right-nav">

          </div>




        </div>
      </nav>
      <!-- header-bot -->
      <?php $this->load->view('common/imt/header'); ?>
      <!-- //header-bot -->
      <!-- banner -->
      <?php $this->load->view('common/imt/navbar'); ?>

    </header>



    <aside id="notifications">
      <div class="container">



      </div>
    </aside>


    
    <nav data-depth="1" class="breadcrumb">
     <div class="container">
      <ol itemscope itemtype="#">

        <li itemprop="itemListElement" itemscope itemtype="#">
          <a itemprop="item" href="index.html">
            <span itemprop="name">Home</span>
          </a>
          <meta itemprop="position" content="1">
        </li>

      </ol>
    </div>
  </nav>


  <section id="wrapper">

    <div class="container">
      <div id="columns_inner">

        <div id="left-column" class="col-xs-12" style="width:24.4%">



          <div class="block-categories block">
           <h4 class="block_title hidden-md-down">
            <a href="#">Home</a>
          </h4>
          <h4 class="block_title hidden-lg-up" data-target="#block_categories_toggle" data-toggle="collapse">
            <a href="#">Home</a>
            <span class="pull-xs-right">
              <span class="navbar-toggler collapse-icons">
                <i class="fa-icon add"></i>
                <i class="fa-icon remove"></i>
              </span>
            </span>
          </h4>
          <div id="block_categories_toggle" class="block_content collapse">
           <ul class="category-top-menu">
            <li>
              <ul class="category-sub-menu">
                <?php $category = $this->Product_model->getCategoryListlimit('8');  

                foreach ($category->result() as $menus) { ?>
                <li data-depth="0">
                  <?php $subcategory = $this->Product_model->getSubcategoryBycatId($menus->id); 
                  $value = sizeof($subcategory->result());  ?>

                  <a href="#"><?php echo $menus->name; ?></a>
                  <?php if (($value)!=0) { ?>
                  <div class="navbar-toggler collapse-icons" data-toggle="collapse" data-target="#exCollapsingNavbar<?php echo $menus->id; ?>">
                    <span class="add"></span>
                    <span class="remove"></span>
                  </div>
                  <?php  } ?>
                  <?php if (($value)!=0) { ?>
                  <div class="collapse" id="exCollapsingNavbar<?php echo $menus->id; ?>">
                    <ul class="category-sub-menu">
                      <?php foreach ($subcategory->result() as $subcatList) { ?>
                      <li data-depth="1">
                        <a href="<?php echo base_url(); ?><?php echo base64_encode('list/')?>LIST?D=<?php echo base64_encode($subcatList->id); ?>"> <?php echo $subcatList->name; ?></a>


                      </li>
                      <?php } ?> 
                    </ul>
                  </div>
                  <?php } ?> 
                </li>
                <?php } ?> 
                  <!-- <li data-depth="0"><a href="indexe734.html?id_category=12&amp;controller=category&amp;id_lang=1">Electronics</a></li>
                  <li data-depth="0"><a href="indexd9ce.html?id_category=13&amp;controller=category&amp;id_lang=1">Baby &amp; Kids</a></li>
                  <li data-depth="0"><a href="indexf052.html?id_category=14&amp;controller=category&amp;id_lang=1">Automobiles</a></li>
                  <li data-depth="0"><a href="indexb34f.html?id_category=15&amp;controller=category&amp;id_lang=1">Jewellery</a></li>
                  <li data-depth="0"><a href="index63be.html?id_category=16&amp;controller=category&amp;id_lang=1">Furniture</a></li>
                  <li data-depth="0"><a href="indexcd48.html?id_category=17&amp;controller=category&amp;id_lang=1">Featured</a></li> -->
                </ul>
              </li>
            </ul>
          </div>
        </div>

        <div id="czleftbanner">
          <ul>
            <li class="slide czleftbanner-container">
              <a href="#" title="LeftBanner 1">
                <img src="<?php echo base_url(); ?>assets/modules/cz_leftbanner/views/img/left-banner-1.jpg" alt="LeftBanner 1" title="LeftBanner 1" />
              </a>        
            </li>
          </ul>
        </div>      

        <div id="newproduct_block" class="block products-block">
          <h4 class="block_title hidden-md-down">
            New products
          </h4>
          <h4 class="block_title hidden-lg-up" data-target="#newproduct_block_toggle" data-toggle="collapse">
            New products
            <span class="pull-xs-right">
              <span class="navbar-toggler collapse-icons">
                <i class="fa-icon add"></i>
                <i class="fa-icon remove"></i>
              </span>
            </span>
          </h4>
          <div id="newproduct_block_toggle" class="block_content  collapse">

            <ul class="products">
              <?php $i=-1;
              $product= $this->Product_model->ProductListBytype('1');
              foreach($product->result() as $products){  $i++; if($i<=3){?>
              <li class="product_item">

                <div class="product-miniature js-product-miniature" data-id-product="15" data-id-product-attribute="268" itemscope itemtype="#">
                  <div class="product_thumbnail">

                    <a href="<?php echo base_url(); ?>single_ProductDetail<?php echo base64_encode('pd1234'); ?>_page?ee=<?php echo base64_encode($products->id); ?>" class="thumbnail product-image">
                      <img style="width:85px; height:97px;"
                      src = "<?php echo IMAGE_URL; ?><?php echo $products->image; ?>"
                      alt = "<?php echo $products->name; ?>"
                      >
                    </a>

                  </div>

                  <div class="product-info">

                    <h1 class="h3 product-title" itemprop="name"><a href="<?php echo base_url(); ?>single_ProductDetail<?php echo base64_encode('pd1234'); ?>_page?ee=<?php echo base64_encode($products->id); ?>"><?php echo $products->name; ?></a></h1>



                    <div class="product-price-and-shipping">



                      <span itemprop="price" class="price">$<?php echo $products->price; ?></span>




                    </div>


                    <div class="comments_note">
                      <div class="star_content clearfix">
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                        <div class="star"></div>
                      </div>
                      <span class="total-rating">0 Review(s)&nbsp</span>
                    </div>


                  </div>
                </div>  


              </li>

              <?php } }?>
            </ul>

            <div class="view_more">
              <a class="all-product-link btn btn-primary" href="#">
                All new products
              </a>
            </div>

          </div>
        </div>


        <!-- Block categories module -->
        <div id="categories_blog_menu" class="block blog-menu">
          <h4 class="block_title hidden-md-down">
          Blog Categories   </h4>
          <h4 class="block_title hidden-lg-up" data-target="#categories_blog_toggle" data-toggle="collapse">
            Blog Categories     <span class="pull-xs-right">
              <span class="navbar-toggler collapse-icons">
                <i class="fa-icon add"></i>
                <i class="fa-icon remove"></i>
              </span>
            </span>
          </h4>
          <div id="categories_blog_toggle" class="block_content  collapse">
            <ul class="level1 tree dhtml "><li id="list_3" class=" "><a href="#" title="Vestibulum consequat"><span>Vestibulum consequat</span></a> <ul class="level2 "><li id="list_4" class=" "><a href="#" title="Pellentesque condimentum"><span>Pellentesque condimentum</span></a> </li><li id="list_5" class=" "><a href="#" title="Suspendisse turpis"><span>Suspendisse turpis</span></a> </li></ul></li></ul>
          </div>
        </div>
        <!-- /Block categories module -->

      </div>



      <div id="content-wrapper" class="left-column col-xs-12 col-sm-8 col-md-9" style="width:75.6%">



        <section id="main">



          <header class="page-header">
            <h1>
              Log in to your account
            </h1>
          </header>




          <section id="content" class="page-content card card-block">



            <section class="login-form">





              <form id="login-form" action="<?php echo base_url(); ?>Access=login_451<?php echo base64_encode('lg-1'); ?>P" method="post">

                <section>




                  <input type="hidden" name="back" value="my-account">




                  

                  <div class="form-group row ">
                    <label class="col-md-3 form-control-label required">
                      Username
                    </label>
                    <div class="col-md-6">

                     <input class="form-control" name="username" type="text" value=""
                      required >

                    </div>

                    <div class="col-md-3 form-control-comment">


                    </div>
                  </div>



                  

                  <div class="form-group row ">
                    <label class="col-md-3 form-control-label required">
                      Password
                    </label>
                    <div class="col-md-6">



                      <div class="input-group js-parent-focus">
                        <input
                        class="form-control js-child-focus js-visible-password"
                        name="password"
                        type="password"
                        value=""
                        pattern=".{5,}"
                        required            >
                        <span class="input-group-btn">
                          <button
                          class="btn"
                          type="button"
                          data-action="show-password"
                          data-text-show="Show"
                          data-text-hide="Hide"
                          >
                          Show
                        </button>
                      </span>
                    </div>






                  </div>

                  <div class="col-md-3 form-control-comment">


                  </div>
                </div>




              <div class="forgot-password">
                  <a href="<?php echo base_url(); ?>Access=forgot_451<?php echo base64_encode('fp-1'); ?>Pass" rel="nofollow">
                    Forgot your password?
                  </a>
                </div>
              </section>


              <footer class="form-footer text-sm-center clearfix">
                <input type="hidden" name="submitLogin" value="1">

                <button class="btn btn-primary" data-link-action="sign-in" type="submit" class="form-control-submit">
                  Sign in
                </button>

              </footer>


            </form>


          </section>
          <hr/>



          <div class="no-account">
            <a href="<?php echo base_url(); ?>User/registration" data-link-action="display-register-form">
              No account? Create one here
            </a>
          </div>


        </section>



        <footer class="page-footer">

          <!-- Footer content -->

        </footer>


      </section>



    </div>



  </div>
</div>

</section>

<!-- footer -->
<?php $this->load->view('common/imt/footer1'); ?>
<!-- //footer -->
</main>


<script type="text/javascript" src="<?php echo base_url(); ?>assets/themes/Fashcod/assets/cache/bottom-9149e8.js" ></script>

<?php $this->load->view('common/imt/customer'); ?>



        </body>


        <!-- Mirrored from codezeel.com/prestashop/PRS06/PRS060129/index.php?controller=authentication&back=my-account by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 17 Jul 2018 15:48:23 GMT -->
        </html>
<?php $this->load->view('common/imt/head'); ?>
<body id="addresses" class="lang-en country-us currency-usd layout-left-column page-addresses tax-display-disabled">
<main id="page">
<header id="header">
      <div class="header-banner">
      </div>
      <nav class="header-nav">
        <div class="container">
          <div class="left-nav">
          </div>
          <div class="right-nav">
          </div>
        </div>
      </nav>
      <!-- header-bot -->
      <?php $this->load->view('common/imt/header'); ?>
      <!-- //header-bot -->
      <!-- banner -->
      <?php $this->load->view('common/imt/navbar'); ?>
    </header>
    <aside id="notifications">
      <div class="container">
      </div>
    </aside>
    <nav data-depth="11" class="breadcrumb">
      <div class="container">
        <ol itemscope itemtype="#">
          
          <li itemprop="itemListElement" itemscope itemtype="#">
            <a itemprop="item" href="index.html">
              <span itemprop="name">Home</span>
            </a>
            <meta itemprop="position" content="1">
          </li>
      </div>
    </nav>


  
        <section id="wrapper">
     
    <div class="container">
      <div id="columns_inner"><div id="left-column" class="col-xs-12" style="width:24.4%">
                    


<div class="block-categories block">
   <h4 class="block_title hidden-md-down">
      <a href="#">Handbags</a>
   </h4>
   <h4 class="block_title hidden-lg-up" data-target="#block_categories_toggle" data-toggle="collapse">
    <a href="#">Handbags</a>
    <span class="pull-xs-right">
      <span class="navbar-toggler collapse-icons">
      <i class="fa-icon add"></i>
      <i class="fa-icon remove"></i>
      </span>
    </span>
  </h4>
   <div id="block_categories_toggle" class="block_content collapse">
     <ul class="category-top-menu">
    <li>  </li>
    </ul>
  </div>
</div>

  <div id="czleftbanner">
    <ul>
              <li class="slide czleftbanner-container">
          <a href="#" title="LeftBanner 1">
            <img src="<?php echo base_url()?>assets/img/left-banner-1.jpg" alt="LeftBanner 1" title="LeftBanner 1">
          </a>        
        </li>
          </ul>
  </div>      

<div id="newproduct_block" class="block products-block">
    <h4 class="block_title hidden-md-down">
    New products
  </h4>
  <h4 class="block_title hidden-lg-up" data-target="#newproduct_block_toggle" data-toggle="collapse">
    New products
    <span class="pull-xs-right">
      <span class="navbar-toggler collapse-icons">
      <i class="fa-icon add"></i>
      <i class="fa-icon remove"></i>
      </span>
    </span>
  </h4>
  <div id="newproduct_block_toggle" class="block_content  collapse">
     
    <ul class="products">
              <li class="product_item">
         
<div class="product-miniature js-product-miniature" data-id-product="15" data-id-product-attribute="268" itemscope="" itemtype="#">
  <div class="product_thumbnail">
    
      <a href="#" class="thumbnail product-image">
      <img src="<?php echo base_url()?>assets/img/108-small_default.jpg" alt="Accusantium Voluptatem">
      </a>
     
  </div>

  <div class="product-info">
    
      <h1 class="h3 product-title" itemprop="name"><a href="#">Accusantium Voluptatem</a></h1>
    
  
    
              <div class="product-price-and-shipping">
              
        
      
        <span itemprop="price" class="price">$80.00</span>
      
        
      
        
        </div>
          
    
      <div class="comments_note">
            <div class="star_content clearfix">
                                                <div class="star"></div>
                                                                <div class="star"></div>
                                                                <div class="star"></div>
                                                                <div class="star"></div>
                                                                <div class="star"></div>
                                    </div>
        <span class="total-rating">0 Review(s)&nbsp;</span>
    </div>
    
    
  </div>
</div>  


        </li>
              <li class="product_item">
         
<div class="product-miniature js-product-miniature" data-id-product="14" data-id-product-attribute="260" itemscope="" itemtype="#">
  <div class="product_thumbnail">
    
      <a href="#" class="thumbnail product-image">
      <img src="<?php echo base_url()?>assets/img/104-small_default.jpg" alt="Occasion praesentium">
      </a>
     
  </div>

  <div class="product-info">
    
      <h1 class="h3 product-title" itemprop="name"><a href="#">Occasion praesentium</a></h1>
    
  
    
              <div class="product-price-and-shipping">
                  
      
          <span class="regular-price">$99.00</span>
                    <span class="discount-percentage">-3%</span>
                        
        
      
        <span itemprop="price" class="price">$96.03</span>
      
        
      
        
        </div>
          
    
      <div class="comments_note">
            <div class="star_content clearfix">
                                                <div class="star star_on"></div>
                                                                <div class="star star_on"></div>
                                                                <div class="star star_on"></div>
                                                                <div class="star star_on"></div>
                                                                <div class="star star_on"></div>
                                    </div>
        <span class="total-rating">1 Review(s)&nbsp;</span>
    </div>
    
    
  </div>
</div>  


        </li>
              <li class="product_item">
         
<div class="product-miniature js-product-miniature" data-id-product="13" data-id-product-attribute="241" itemscope="" itemtype="#">
  <div class="product_thumbnail">
    
      <a href="#" class="thumbnail product-image">
      <img src="<?php echo base_url()?>assets/img/96-small_default.jpg" alt="Laudant doloremque">
      </a>
     
  </div>

  <div class="product-info">
    
      <h1 class="h3 product-title" itemprop="name"><a href="#">Laudant doloremque</a></h1>
    
  
    
              <div class="product-price-and-shipping">
                  
      
          <span class="regular-price">$91.00</span>
                        
        
      
        <span itemprop="price" class="price">$85.00</span>
      
        
      
        
        </div>
          
    
      <div class="comments_note">
            <div class="star_content clearfix">
                                                <div class="star"></div>
                                                                <div class="star"></div>
                                                                <div class="star"></div>
                                                                <div class="star"></div>
                                                                <div class="star"></div>
                                    </div>
        <span class="total-rating">0 Review(s)&nbsp;</span>
    </div>
    
    
  </div>
</div>  


        </li>
        
    </ul>
     
    <div class="view_more">
      <a class="all-product-link btn btn-primary" href="#">
        All new products
      </a>
    </div>
    
  </div>
</div>


<!-- Block categories module -->
        <div id="categories_blog_menu" class="block blog-menu">
      <h4 class="block_title hidden-md-down">
        Blog Categories   </h4>
    <h4 class="block_title hidden-lg-up" data-target="#categories_blog_toggle" data-toggle="collapse">
      Blog Categories     <span class="pull-xs-right">
        <span class="navbar-toggler collapse-icons">
        <i class="fa-icon add"></i>
        <i class="fa-icon remove"></i>
        </span>
      </span>
    </h4>
        <div id="categories_blog_toggle" class="block_content  collapse">
            <ul class="level1 tree dhtml "><li id="list_3" class=" "><a href="#" title="Vestibulum consequat"><span>Vestibulum consequat</span></a> <ul class="level2 "><li id="list_4" class=" "><a href="#" title="Pellentesque condimentum"><span>Pellentesque condimentum</span></a> </li><li id="list_5" class=" "><a href="#" title="Suspendisse turpis"><span>Suspendisse turpis</span></a> </li></ul></li></ul>
        </div>
    </div>
        <!-- /Block categories module -->

                  </div>
        
        
        

        
  <div id="content-wrapper" class="left-column col-xs-12 col-sm-8 col-md-9" style="width:75.6%">

    

  <section id="main">

    
      
        <header class="page-header">
          <h1>
  Your addresses
</h1>
        </header>
      
    

    
  <section id="content" class="page-content">
    
      
        
<aside id="notifications">
  <div class="container">
    
    
    
      </div>
</aside>
      
    
    
      <div class="col-lg-4 col-md-6 col-sm-6">
    
      
  <article id="address-8" class="address" data-id-address="8">
    <div class="address-body">
      <h4>My Address</h4>
      <address>minakshi kumrawat<br>impetrosys<br>s-2 yashwant plaza indore<br>Indore, Alaska 45601<br>United States<br>8956325610</address>
    </div>

    
      <div class="address-footer">
        <a href="#" data-link-action="edit-address">
          <i class="material-icons"></i>
          <span>Update</span>
        </a>
        <a href="#" data-link-action="delete-address">
          <i class="material-icons"></i>
          <span>Delete</span>
        </a>
      </div>
    
  </article>

    
    </div>
    <div class="clearfix"></div>
  <div class="addresses-footer">
    <a href="#" data-link-action="add-address">
      <i class="material-icons"></i>
      <span>Create new address</span>
    </a>
  </div>

  </section>


    
      <footer class="page-footer">
        
  
    
  <a href="#" class="account-link">
    <i class="material-icons"></i>
    <span>Back to your account</span>
  </a>
  <a href="#" class="account-link">
    <i class="material-icons"></i>
    <span>Home</span>
  </a>

  

      </footer>
    

  </section>


    
  </div>


        
      </div>
        </div>

      </section>
 
  
<!-- //contact -->


<!-- footer --><?php $this->load->view('common/imt/footer1'); ?>
<!-- //footer -->
<!-- login -->
<script type="text/javascript" src="<?php echo base_url(); ?>assets/themes/Fashcod/assets/cache/bottom-9149e8.js" ></script>

<?php $this->load->view('common/imt/customer'); ?>
<!-- //footer -->
</main>
</body>

</html>

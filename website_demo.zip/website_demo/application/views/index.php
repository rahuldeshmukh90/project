<body id="index" class="lang-en country-us currency-usd layout-full-width page-index tax-display-disabled">

  
  
  

  <main id="page">
    
    

    <header id="header">
      <div class="header-banner">
      </div>
      <nav class="header-nav">
        <div class="container">
          <div class="left-nav">
          </div>
          <div class="right-nav">
          </div>
        </div>
      </nav>
      <!-- header-bot -->
      <?php $this->load->view('common/imt/header'); ?>
      <!-- //header-bot -->
      <!-- banner -->
      <?php $this->load->view('common/imt/navbar'); ?>
    </header>
    <aside id="notifications">
      <div class="container">
      </div>
    </aside>
    <nav data-depth="1" class="breadcrumb">
      <div class="container">
        <ol itemscope itemtype="#">
          
          <li itemprop="itemListElement" itemscope itemtype="#">
            <a itemprop="item" href="<?php echo base_url(); ?>">
              <span itemprop="name">Home</span>
            </a>
            <meta itemprop="position" content="1">
          </li>
          
        </ol>
      </div>
    </nav>
    
    
    <section id="wrapper">
     
      <div class="home-container">
        <div id="columns_inner">
          

          
          <div id="content-wrapper">
            
            

            <section id="main">

              
              
              

              
              <section id="content" class="page-home">
                
                
                
                <div class="czhomeslider">
                  <div id="spinner" class="loadingdiv spinner"></div>
                  <div id="nivoslider" class="nivoSlider" data-interval="8000" data-pause="true">
                    <?php  foreach($slider as $sli){?>
                    <a href="#" title="<?php echo $sli->main_title; ?>">
                      <img src="<?php echo SLIDERIMAGE_URL.$sli->image; ?>" data-thumb="<?php echo SLIDERIMAGE_URL.$sli->image; ?>" alt="<?php echo $sli->main_title; ?>" title="<?php echo $sli->main_title; ?>" style="max-height: 450px"/>
                    </a>
                  <?php } ?>
                   <!--  <a href="#" title="sample-2">
                      <img src="<?php echo base_url(); ?>assets/modules/cz_imageslider/views/img/sample-2.jpg" data-thumb="https://codezeel.com/prestashop/PRS06/PRS060129/modules/cz_imageslider/views/img/sample-2.jpg" alt="sample-2" title="Sample 2" />
                    </a>
                    <a href="#" title="sample-3">
                      <img src="<?php echo base_url(); ?>assets/modules/cz_imageslider/views/img/sample-3.jpg" data-thumb="https://codezeel.com/prestashop/PRS06/PRS060129/modules/cz_imageslider/views/img/sample-3.jpg" alt="sample-3" title="Sample 3" />
                    </a> -->
                  </div>
                </div>
                <section class="cz-hometabcontent">
                  <div class="container"> 
                    <h2 class="h1 products-section-title text-uppercase">Best Selling Product</h2>
                    <div class="tabs">
                      <ul id="home-page-tabs" class="nav nav-tabs clearfix">
                        <li class="nav-item">
                          <a data-toggle="tab" href="#featureProduct" class="nav-link active" data-text="Featured">
                            <span>Featured</span>
                          </a>
                        </li>
                        <li class="nav-item">
                          <a data-toggle="tab" href="#newProduct" class="nav-link" data-text="New Arrival">
                            <span>New Arrival</span>
                          </a>
                        </li>
                        <li class="nav-item">
                          <a data-toggle="tab" href="#bestseller" class="nav-link" data-text="Best Sellers">
                            <span>Best Sellers</span>
                          </a>
                        </li>
                      </ul>
                      <div class="tab-content">
                        <div id="featureProduct" class="cz_productinner tab-pane active">   
                          
                          <section class="featured-products clearfix">
                            <h2 class="h1 products-section-title text-uppercase">
                              Featured products
                            </h2>
                            <div class="products">          
                             <!-- Define Number of product for SLIDER -->
                             <ul id="feature-carousel" class="cz-carousel product_list">
                               <?php 
                                $product= $this->Product_model->ProductListBytype('2');
                               foreach($product->result() as $products){ ?>
                              <li class="item">
                                
                                <div class="product-miniature js-product-miniature" data-id-product="1" data-id-product-attribute="49" itemscope itemtype="#">
                                  <div class="thumbnail-container">
                                    
                                    <a href="<?php echo base_url(); ?>single_ProductDetail<?php echo base64_encode('pd1234'); ?>_page?ee=<?php echo base64_encode($products->id); ?>" class="thumbnail product-thumbnail">
                                      <img
                                      src = "<?php echo IMAGE_URL; ?><?php echo $products->image; ?>"
                                      data-full-size-image-url = "<?php echo base_url(); ?>assets/img/p/2/4/24-large_default.jpg"
                                      >
                                      
                                      <img class="<?php echo IMAGE_URL; ?><?php echo $products->image; ?>" data-full-size-image-url="<?php echo base_url(); ?>assets/img/p/2/5/25-large_default.jpg" alt="" />

                                    </a>
                                    <!-- <ul class="product-flags">
                                      <li class="new" style="background:#1d9dff;">New</li>
                                    </ul> -->
                                    <div class="outer-functional">
                                      <div class="functional-buttons">
                                        
                                        <a href="<?php echo base_url(); ?>single_ProductDetail<?php echo base64_encode('pd1234'); ?>_page?ee=<?php echo base64_encode($products->id); ?>" class="quick-view">
                                          <i class="material-icons search">&#xE417;</i> Quick view
                                        </a>
                                         

                                        
                                        
                                        
                                        <!-- <div class="product-actions">
                                          <form action="<?php echo base_url(); ?>Cart/add" method="post" class="add-to-cart-or-refresh">
                                            <input type="hidden" name="token" value="f6ea937a766343139d0cc27dc915cb03">
                                                <input type="hidden" name="p_id" value="<?php echo $products->id; ?>" > 
                                            <input type="hidden" name="p_name" value="<?php echo $products->name; ?>" > 
                                            <input type="hidden" name="p_category" value="<?php echo $products->category_id; ?>" > 
                                            <input type="hidden" name="p_subcategoryId" value="<?php echo $products->subcategory_id; ?>" > 
                                            <input type="hidden" name="p_qty" value="1" > 
                                            
                                           <input type="hidden" name="p_price" value="<?php echo $products->price; ?>" >
                                            <input type="hidden" name="p_image" value="<?php echo $products->image; ?>" > 
                                            <?php $total_price = ($products->price)*(1); ?>
                                            <input type="hidden" name="p_total" value="<?php echo $total_price; ?>" > 
                                            <button class="btn btn-primary add-to-cart" data-button-action="add-to-cart" type="submit"  >
                                              Add to cart
                                            </button>
                                          </form>
                                        </div> -->
                                        
                                        
                                      </div>
                                    </div>  
                                  </div>

                                  <div class="product-description">
                                    
                                    <span class="h3 product-title" itemprop="name"><a href="<?php echo base_url(); ?>single_ProductDetail<?php echo base64_encode('pd1234'); ?>_page?ee=<?php echo base64_encode($products->id); ?>"><?php echo $products->name; ?></a></span>
                                    

                                    
                                    <div class="product-price-and-shipping">
                                      
                                      

                                      <span itemprop="price" class="price">₹<?php echo $products->price; ?></span>

                                      

                                      
                                    </div>
                                    
                                    
                                    
                                    
                                     <div class="comments_note">
                                      <div class="product-reference">
                                      <label class="label">Product code: </label>
                                      <span itemprop="sku"><?php echo $products->code; ?></span>
                                      </div>
                                      
                                    </div>
                                    
                                    <div class="highlighted-informations hidden-sm-down">
                                      
                                      
                                      <div class="variant-links">
                                        <a href="indexb846.html?id_product=1&amp;id_product_attribute=274&amp;rewrite=faded-short-sleeves-tshirt&amp;controller=product&amp;id_lang=1#/11-color-black"
                                        class="color"
                                        title="Black"
                                        
                                        style="background-color: #434A54"           ><span class="sr-only">Black</span></a>
                                        <a href="index69ac.html?id_product=1&amp;id_product_attribute=50&amp;rewrite=faded-short-sleeves-tshirt&amp;controller=product&amp;id_lang=1#/2-size-m/13-color-orange"
                                        class="color"
                                        title="Orange"
                                        
                                        style="background-color: #F39C11"           ><span class="sr-only">Orange</span></a>
                                        <a href="index4b53.html?id_product=1&amp;id_product_attribute=52&amp;rewrite=faded-short-sleeves-tshirt&amp;controller=product&amp;id_lang=1#/1-size-s/15-color-green"
                                        class="color"
                                        title="Green"
                                        
                                        style="background-color: #A0D468" ><span class="sr-only">Green</span></a>
                                        <span class="js-count count"></span>
                                      </div>
                                      
                                    </div>
                                  </div>
                                </div>

                              </li>
                            <?php } ?>
                              <?php /*
                              <li class="item">
                                
                                <div class="product-miniature js-product-miniature" data-id-product="2" data-id-product-attribute="56" itemscope itemtype="http://schema.org/Product">
                                  <div class="thumbnail-container">
                                    
                                    <a href="index13b2.html?id_product=2&amp;id_product_attribute=56&amp;rewrite=blouse&amp;controller=product&amp;id_lang=1#/1-size-s/14-color-blue" class="thumbnail product-thumbnail">
                                      <img
                                      src = "<?php echo base_url(); ?>assets/img/p/3/0/30-home_default.jpg"
                                      alt = "Exercitat Virginia"
                                      data-full-size-image-url = "<?php echo base_url(); ?>assets/img/p/3/0/30-large_default.jpg"
                                      >
                                      
                                      <img class="fliper_image img-responsive" src="<?php echo base_url(); ?>assets/img/p/3/1/31-home_default.jpg" data-full-size-image-url="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/3/1/31-large_default.jpg" alt="" />

                                    </a>
                                    
                                    
                                    
                                    <ul class="product-flags">
                                      <li class="on-sale">On sale!</li>
                                      <li class="new" style="background:#1d9dff;">New</li>
                                    </ul>
                                    
                                    
                                    <div class="outer-functional">
                                      <div class="functional-buttons">
                                        
                                        <a href="#" class="quick-view" data-toggle="modal" data-target="#myModal" data-link-action="quickview">
                                          <i class="material-icons search">&#xE417;</i> Quick view
                                        </a>
                                        <div class="product-actions">
                                          <form action="https://codezeel.com/prestashop/PRS06/PRS060129/index.php?controller=cart" method="post" class="add-to-cart-or-refresh">
                                            <input type="hidden" name="token" value="f6ea937a766343139d0cc27dc915cb03">
                                            <input type="hidden" name="id_product" value="2" class="product_page_product_id">
                                            <input type="hidden" name="id_customization" value="0" class="product_customization_id">
                                            <button class="btn btn-primary add-to-cart" data-button-action="add-to-cart" type="submit"  data-toggle="modal" data-target="#blockcart-modal">
                                              Add to cart
                                            </button>
                                          </form>
                                        </div>
                                        
                                        
                                      </div>
                                    </div>  
                                  </div>

                                  <div class="product-description">
                                    
                                    <span class="h3 product-title" itemprop="name"><a href="index13b2.html?id_product=2&amp;id_product_attribute=56&amp;rewrite=blouse&amp;controller=product&amp;id_lang=1#/1-size-s/14-color-blue">Exercitat Virginia</a></span>
                                    

                                    
                                    <div class="product-price-and-shipping">
                                      

                                      <span class="regular-price">$87.00</span>
                                      <span class="discount-percentage">-5%</span>
                                      
                                      

                                      <span itemprop="price" class="price">$82.65</span>

                                      

                                      
                                    </div>
                                    
                                    
                                    
                                    
                                    <!-- <div class="comments_note">
                                      <div class="star_content clearfix">
                                        <div class="star"></div>
                                        <div class="star"></div>
                                        <div class="star"></div>
                                        <div class="star"></div>
                                        <div class="star"></div>
                                      </div>
                                      <span class="total-rating">0 Review(s)&nbsp</span>
                                    </div> -->
                                    
                                    <div class="highlighted-informations hidden-sm-down">
                                      
                                      
                                      <div class="variant-links">
                                        <a href="index741d.html?id_product=2&amp;id_product_attribute=58&amp;rewrite=blouse&amp;controller=product&amp;id_lang=1#/2-size-m/8-color-white"
                                        class="color"
                                        title="White"
                                        
                                        style="background-color: #ffffff"           ><span class="sr-only">White</span></a>
                                        <a href="indexf85f.html?id_product=2&amp;id_product_attribute=55&amp;rewrite=blouse&amp;controller=product&amp;id_lang=1#/2-size-m/14-color-blue"
                                        class="color"
                                        title="Blue"
                                        
                                        style="background-color: #5D9CEC"           ><span class="sr-only">Blue</span></a>
                                        <a href="indexfa11.html?id_product=2&amp;id_product_attribute=61&amp;rewrite=blouse&amp;controller=product&amp;id_lang=1#/2-size-m/16-color-yellow"
                                        class="color"
                                        title="Yellow"
                                        
                                        style="background-color: #F1C40F"           ><span class="sr-only">Yellow</span></a>
                                        <span class="js-count count"></span>
                                      </div>
                                      
                                    </div>
                                  </div>
                                </div>

                              </li>
                              <li class="item">
                                
                                <div class="product-miniature js-product-miniature" data-id-product="3" data-id-product-attribute="64" itemscope itemtype="http://schema.org/Product">
                                  <div class="thumbnail-container">
                                    
                                    <a href="index9c23.html?id_product=3&amp;id_product_attribute=64&amp;rewrite=printed-dress&amp;controller=product&amp;id_lang=1#/1-size-s/15-color-green" class="thumbnail product-thumbnail">
                                      <img
                                      src = "<?php echo base_url(); ?>assets/img/p/3/5/35-home_default.jpg"
                                      alt = "Accusantium doloremque"
                                      data-full-size-image-url = "<?php echo base_url(); ?>assets/img/p/3/5/35-large_default.jpg"
                                      >
                                      
                                      <img class="fliper_image img-responsive" src="<?php echo base_url(); ?>assets/img/p/5/4/54-home_default.jpg" data-full-size-image-url="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/5/4/54-large_default.jpg" alt="" />

                                    </a>
                                    
                                    
                                    
                                    <ul class="product-flags">
                                      <li class="new" style="background:#1d9dff;">New</li>
                                    </ul>
                                    
                                    
                                    <div class="outer-functional">
                                      <div class="functional-buttons">
                                        
                                        <a href="#" class="quick-view" data-toggle="modal" data-target="#myModal" data-link-action="quickview">
                                          <i class="material-icons search">&#xE417;</i> Quick view
                                        </a>
                                        
                                        
                                        
                                        <div class="product-actions">
                                          <form action="https://codezeel.com/prestashop/PRS06/PRS060129/index.php?controller=cart" method="post" class="add-to-cart-or-refresh">
                                            <input type="hidden" name="token" value="f6ea937a766343139d0cc27dc915cb03">
                                            <input type="hidden" name="id_product" value="3" class="product_page_product_id">
                                            <input type="hidden" name="id_customization" value="0" class="product_customization_id">
                                            <button class="btn btn-primary add-to-cart" data-button-action="add-to-cart" type="submit"  data-toggle="modal" data-target="#blockcart-modal">
                                              Add to cart
                                            </button>
                                          </form>
                                        </div>
                                        
                                        
                                      </div>
                                    </div>  
                                  </div>

                                  <div class="product-description">
                                    
                                    <span class="h3 product-title" itemprop="name"><a href="index9c23.html?id_product=3&amp;id_product_attribute=64&amp;rewrite=printed-dress&amp;controller=product&amp;id_lang=1#/1-size-s/15-color-green">Accusantium doloremque</a></span>
                                    

                                    
                                    <div class="product-price-and-shipping">
                                      
                                      

                                      <span itemprop="price" class="price">$110.00</span>

                                      

                                      
                                    </div>
                                    
                                    
                                    
                                    
                                    <!-- <div class="comments_note">
                                      <div class="star_content clearfix">
                                        <div class="star"></div>
                                        <div class="star"></div>
                                        <div class="star"></div>
                                        <div class="star"></div>
                                        <div class="star"></div>
                                      </div>
                                      <span class="total-rating">0 Review(s)&nbsp</span>
                                    </div> -->
                                    
                                    <div class="highlighted-informations hidden-sm-down">
                                      
                                      
                                      <div class="variant-links">
                                        <a href="indexece9.html?id_product=3&amp;id_product_attribute=66&amp;rewrite=printed-dress&amp;controller=product&amp;id_lang=1#/1-size-s/11-color-black"
                                        class="color"
                                        title="Black"
                                        
                                        style="background-color: #434A54"           ><span class="sr-only">Black</span></a>
                                        <a href="index0d73.html?id_product=3&amp;id_product_attribute=65&amp;rewrite=printed-dress&amp;controller=product&amp;id_lang=1#/1-size-s/14-color-blue"
                                        class="color"
                                        title="Blue"
                                        
                                        style="background-color: #5D9CEC"           ><span class="sr-only">Blue</span></a>
                                        <a href="indexda82.html?id_product=3&amp;id_product_attribute=67&amp;rewrite=printed-dress&amp;controller=product&amp;id_lang=1#/2-size-m/15-color-green"
                                        class="color"
                                        title="Green"
                                        
                                        style="background-color: #A0D468"           ><span class="sr-only">Green</span></a>
                                        <span class="js-count count"></span>
                                      </div>
                                      
                                    </div>
                                  </div>
                                </div>

                              </li>
                              <li class="item">
                                
                                <div class="product-miniature js-product-miniature" data-id-product="4" data-id-product-attribute="76" itemscope itemtype="http://schema.org/Product">
                                  <div class="thumbnail-container">
                                    
                                    <a href="index6a45.html?id_product=4&amp;id_product_attribute=76&amp;rewrite=printed-dress&amp;controller=product&amp;id_lang=1#/1-size-s/8-color-white" class="thumbnail product-thumbnail">
                                      <img
                                      src = "<?php echo base_url(); ?>assets/img/p/4/2/42-home_default.jpg"
                                      alt = "Voluptas assumenda"
                                      data-full-size-image-url = "<?php echo base_url(); ?>assets/img/p/4/2/42-large_default.jpg"
                                      >
                                      
                                      <img class="fliper_image img-responsive" src="<?php echo base_url(); ?>assets/img/p/4/3/43-home_default.jpg" data-full-size-image-url="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/4/3/43-large_default.jpg" alt="" />

                                    </a>
                                    
                                    
                                    
                                    <ul class="product-flags">
                                      <li class="new" style="background:#1d9dff;">New</li>
                                    </ul>
                                    
                                    
                                    <div class="outer-functional">
                                      <div class="functional-buttons">
                                        
                                        <a href="#" class="quick-view" data-toggle="modal" data-target="#myModal" data-link-action="quickview">
                                          <i class="material-icons search">&#xE417;</i> Quick view
                                        </a>
                                        
                                        
                                        
                                        <div class="product-actions">
                                          <form action="https://codezeel.com/prestashop/PRS06/PRS060129/index.php?controller=cart" method="post" class="add-to-cart-or-refresh">
                                            <input type="hidden" name="token" value="f6ea937a766343139d0cc27dc915cb03">
                                            <input type="hidden" name="id_product" value="4" class="product_page_product_id">
                                            <input type="hidden" name="id_customization" value="0" class="product_customization_id">
                                            <button class="btn btn-primary add-to-cart" data-button-action="add-to-cart" type="submit"  data-toggle="modal" data-target="#blockcart-modal">
                                              Add to cart
                                            </button>
                                          </form>
                                        </div>
                                        
                                        
                                      </div>
                                    </div>  
                                  </div>

                                  <div class="product-description">
                                    
                                    <span class="h3 product-title" itemprop="name"><a href="index6a45.html?id_product=4&amp;id_product_attribute=76&amp;rewrite=printed-dress&amp;controller=product&amp;id_lang=1#/1-size-s/8-color-white">Voluptas assumenda</a></span>
                                    

                                    
                                    <div class="product-price-and-shipping">
                                      
                                      

                                      <span itemprop="price" class="price">$78.00</span>

                                      

                                      
                                    </div>
                                    
                                    
                                    
                                    
                                    <!-- <div class="comments_note">
                                      <div class="star_content clearfix">
                                        <div class="star star_on"></div>
                                        <div class="star star_on"></div>
                                        <div class="star star_on"></div>
                                        <div class="star star_on"></div>
                                        <div class="star"></div>
                                      </div>
                                      <span class="total-rating">1 Review(s)&nbsp</span>
                                    </div> -->
                                    
                                    <div class="highlighted-informations hidden-sm-down">
                                      
                                      
                                      <div class="variant-links">
                                        <a href="indexb253.html?id_product=4&amp;id_product_attribute=73&amp;rewrite=printed-dress&amp;controller=product&amp;id_lang=1#/2-size-m/8-color-white"
                                        class="color" title="White"  style="background-color: #ffffff" ><span class="sr-only">White</span></a>
                                        <a href="index9145.html?id_product=4&amp;id_product_attribute=75&amp;rewrite=printed-dress&amp;controller=product&amp;id_lang=1#/2-size-m/13-color-orange"
                                        class="color"  title="Orange" style="background-color: #F39C11"><span class="sr-only">Orange</span></a>
                                        <a href="indexab4b.html?id_product=4&amp;id_product_attribute=74&amp;rewrite=printed-dress&amp;controller=product&amp;id_lang=1#/2-size-m/14-color-blue"
                                        class="color"
                                        title="Blue"
                                        
                                        style="background-color: #5D9CEC"           ><span class="sr-only">Blue</span></a>
                                        <span class="js-count count"></span>
                                      </div>
                                      
                                    </div>
                                  </div>
                                </div>

                              </li>
                              <li class="item">
                                
                                <div class="product-miniature js-product-miniature" data-id-product="5" data-id-product-attribute="109" itemscope itemtype="http://schema.org/Product">
                                  <div class="thumbnail-container">
                                    
                                    <a href="index7b5e.html?id_product=5&amp;id_product_attribute=109&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/3-size-l/14-color-blue/20-shoes_size-37" class="thumbnail product-thumbnail">
                                      <img
                                      src = "<?php echo base_url(); ?>assets/img/p/4/7/47-home_default.jpg"
                                      alt = "Nostrud exercitation"
                                      data-full-size-image-url = "<?php echo base_url(); ?>assets/img/p/4/7/47-large_default.jpg"
                                      >
                                      
                                      <img class="fliper_image img-responsive" src="<?php echo base_url(); ?>assets/img/p/5/5/55-home_default.jpg" data-full-size-image-url="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/5/5/55-large_default.jpg" alt="" />

                                    </a>
                                    
                                    
                                    
                                    <ul class="product-flags">
                                      <li class="on-sale">On sale!</li>
                                      <li class="new" style="background:#1d9dff;">New</li>
                                    </ul>
                                    
                                    
                                    <div class="outer-functional">
                                      <div class="functional-buttons">
                                        
                                        <a href="#" class="quick-view" data-toggle="modal" data-target="#myModal" data-link-action="quickview">
                                          <i class="material-icons search">&#xE417;</i> Quick view
                                        </a>
                                        
                                        
                                        
                                        <div class="product-actions">
                                          <form action="https://codezeel.com/prestashop/PRS06/PRS060129/index.php?controller=cart" method="post" class="add-to-cart-or-refresh">
                                            <input type="hidden" name="token" value="f6ea937a766343139d0cc27dc915cb03">
                                            <input type="hidden" name="id_product" value="5" class="product_page_product_id">
                                            <input type="hidden" name="id_customization" value="0" class="product_customization_id">
                                            <button class="btn btn-primary add-to-cart" data-button-action="add-to-cart" type="submit"  data-toggle="modal" data-target="#blockcart-modal">
                                              Add to cart
                                            </button>
                                          </form>
                                        </div>
                                        
                                        
                                      </div>
                                    </div>  
                                  </div>

                                  <div class="product-description">
                                    
                                    <span class="h3 product-title" itemprop="name"><a href="index7b5e.html?id_product=5&amp;id_product_attribute=109&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/3-size-l/14-color-blue/20-shoes_size-37">Nostrud exercitation</a></span>
                                    

                                    
                                    <div class="product-price-and-shipping">
                                      

                                      <span class="regular-price">$98.00</span>
                                      <span class="discount-percentage">-5%</span>
                                      
                                      

                                      <span itemprop="price" class="price">$93.10</span>

                                      

                                      
                                    </div>
                                    
                                    
                                    
                                    
                                    <!-- <div class="comments_note">
                                      <div class="star_content clearfix">
                                        <div class="star star_on"></div>
                                        <div class="star star_on"></div>
                                        <div class="star star_on"></div>
                                        <div class="star star_on"></div>
                                        <div class="star star_on"></div>
                                      </div>
                                      <span class="total-rating">1 Review(s)&nbsp</span>
                                    </div> -->
                                    
                                    <div class="highlighted-informations hidden-sm-down">
                                      
                                      
                                      <div class="variant-links">
                                        <a href="index3e01.html?id_product=5&amp;id_product_attribute=112&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/2-size-m/14-color-blue/20-shoes_size-37"
                                        class="color"
                                        title="Blue"
                                        
                                        style="background-color: #5D9CEC"           ><span class="sr-only">Blue</span></a>
                                        <a href="indexe051.html?id_product=5&amp;id_product_attribute=110&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/3-size-l/15-color-green/20-shoes_size-37"
                                        class="color"
                                        title="Green"
                                        
                                        style="background-color: #A0D468"           ><span class="sr-only">Green</span></a>
                                        <a href="index0fe1.html?id_product=5&amp;id_product_attribute=111&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/3-size-l/16-color-yellow/20-shoes_size-37"
                                        class="color"
                                        title="Yellow"
                                        
                                        style="background-color: #F1C40F"           ><span class="sr-only">Yellow</span></a>
                                        <span class="js-count count"></span>
                                      </div>
                                      
                                    </div>
                                  </div>
                                </div>

                              </li>
                              <li class="item">
                                
                                <div class="product-miniature js-product-miniature" data-id-product="6" data-id-product-attribute="127" itemscope itemtype="http://schema.org/Product">
                                  <div class="thumbnail-container">
                                    
                                    <a href="index0dfc.html?id_product=6&amp;id_product_attribute=127&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/1-size-s/8-color-white/22-shoes_size-39" class="thumbnail product-thumbnail">
                                      <img
                                      src = "<?php echo base_url(); ?>assets/img/p/5/6/56-home_default.jpg"
                                      alt = "Commodi consequatur"
                                      data-full-size-image-url = "<?php echo base_url(); ?>assets/img/p/5/6/56-large_default.jpg"
                                      >
                                      
                                      <img class="fliper_image img-responsive" src="<?php echo base_url(); ?>assets/img/p/5/7/57-home_default.jpg" data-full-size-image-url="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/5/7/57-large_default.jpg" alt="" />

                                    </a>
                                    
                                    
                                    
                                    <ul class="product-flags">
                                      <li class="new" style="background:#1d9dff;">New</li>
                                    </ul>
                                    
                                    
                                    <div class="outer-functional">
                                      <div class="functional-buttons">
                                        
                                        <a href="#" class="quick-view" data-toggle="modal" data-target="#myModal" data-link-action="quickview">
                                          <i class="material-icons search">&#xE417;</i> Quick view
                                        </a>
                                        
                                        
                                        
                                        <div class="product-actions">
                                          <form action="https://codezeel.com/prestashop/PRS06/PRS060129/index.php?controller=cart" method="post" class="add-to-cart-or-refresh">
                                            <input type="hidden" name="token" value="f6ea937a766343139d0cc27dc915cb03">
                                            <input type="hidden" name="id_product" value="6" class="product_page_product_id">
                                            <input type="hidden" name="id_customization" value="0" class="product_customization_id">
                                            <button class="btn btn-primary add-to-cart" data-button-action="add-to-cart" type="submit"  data-toggle="modal" data-target="#blockcart-modal">
                                              Add to cart
                                            </button>
                                          </form>
                                        </div>
                                        
                                        
                                      </div>
                                    </div>  
                                  </div>

                                  <div class="product-description">
                                    
                                    <span class="h3 product-title" itemprop="name"><a href="index0dfc.html?id_product=6&amp;id_product_attribute=127&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/1-size-s/8-color-white/22-shoes_size-39">Commodi consequatur</a></span>
                                    

                                    
                                    <div class="product-price-and-shipping">
                                      
                                      

                                      <span itemprop="price" class="price">$85.00</span>

                                      

                                      
                                    </div>
                                    
                                    
                                    
                                    
                                    <!-- <div class="comments_note">
                                      <div class="star_content clearfix">
                                        <div class="star"></div>
                                        <div class="star"></div>
                                        <div class="star"></div>
                                        <div class="star"></div>
                                        <div class="star"></div>
                                      </div>
                                      <span class="total-rating">0 Review(s)&nbsp</span>
                                    </div> -->
                                    
                                    <div class="highlighted-informations hidden-sm-down">
                                      
                                      
                                      <div class="variant-links">
                                        <a href="index7f57.html?id_product=6&amp;id_product_attribute=121&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/2-size-m/8-color-white/22-shoes_size-39"
                                        class="color"
                                        title="White"
                                        
                                        style="background-color: #ffffff"           ><span class="sr-only">White</span></a>
                                        <a href="index2e82.html?id_product=6&amp;id_product_attribute=122&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/2-size-m/15-color-green/22-shoes_size-39"
                                        class="color"
                                        title="Green"
                                        
                                        style="background-color: #A0D468"           ><span class="sr-only">Green</span></a>
                                        <a href="index86c6.html?id_product=6&amp;id_product_attribute=123&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/2-size-m/16-color-yellow/22-shoes_size-39"
                                        class="color"
                                        title="Yellow"
                                        
                                        style="background-color: #F1C40F"           ><span class="sr-only">Yellow</span></a>
                                        <span class="js-count count"></span>
                                      </div>
                                      
                                    </div>
                                  </div>
                                </div>

                              </li>
                              <li class="item">
                                
                                <div class="product-miniature js-product-miniature" data-id-product="7" data-id-product-attribute="275" itemscope itemtype="http://schema.org/Product">
                                  <div class="thumbnail-container">
                                    
                                    <a href="index54ae.html?id_product=7&amp;id_product_attribute=275&amp;rewrite=printed-chiffon-dress&amp;controller=product&amp;id_lang=1#/1-size-s/15-color-green" class="thumbnail product-thumbnail">
                                      <img
                                      src = "<?php echo base_url(); ?>assets/img/p/6/0/60-home_default.jpg"
                                      alt = "Praesentium voluptatum"
                                      data-full-size-image-url = "<?php echo base_url(); ?>assets/img/p/6/0/60-large_default.jpg"
                                      >
                                      
                                      <img class="fliper_image img-responsive" src="<?php echo base_url(); ?>assets/img/p/6/3/63-home_default.jpg" data-full-size-image-url="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/6/3/63-large_default.jpg" alt="" />

                                    </a>
                                    
                                    
                                    
                                    <ul class="product-flags">
                                      <li class="discount">Reduced price</li>
                                      <li class="new" style="background:#1d9dff;">New</li>
                                    </ul>
                                    
                                    
                                    <div class="outer-functional">
                                      <div class="functional-buttons">
                                        
                                        <a href="#" class="quick-view" data-toggle="modal" data-target="#myModal" data-link-action="quickview">
                                          <i class="material-icons search">&#xE417;</i> Quick view
                                        </a>
                                        
                                        
                                        
                                        <div class="product-actions">
                                          <form action="https://codezeel.com/prestashop/PRS06/PRS060129/index.php?controller=cart" method="post" class="add-to-cart-or-refresh">
                                            <input type="hidden" name="token" value="f6ea937a766343139d0cc27dc915cb03">
                                            <input type="hidden" name="id_product" value="7" class="product_page_product_id">
                                            <input type="hidden" name="id_customization" value="0" class="product_customization_id">
                                            <button class="btn btn-primary add-to-cart" data-button-action="add-to-cart" type="submit"  data-toggle="modal" data-target="#blockcart-modal">
                                              Add to cart
                                            </button>
                                          </form>
                                        </div>
                                        
                                        
                                      </div>
                                    </div>  
                                  </div>

                                  <div class="product-description">
                                    
                                    <span class="h3 product-title" itemprop="name"><a href="index54ae.html?id_product=7&amp;id_product_attribute=275&amp;rewrite=printed-chiffon-dress&amp;controller=product&amp;id_lang=1#/1-size-s/15-color-green">Praesentium voluptatum</a></span>
                                    

                                    
                                    <div class="product-price-and-shipping">
                                      

                                      <span class="regular-price">$79.00</span>
                                      
                                      

                                      <span itemprop="price" class="price">$75.00</span>

                                      

                                      
                                    </div>
                                    
                                    
                                    
                                    
                                    <!-- <div class="comments_note">
                                      <div class="star_content clearfix">
                                        <div class="star"></div>
                                        <div class="star"></div>
                                        <div class="star"></div>
                                        <div class="star"></div>
                                        <div class="star"></div>
                                      </div>
                                      <span class="total-rating">0 Review(s)&nbsp</span>
                                    </div> -->
                                    
                                    <div class="highlighted-informations hidden-sm-down">
                                      
                                      
                                      <div class="variant-links">
                                        <a href="index74ca.html?id_product=7&amp;id_product_attribute=277&amp;rewrite=printed-chiffon-dress&amp;controller=product&amp;id_lang=1#/1-size-s/5-color-grey"
                                        class="color"
                                        title="Grey"
                                        
                                        style="background-color: #AAB2BD"           ><span class="sr-only">Grey</span></a>
                                        <a href="indexff6f.html?id_product=7&amp;id_product_attribute=276&amp;rewrite=printed-chiffon-dress&amp;controller=product&amp;id_lang=1#/1-size-s/14-color-blue"
                                        class="color"
                                        title="Blue"
                                        
                                        style="background-color: #5D9CEC"           ><span class="sr-only">Blue</span></a>
                                        <a href="indexa5bf.html?id_product=7&amp;id_product_attribute=278&amp;rewrite=printed-chiffon-dress&amp;controller=product&amp;id_lang=1#/2-size-m/15-color-green"
                                        class="color"
                                        title="Green"
                                        
                                        style="background-color: #A0D468"           ><span class="sr-only">Green</span></a>
                                        <span class="js-count count"></span>
                                      </div>
                                      
                                    </div>
                                  </div>
                                </div>

                              </li>
                              <li class="item">
                                
                                <div class="product-miniature js-product-miniature" data-id-product="8" data-id-product-attribute="284" itemscope itemtype="http://schema.org/Product">
                                  <div class="thumbnail-container">
                                    
                                    <a href="indexd483.html?id_product=8&amp;id_product_attribute=284&amp;rewrite=faded-short-sleeves-tshirt&amp;controller=product&amp;id_lang=1#/1-size-s/13-color-orange" class="thumbnail product-thumbnail">
                                      <img
                                      src = "<?php echo base_url(); ?>assets/img/p/6/8/68-home_default.jpg"
                                      alt = "Voluptates repudiandae"
                                      data-full-size-image-url = "<?php echo base_url(); ?>assets/img/p/6/8/68-large_default.jpg"
                                      >
                                      
                                      <img class="fliper_image img-responsive" src="<?php echo base_url(); ?>assets/img/p/6/9/69-home_default.jpg" data-full-size-image-url="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/6/9/69-large_default.jpg" alt="" />

                                    </a>
                                    
                                    
                                    
                                    <ul class="product-flags">
                                      <li class="new" style="background:#1d9dff;">New</li>
                                    </ul>
                                    
                                    
                                    <div class="outer-functional">
                                      <div class="functional-buttons">
                                        
                                        <a href="#" class="quick-view" data-toggle="modal" data-target="#myModal" data-link-action="quickview">
                                          <i class="material-icons search">&#xE417;</i> Quick view
                                        </a>
                                        
                                        
                                        
                                        <div class="product-actions">
                                          <form action="https://codezeel.com/prestashop/PRS06/PRS060129/index.php?controller=cart" method="post" class="add-to-cart-or-refresh">
                                            <input type="hidden" name="token" value="f6ea937a766343139d0cc27dc915cb03">
                                            <input type="hidden" name="id_product" value="8" class="product_page_product_id">
                                            <input type="hidden" name="id_customization" value="0" class="product_customization_id">
                                            <button class="btn btn-primary add-to-cart" data-button-action="add-to-cart" type="submit"  data-toggle="modal" data-target="#blockcart-modal">
                                              Add to cart
                                            </button>
                                          </form>
                                        </div>
                                        
                                        
                                      </div>
                                    </div>  
                                  </div>

                                  <div class="product-description">
                                    
                                    <span class="h3 product-title" itemprop="name"><a href="indexd483.html?id_product=8&amp;id_product_attribute=284&amp;rewrite=faded-short-sleeves-tshirt&amp;controller=product&amp;id_lang=1#/1-size-s/13-color-orange">Voluptates repudiandae</a></span>
                                    

                                    
                                    <div class="product-price-and-shipping">
                                      
                                      

                                      <span itemprop="price" class="price">$105.00</span>

                                      

                                      
                                    </div>
                                    
                                    
                                    
                                    
                                    <!-- <div class="comments_note">
                                      <div class="star_content clearfix">
                                        <div class="star"></div>
                                        <div class="star"></div>
                                        <div class="star"></div>
                                        <div class="star"></div>
                                        <div class="star"></div>
                                      </div>
                                      <span class="total-rating">0 Review(s)&nbsp</span>
                                    </div> -->
                                    
                                    <div class="highlighted-informations hidden-sm-down">
                                      
                                      
                                      <div class="variant-links">
                                        <a href="index82e5.html?id_product=8&amp;id_product_attribute=287&amp;rewrite=faded-short-sleeves-tshirt&amp;controller=product&amp;id_lang=1#/2-size-m/13-color-orange"
                                        class="color"
                                        title="Orange"
                                        
                                        style="background-color: #F39C11"           ><span class="sr-only">Orange</span></a>
                                        <a href="index1622.html?id_product=8&amp;id_product_attribute=286&amp;rewrite=faded-short-sleeves-tshirt&amp;controller=product&amp;id_lang=1#/1-size-s/14-color-blue"
                                        class="color"
                                        title="Blue"
                                        
                                        style="background-color: #5D9CEC"           ><span class="sr-only">Blue</span></a>
                                        <a href="indexe74a.html?id_product=8&amp;id_product_attribute=285&amp;rewrite=faded-short-sleeves-tshirt&amp;controller=product&amp;id_lang=1#/1-size-s/16-color-yellow"
                                        class="color"
                                        title="Yellow"
                                        
                                        style="background-color: #F1C40F"           ><span class="sr-only">Yellow</span></a>
                                        <span class="js-count count"></span>
                                      </div>
                                      
                                    </div>
                                  </div>
                                </div>

                              </li>*/ ?>
                              
                            </ul>   
                            <div class="customNavigation">
                              <a class="btn prev feature_prev">&nbsp;</a>
                              <a class="btn next feature_next">&nbsp;</a>
                            </div>
                            
                          </div>
                        </section>
                      </div>
                      <div id="newProduct" class="cz_productinner tab-pane">
                        
                        <section class="newproducts clearfix">
                          <h2 class="h1 products-section-title text-uppercase">
                            New products
                          </h2>
                          <div class="products">
                           <!-- Define Number of product for SLIDER -->
                           <ul id="newproduct-carousel" class="cz-carousel product_list">
                             <?php 
                                $product= $this->Product_model->ProductListBytype('1');
                               foreach($product->result() as $products){ ?>
                               
                            <li class="item">
                              
                              <div class="product-miniature js-product-miniature" data-id-product="15" data-id-product-attribute="268" itemscope itemtype="#">
                                <div class="thumbnail-container">
                                  
                                  <a href="<?php echo base_url(); ?>single_ProductDetail<?php echo base64_encode('pd1234'); ?>_page?ee=<?php echo base64_encode($products->id); ?>" class="thumbnail product-thumbnail">
                                    <img
                                    src = "<?php echo IMAGE_URL; ?><?php echo $products->image; ?>"
                                    alt = "Accusantium Voluptatem"
                                    data-full-size-image-url = "<?php echo base_url(); ?>assets/img/p/2/5/25-large_default.jpg"
                                    >
                                    
                                    <img class="fliper_image img-responsive" src="<?php echo IMAGE_URL; ?><?php echo $products->image; ?>" data-full-size-image-url="<?php echo base_url(); ?>assets/img/p/2/5/25-large_default.jpg" alt="" />

                                  </a>
                                  
                                  
                                  
                                  <!-- <ul class="product-flags">
                                    <li class="new" style="background:#1d9dff;">New</li>
                                  </ul> -->
                                  
                                  
                                  <div class="outer-functional">
                                    <div class="functional-buttons">
                                      
                                      <a href="<?php echo base_url(); ?>single_ProductDetail<?php echo base64_encode('pd1234'); ?>_page?ee=<?php echo base64_encode($products->id); ?>" class="quick-view"  >
                                        <i class="material-icons search">&#xE417;</i> Quick view
                                      </a>
                                       

                                      
                                      
                                      <!-- <div class="product-actions">
                                        <form action="<?php echo base_url(); ?>Cart/add" method="post" class="add-to-cart-or-refresh">
                                          <input type="hidden" name="token" value="f6ea937a766343139d0cc27dc915cb03">
                                           <input type="hidden" name="p_id" value="<?php echo $products->id; ?>" > 
                                            <input type="hidden" name="p_name" value="<?php echo $products->name; ?>" > 
                                            <input type="hidden" name="p_category" value="<?php echo $products->category_id; ?>" > 
                                            <input type="hidden" name="p_subcategoryId" value="<?php echo $products->subcategory_id; ?>" > 
                                            <input type="hidden" name="p_qty" value="1" > 
                                           
                                            <input type="hidden" name="p_price" value="<?php echo $products->price; ?>" >
                                            <input type="hidden" name="p_image" value="<?php echo $products->image; ?>" > 
                                            <?php $total_price = ($products->price)*(1); ?>
                                            <input type="hidden" name="p_total" value="<?php echo $total_price; ?>" >
                                          <button class="btn btn-primary add-to-cart" data-button-action="add-to-cart" type="submit" >
                                            Add to cart
                                          </button>
                                        </form>
                                      </div> -->
                                      
                                      
                                    </div>
                                  </div>  
                                </div>

                                <div class="product-description">
                                  
                                  <span class="h3 product-title" itemprop="name"><a href="<?php echo base_url(); ?>single_ProductDetail<?php echo base64_encode('pd1234'); ?>_page?ee=<?php echo base64_encode($products->id); ?>"><?php echo $products->name; ?></a></span>
                                  

                                  
                                  <div class="product-price-and-shipping">
                                    
                                    

                                    <span itemprop="price" class="price">₹<?php echo $products->price; ?></span>

                                    

                                    
                                  </div>
                                  
                                  
                                  
                                  
                                    <div class="comments_note">
                                    <div class="star_content clearfix">
                                    <div class="product-reference">
                                    <label class="label">Product code: </label>
                                    <span itemprop="sku"><?php echo $products->code; ?></span>
                                    </div>
                                    </div>
                                    <span class="total-rating">0 Review(s)&nbsp</span>
                                  </div>
                                  
                                  <div class="highlighted-informations hidden-sm-down">
                                    
                                    
                                    <div class="variant-links">
                                      <a href="#"
                                      class="color"
                                      title="White"
                                      
                                      style="background-color: #ffffff"           ><span class="sr-only">White</span></a>
                                      <a href="#"
                                      class="color"
                                      title="Green"
                                      
                                      style="background-color: #A0D468"           ><span class="sr-only">Green</span></a>
                                      <a href="#"
                                      class="color"
                                      title="Yellow"
                                      
                                      style="background-color: #F1C40F"           ><span class="sr-only">Yellow</span></a>
                                      <span class="js-count count"></span>
                                    </div>
                                    
                                  </div>
                                </div>
                              </div>

                            </li>
                             <?php /* 
                            <li class="item">
                              
                              <div class="product-miniature js-product-miniature" data-id-product="14" data-id-product-attribute="260" itemscope itemtype="http://schema.org/Product">
                                <div class="thumbnail-container">
                                  
                                  <a href="index4304.html?id_product=14&amp;id_product_attribute=260&amp;rewrite=printed-chiffon-dress&amp;controller=product&amp;id_lang=1#/15-color-green" class="thumbnail product-thumbnail">
                                    <img
                                    src = "<?php echo base_url(); ?>assets/img/p/1/0/4/104-home_default.jpg"
                                    alt = "Occasion praesentium"
                                    data-full-size-image-url = "<?php echo base_url(); ?>assets/img/p/1/0/4/104-large_default.jpg"
                                    >
                                    
                                    <img class="fliper_image img-responsive" src="<?php echo base_url(); ?>assets/img/p/1/0/5/105-home_default.jpg" data-full-size-image-url="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/1/0/5/105-large_default.jpg" alt="" />

                                  </a>
                                  
                                  
                                  
                                  <ul class="product-flags">
                                    <li class="on-sale">On sale!</li>
                                    <li class="new" style="background:#1d9dff;">New</li>
                                  </ul>
                                  
                                  
                                  <div class="outer-functional">
                                    <div class="functional-buttons">
                                      
                                      <a href="#" class="quick-view" data-toggle="modal" data-target="#myModal" data-link-action="quickview">
                                        <i class="material-icons search">&#xE417;</i> Quick view
                                      </a>
                                      
                                      
                                      
                                      <div class="product-actions">
                                        <form action="https://codezeel.com/prestashop/PRS06/PRS060129/index.php?controller=cart" method="post" class="add-to-cart-or-refresh">
                                          <input type="hidden" name="token" value="f6ea937a766343139d0cc27dc915cb03">
                                          <input type="hidden" name="id_product" value="14" class="product_page_product_id">
                                          <input type="hidden" name="id_customization" value="0" class="product_customization_id">
                                          <button class="btn btn-primary add-to-cart" data-button-action="add-to-cart" type="submit"  data-toggle="modal" data-target="#blockcart-modal">
                                            Add to cart
                                          </button>
                                        </form>
                                      </div>
                                      
                                      
                                    </div>
                                  </div>  
                                </div>

                                <div class="product-description">
                                  
                                  <span class="h3 product-title" itemprop="name"><a href="index4304.html?id_product=14&amp;id_product_attribute=260&amp;rewrite=printed-chiffon-dress&amp;controller=product&amp;id_lang=1#/15-color-green">Occasion praesentium</a></span>
                                  

                                  
                                  <div class="product-price-and-shipping">
                                    

                                    <span class="regular-price">$99.00</span>
                                    <span class="discount-percentage">-3%</span>
                                    
                                    

                                    <span itemprop="price" class="price">$96.03</span>

                                    

                                    
                                  </div>
                                  
                                  
                                  
                                  
                                  <!-- <div class="comments_note">
                                    <div class="star_content clearfix">
                                      <div class="star star_on"></div>
                                      <div class="star star_on"></div>
                                      <div class="star star_on"></div>
                                      <div class="star star_on"></div>
                                      <div class="star star_on"></div>
                                    </div>
                                    <span class="total-rating">1 Review(s)&nbsp</span>
                                  </div> -->
                                  
                                  <div class="highlighted-informations hidden-sm-down">
                                    
                                    
                                    <div class="variant-links">
                                      <a href="index19a9.html?id_product=14&amp;id_product_attribute=294&amp;rewrite=printed-chiffon-dress&amp;controller=product&amp;id_lang=1#/5-color-grey"
                                      class="color"
                                      title="Grey"
                                      
                                      style="background-color: #AAB2BD"           ><span class="sr-only">Grey</span></a>
                                      <a href="index40fa.html?id_product=14&amp;id_product_attribute=293&amp;rewrite=printed-chiffon-dress&amp;controller=product&amp;id_lang=1#/11-color-black"
                                      class="color"
                                      title="Black"
                                      
                                      style="background-color: #434A54"           ><span class="sr-only">Black</span></a>
                                      <a href="index4304.html?id_product=14&amp;id_product_attribute=260&amp;rewrite=printed-chiffon-dress&amp;controller=product&amp;id_lang=1#/15-color-green"
                                      class="color"
                                      title="Green"
                                      
                                      style="background-color: #A0D468"           ><span class="sr-only">Green</span></a>
                                      <span class="js-count count"></span>
                                    </div>
                                    
                                  </div>
                                </div>
                              </div>

                            </li>
                            <li class="item">
                              
                              <div class="product-miniature js-product-miniature" data-id-product="13" data-id-product-attribute="241" itemscope itemtype="http://schema.org/Product">
                                <div class="thumbnail-container">
                                  
                                  <a href="index9863.html?id_product=13&amp;id_product_attribute=241&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/1-size-s/8-color-white" class="thumbnail product-thumbnail">
                                    <img
                                    src = "<?php echo base_url(); ?>assets/img/p/9/6/96-home_default.jpg"
                                    alt = "Laudant doloremque"
                                    data-full-size-image-url = "<?php echo base_url(); ?>assets/img/p/9/6/96-large_default.jpg"
                                    >
                                    
                                    <img class="fliper_image img-responsive" src="<?php echo base_url(); ?>assets/img/p/9/9/99-home_default.jpg" data-full-size-image-url="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/9/9/99-large_default.jpg" alt="" />

                                  </a>
                                  
                                  
                                  
                                  <ul class="product-flags">
                                    <li class="on-sale">On sale!</li>
                                    <li class="new" style="background:#1d9dff;">New</li>
                                  </ul>
                                  
                                  
                                  <div class="outer-functional">
                                    <div class="functional-buttons">
                                      
                                      <a href="#" class="quick-view" data-toggle="modal" data-target="#myModal" data-link-action="quickview">
                                        <i class="material-icons search">&#xE417;</i> Quick view
                                      </a>
                                      
                                      
                                      
                                      <div class="product-actions">
                                        <form action="https://codezeel.com/prestashop/PRS06/PRS060129/index.php?controller=cart" method="post" class="add-to-cart-or-refresh">
                                          <input type="hidden" name="token" value="f6ea937a766343139d0cc27dc915cb03">
                                          <input type="hidden" name="id_product" value="13" class="product_page_product_id">
                                          <input type="hidden" name="id_customization" value="0" class="product_customization_id">
                                          <button class="btn btn-primary add-to-cart" data-button-action="add-to-cart" type="submit"  data-toggle="modal" data-target="#blockcart-modal">
                                            Add to cart
                                          </button>
                                        </form>
                                      </div>
                                      
                                      
                                    </div>
                                  </div>  
                                </div>

                                <div class="product-description">
                                  
                                  <span class="h3 product-title" itemprop="name"><a href="index9863.html?id_product=13&amp;id_product_attribute=241&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/1-size-s/8-color-white">Laudant doloremque</a></span>
                                  

                                  
                                  <div class="product-price-and-shipping">
                                    

                                    <span class="regular-price">$91.00</span>
                                    
                                    

                                    <span itemprop="price" class="price">$85.00</span>

                                    

                                    
                                  </div>
                                  
                                  
                                  
                                  
                                  <!-- <div class="comments_note">
                                    <div class="star_content clearfix">
                                      <div class="star"></div>
                                      <div class="star"></div>
                                      <div class="star"></div>
                                      <div class="star"></div>
                                      <div class="star"></div>
                                    </div>
                                    <span class="total-rating">0 Review(s)&nbsp</span>
                                  </div> -->
                                  
                                  <div class="highlighted-informations hidden-sm-down">
                                    
                                    
                                    <div class="variant-links">
                                      <a href="index7222.html?id_product=13&amp;id_product_attribute=235&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/3-size-l/8-color-white"
                                      class="color"
                                      title="White"
                                      
                                      style="background-color: #ffffff"           ><span class="sr-only">White</span></a>
                                      <a href="indexf601.html?id_product=13&amp;id_product_attribute=236&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/3-size-l/14-color-blue"
                                      class="color"
                                      title="Blue"
                                      
                                      style="background-color: #5D9CEC"           ><span class="sr-only">Blue</span></a>
                                      <a href="indexef55.html?id_product=13&amp;id_product_attribute=237&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/3-size-l/15-color-green"
                                      class="color"
                                      title="Green"
                                      
                                      style="background-color: #A0D468"           ><span class="sr-only">Green</span></a>
                                      <span class="js-count count"></span>
                                    </div>
                                    
                                  </div>
                                </div>
                              </div>

                            </li>
                            <li class="item">
                              
                              <div class="product-miniature js-product-miniature" data-id-product="12" data-id-product-attribute="220" itemscope itemtype="http://schema.org/Product">
                                <div class="thumbnail-container">
                                  
                                  <a href="index7769.html?id_product=12&amp;id_product_attribute=220&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/1-size-s/15-color-green" class="thumbnail product-thumbnail">
                                    <img
                                    src = "<?php echo base_url(); ?>assets/img/p/9/2/92-home_default.jpg"
                                    alt = "Reprehenderit aliquam"
                                    data-full-size-image-url = "<?php echo base_url(); ?>assets/img/p/9/2/92-large_default.jpg"
                                    >
                                    
                                    <img class="fliper_image img-responsive" src="<?php echo base_url(); ?>assets/img/p/9/3/93-home_default.jpg" data-full-size-image-url="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/9/3/93-large_default.jpg" alt="" />

                                  </a>
                                  
                                  
                                  
                                  <ul class="product-flags">
                                    <li class="new" style="background:#1d9dff;">New</li>
                                  </ul>
                                  
                                  
                                  <div class="outer-functional">
                                    <div class="functional-buttons">
                                      
                                      <a href="#" class="quick-view" data-toggle="modal" data-target="#myModal" data-link-action="quickview">
                                        <i class="material-icons search">&#xE417;</i> Quick view
                                      </a>
                                      
                                      
                                      
                                      <div class="product-actions">
                                        <form action="https://codezeel.com/prestashop/PRS06/PRS060129/index.php?controller=cart" method="post" class="add-to-cart-or-refresh">
                                          <input type="hidden" name="token" value="f6ea937a766343139d0cc27dc915cb03">
                                          <input type="hidden" name="id_product" value="12" class="product_page_product_id">
                                          <input type="hidden" name="id_customization" value="0" class="product_customization_id">
                                          <button class="btn btn-primary add-to-cart" data-button-action="add-to-cart" type="submit"  data-toggle="modal" data-target="#blockcart-modal">
                                            Add to cart
                                          </button>
                                        </form>
                                      </div>
                                      
                                      
                                    </div>
                                  </div>  
                                </div>

                                <div class="product-description">
                                  
                                  <span class="h3 product-title" itemprop="name"><a href="index7769.html?id_product=12&amp;id_product_attribute=220&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/1-size-s/15-color-green">Reprehenderit aliquam</a></span>
                                  

                                  
                                  <div class="product-price-and-shipping">
                                    
                                    

                                    <span itemprop="price" class="price">$112.00</span>

                                    

                                    
                                  </div>
                                  
                                  
                                  
                                  
                                  <!-- <div class="comments_note">
                                    <div class="star_content clearfix">
                                      <div class="star"></div>
                                      <div class="star"></div>
                                      <div class="star"></div>
                                      <div class="star"></div>
                                      <div class="star"></div>
                                    </div>
                                    <span class="total-rating">0 Review(s)&nbsp</span>
                                  </div> -->
                                  
                                  <div class="highlighted-informations hidden-sm-down">
                                    
                                    
                                    <div class="variant-links">
                                      <a href="indexa95f.html?id_product=12&amp;id_product_attribute=216&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/2-size-m/11-color-black"
                                      class="color"
                                      title="Black"
                                      
                                      style="background-color: #434A54"           ><span class="sr-only">Black</span></a>
                                      <a href="indexb23b.html?id_product=12&amp;id_product_attribute=215&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/2-size-m/14-color-blue"
                                      class="color"
                                      title="Blue"
                                      
                                      style="background-color: #5D9CEC"           ><span class="sr-only">Blue</span></a>
                                      <a href="indexfd75.html?id_product=12&amp;id_product_attribute=214&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/2-size-m/15-color-green"
                                      class="color"
                                      title="Green"
                                      
                                      style="background-color: #A0D468"           ><span class="sr-only">Green</span></a>
                                      <span class="js-count count"></span>
                                    </div>
                                    
                                  </div>
                                </div>
                              </div>

                            </li>
                            <li class="item">
                              
                              <div class="product-miniature js-product-miniature" data-id-product="11" data-id-product-attribute="190" itemscope itemtype="http://schema.org/Product">
                                <div class="thumbnail-container">
                                  
                                  <a href="index6c33.html?id_product=11&amp;id_product_attribute=190&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/3-size-l/14-color-blue/20-shoes_size-37" class="thumbnail product-thumbnail">
                                    <img
                                    src = "<?php echo base_url(); ?>assets/img/p/8/6/86-home_default.jpg"
                                    alt = "Occaecat voluptas"
                                    data-full-size-image-url = "<?php echo base_url(); ?>assets/img/p/8/6/86-large_default.jpg"
                                    >
                                    
                                    <img class="fliper_image img-responsive" src="<?php echo base_url(); ?>assets/img/p/8/7/87-home_default.jpg" data-full-size-image-url="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/8/7/87-large_default.jpg" alt="" />

                                  </a>
                                  
                                  
                                  
                                  <ul class="product-flags">
                                    <li class="on-sale">On sale!</li>
                                    <li class="new" style="background:#1d9dff;">New</li>
                                  </ul>
                                  
                                  
                                  <div class="outer-functional">
                                    <div class="functional-buttons">
                                      
                                      <a href="#" class="quick-view" data-toggle="modal" data-target="#myModal" data-link-action="quickview">
                                        <i class="material-icons search">&#xE417;</i> Quick view
                                      </a>
                                      
                                      
                                      
                                      <div class="product-actions">
                                        <form action="https://codezeel.com/prestashop/PRS06/PRS060129/index.php?controller=cart" method="post" class="add-to-cart-or-refresh">
                                          <input type="hidden" name="token" value="f6ea937a766343139d0cc27dc915cb03">
                                          <input type="hidden" name="id_product" value="11" class="product_page_product_id">
                                          <input type="hidden" name="id_customization" value="0" class="product_customization_id">
                                          <button class="btn btn-primary add-to-cart" data-button-action="add-to-cart" type="submit"  data-toggle="modal" data-target="#blockcart-modal">
                                            Add to cart
                                          </button>
                                        </form>
                                      </div>
                                      
                                      
                                    </div>
                                  </div>  
                                </div>

                                <div class="product-description">
                                  
                                  <span class="h3 product-title" itemprop="name"><a href="index6c33.html?id_product=11&amp;id_product_attribute=190&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/3-size-l/14-color-blue/20-shoes_size-37">Occaecat voluptas</a></span>
                                  

                                  
                                  <div class="product-price-and-shipping">
                                    

                                    <span class="regular-price">$94.00</span>
                                    <span class="discount-percentage">-2%</span>
                                    
                                    

                                    <span itemprop="price" class="price">$92.12</span>

                                    

                                    
                                  </div>
                                  
                                  
                                  
                                  
                                  <!-- <div class="comments_note">
                                    <div class="star_content clearfix">
                                      <div class="star"></div>
                                      <div class="star"></div>
                                      <div class="star"></div>
                                      <div class="star"></div>
                                      <div class="star"></div>
                                    </div>
                                    <span class="total-rating">0 Review(s)&nbsp</span>
                                  </div> -->
                                  
                                  <div class="highlighted-informations hidden-sm-down">
                                    
                                    
                                    <div class="variant-links">
                                      <a href="index2a10.html?id_product=11&amp;id_product_attribute=193&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/2-size-m/14-color-blue/20-shoes_size-37"
                                      class="color"
                                      title="Blue"
                                      
                                      style="background-color: #5D9CEC"           ><span class="sr-only">Blue</span></a>
                                      <a href="index064a.html?id_product=11&amp;id_product_attribute=197&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/3-size-l/15-color-green/19-shoes_size-36"
                                      class="color"
                                      title="Green"
                                      
                                      style="background-color: #A0D468"           ><span class="sr-only">Green</span></a>
                                      <a href="indexf7e5.html?id_product=11&amp;id_product_attribute=195&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/2-size-m/16-color-yellow/20-shoes_size-37"
                                      class="color"
                                      title="Yellow"
                                      
                                      style="background-color: #F1C40F"           ><span class="sr-only">Yellow</span></a>
                                      <span class="js-count count"></span>
                                    </div>
                                    
                                  </div>
                                </div>
                              </div>

                            </li>
                            <li class="item">
                              
                              <div class="product-miniature js-product-miniature" data-id-product="10" data-id-product-attribute="184" itemscope itemtype="http://schema.org/Product">
                                <div class="thumbnail-container">
                                  
                                  <a href="indexa397.html?id_product=10&amp;id_product_attribute=184&amp;rewrite=printed-dress&amp;controller=product&amp;id_lang=1#/2-size-m/11-color-black" class="thumbnail product-thumbnail">
                                    <img
                                    src = "<?php echo base_url(); ?>assets/img/p/8/0/80-home_default.jpg"
                                    alt = "Necessitatibus"
                                    data-full-size-image-url = "<?php echo base_url(); ?>assets/img/p/8/0/80-large_default.jpg"
                                    >
                                    
                                    <img class="fliper_image img-responsive" src="<?php echo base_url(); ?>assets/img/p/8/1/81-home_default.jpg" data-full-size-image-url="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/8/1/81-large_default.jpg" alt="" />

                                  </a>
                                  
                                  
                                  
                                  <ul class="product-flags">
                                    <li class="new" style="background:#1d9dff;">New</li>
                                  </ul>
                                  
                                  
                                  <div class="outer-functional">
                                    <div class="functional-buttons">
                                      
                                      <a href="#" class="quick-view" data-toggle="modal" data-target="#myModal" data-link-action="quickview">
                                        <i class="material-icons search">&#xE417;</i> Quick view
                                      </a>
                                      
                                      
                                      
                                      <div class="product-actions">
                                        <form action="https://codezeel.com/prestashop/PRS06/PRS060129/index.php?controller=cart" method="post" class="add-to-cart-or-refresh">
                                          <input type="hidden" name="token" value="f6ea937a766343139d0cc27dc915cb03">
                                          <input type="hidden" name="id_product" value="10" class="product_page_product_id">
                                          <input type="hidden" name="id_customization" value="0" class="product_customization_id">
                                          <button class="btn btn-primary add-to-cart" data-button-action="add-to-cart" type="submit"  data-toggle="modal" data-target="#blockcart-modal">
                                            Add to cart
                                          </button>
                                        </form>
                                      </div>
                                      
                                      
                                    </div>
                                  </div>  
                                </div>

                                <div class="product-description">
                                  
                                  <span class="h3 product-title" itemprop="name"><a href="indexa397.html?id_product=10&amp;id_product_attribute=184&amp;rewrite=printed-dress&amp;controller=product&amp;id_lang=1#/2-size-m/11-color-black">Necessitatibus</a></span>
                                  

                                  
                                  <div class="product-price-and-shipping">
                                    
                                    

                                    <span itemprop="price" class="price">$83.00</span>

                                    

                                    
                                  </div>
                                  
                                  
                                  
                                  
                                  <!-- <div class="comments_note">
                                    <div class="star_content clearfix">
                                      <div class="star"></div>
                                      <div class="star"></div>
                                      <div class="star"></div>
                                      <div class="star"></div>
                                      <div class="star"></div>
                                    </div>
                                    <span class="total-rating">0 Review(s)&nbsp</span>
                                  </div> -->
                                  
                                  <div class="highlighted-informations hidden-sm-down">
                                    
                                    
                                    <div class="variant-links">
                                      <a href="indexdea2.html?id_product=10&amp;id_product_attribute=186&amp;rewrite=printed-dress&amp;controller=product&amp;id_lang=1#/2-size-m/5-color-grey"
                                      class="color"
                                      title="Grey"
                                      
                                      style="background-color: #AAB2BD"           ><span class="sr-only">Grey</span></a>
                                      <a href="indexf185.html?id_product=10&amp;id_product_attribute=185&amp;rewrite=printed-dress&amp;controller=product&amp;id_lang=1#/2-size-m/8-color-white"
                                      class="color"
                                      title="White"
                                      
                                      style="background-color: #ffffff"           ><span class="sr-only">White</span></a>
                                      <a href="indexa397.html?id_product=10&amp;id_product_attribute=184&amp;rewrite=printed-dress&amp;controller=product&amp;id_lang=1#/2-size-m/11-color-black"
                                      class="color"
                                      title="Black"
                                      
                                      style="background-color: #434A54"           ><span class="sr-only">Black</span></a>
                                      <span class="js-count count"></span>
                                    </div>
                                    
                                  </div>
                                </div>
                              </div>

                            </li>
                            <li class="item">
                              
                              <div class="product-miniature js-product-miniature" data-id-product="9" data-id-product-attribute="169" itemscope itemtype="http://schema.org/Product">
                                <div class="thumbnail-container">
                                  
                                  <a href="indexfb10.html?id_product=9&amp;id_product_attribute=169&amp;rewrite=blouse&amp;controller=product&amp;id_lang=1#/2-size-m/14-color-blue" class="thumbnail product-thumbnail">
                                    <img
                                    src = "<?php echo base_url(); ?>assets/img/p/7/2/72-home_default.jpg"
                                    alt = "Laborum eveniet"
                                    data-full-size-image-url = "<?php echo base_url(); ?>assets/<?php echo base_url(); ?>assets/img/p/7/2/72-large_default.jpg"
                                    >
                                    
                                    <img class="fliper_image img-responsive" src="<?php echo base_url(); ?>assets/img/p/7/4/74-home_default.jpg" data-full-size-image-url="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/7/4/74-large_default.jpg" alt="" />

                                  </a>
                                  
                                  
                                  
                                  <ul class="product-flags">
                                    <li class="on-sale">On sale!</li>
                                    <li class="new" style="background:#1d9dff;">New</li>
                                  </ul>
                                  
                                  
                                  <div class="outer-functional">
                                    <div class="functional-buttons">
                                      
                                      <a href="#" class="quick-view" data-toggle="modal" data-target="#myModal" data-link-action="quickview">
                                        <i class="material-icons search">&#xE417;</i> Quick view
                                      </a>
                                      
                                      
                                      
                                      <div class="product-actions">
                                        <form action="https://codezeel.com/prestashop/PRS06/PRS060129/index.php?controller=cart" method="post" class="add-to-cart-or-refresh">
                                          <input type="hidden" name="token" value="f6ea937a766343139d0cc27dc915cb03">
                                          <input type="hidden" name="id_product" value="9" class="product_page_product_id">
                                          <input type="hidden" name="id_customization" value="0" class="product_customization_id">
                                          <button class="btn btn-primary add-to-cart" data-button-action="add-to-cart" type="submit"  data-toggle="modal" data-target="#blockcart-modal">
                                            Add to cart
                                          </button>
                                        </form>
                                      </div>
                                      
                                      
                                    </div>
                                  </div>  
                                </div>

                                <div class="product-description">
                                  
                                  <span class="h3 product-title" itemprop="name"><a href="indexfb10.html?id_product=9&amp;id_product_attribute=169&amp;rewrite=blouse&amp;controller=product&amp;id_lang=1#/2-size-m/14-color-blue">Laborum eveniet</a></span>
                                  

                                  
                                  <div class="product-price-and-shipping">
                                    

                                    <span class="regular-price">$99.00</span>
                                    <span class="discount-percentage">-5%</span>
                                    
                                    

                                    <span itemprop="price" class="price">$94.05</span>

                                    

                                    
                                  </div>
                                  
                                  
                                  
                                  
                                  <!-- <div class="comments_note">
                                    <div class="star_content clearfix">
                                      <div class="star"></div>
                                      <div class="star"></div>
                                      <div class="star"></div>
                                      <div class="star"></div>
                                      <div class="star"></div>
                                    </div>
                                    <span class="total-rating">0 Review(s)&nbsp</span>
                                  </div> -->
                                  
                                  <div class="highlighted-informations hidden-sm-down">
                                    
                                    
                                    <div class="variant-links">
                                      <a href="index5021.html?id_product=9&amp;id_product_attribute=170&amp;rewrite=blouse&amp;controller=product&amp;id_lang=1#/2-size-m/13-color-orange"
                                      class="color"
                                      title="Orange"
                                      
                                      style="background-color: #F39C11"           ><span class="sr-only">Orange</span></a>
                                      <a href="indexfb10.html?id_product=9&amp;id_product_attribute=169&amp;rewrite=blouse&amp;controller=product&amp;id_lang=1#/2-size-m/14-color-blue"
                                      class="color"
                                      title="Blue"
                                      
                                      style="background-color: #5D9CEC"           ><span class="sr-only">Blue</span></a>
                                      <a href="indexa70b.html?id_product=9&amp;id_product_attribute=171&amp;rewrite=blouse&amp;controller=product&amp;id_lang=1#/2-size-m/15-color-green"
                                      class="color"
                                      title="Green"
                                      
                                      style="background-color: #A0D468"           ><span class="sr-only">Green</span></a>
                                      <span class="js-count count"></span>
                                    </div>
                                    
                                  </div>
                                </div>
                              </div>

                            </li>
                            <li class="item">
                              
                              <div class="product-miniature js-product-miniature" data-id-product="8" data-id-product-attribute="284" itemscope itemtype="http://schema.org/Product">
                                <div class="thumbnail-container">
                                  
                                  <a href="indexd483.html?id_product=8&amp;id_product_attribute=284&amp;rewrite=faded-short-sleeves-tshirt&amp;controller=product&amp;id_lang=1#/1-size-s/13-color-orange" class="thumbnail product-thumbnail">
                                    <img
                                    src = "<?php echo base_url(); ?>assets/img/p/6/8/68-home_default.jpg"
                                    alt = "Voluptates repudiandae"
                                    data-full-size-image-url = "<?php echo base_url(); ?>assets/img/p/6/8/68-large_default.jpg"
                                    >
                                    
                                    <img class="fliper_image img-responsive" src="<?php echo base_url(); ?>assets/img/p/6/9/69-home_default.jpg" data-full-size-image-url="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/6/9/69-large_default.jpg" alt="" />

                                  </a>
                                  
                                  
                                  
                                  <ul class="product-flags">
                                    <li class="new" style="background:#1d9dff;">New</li>
                                  </ul>
                                  
                                  
                                  <div class="outer-functional">
                                    <div class="functional-buttons">
                                      
                                      <a href="#" class="quick-view" data-toggle="modal" data-target="#myModal" data-link-action="quickview">
                                        <i class="material-icons search">&#xE417;</i> Quick view
                                      </a>
                                      
                                      
                                      
                                      <div class="product-actions">
                                        <form action="https://codezeel.com/prestashop/PRS06/PRS060129/index.php?controller=cart" method="post" class="add-to-cart-or-refresh">
                                          <input type="hidden" name="token" value="f6ea937a766343139d0cc27dc915cb03">
                                          <input type="hidden" name="id_product" value="8" class="product_page_product_id">
                                          <input type="hidden" name="id_customization" value="0" class="product_customization_id">
                                          <button class="btn btn-primary add-to-cart" data-button-action="add-to-cart" type="submit"  data-toggle="modal" data-target="#blockcart-modal">
                                            Add to cart
                                          </button>
                                        </form>
                                      </div>
                                      
                                      
                                    </div>
                                  </div>  
                                </div>

                                <div class="product-description">
                                  
                                  <span class="h3 product-title" itemprop="name"><a href="indexd483.html?id_product=8&amp;id_product_attribute=284&amp;rewrite=faded-short-sleeves-tshirt&amp;controller=product&amp;id_lang=1#/1-size-s/13-color-orange">Voluptates repudiandae</a></span>
                                  

                                  
                                  <div class="product-price-and-shipping">
                                    
                                    

                                    <span itemprop="price" class="price">$105.00</span>

                                    

                                    
                                  </div>
                                  
                                  
                                  
                                  
                                  <!-- <div class="comments_note">
                                    <div class="star_content clearfix">
                                      <div class="star"></div>
                                      <div class="star"></div>
                                      <div class="star"></div>
                                      <div class="star"></div>
                                      <div class="star"></div>
                                    </div>
                                    <span class="total-rating">0 Review(s)&nbsp</span>
                                  </div> -->
                                  
                                  <div class="highlighted-informations hidden-sm-down">
                                    
                                    
                                    <div class="variant-links">
                                      <a href="index82e5.html?id_product=8&amp;id_product_attribute=287&amp;rewrite=faded-short-sleeves-tshirt&amp;controller=product&amp;id_lang=1#/2-size-m/13-color-orange"
                                      class="color"
                                      title="Orange"
                                      
                                      style="background-color: #F39C11"           ><span class="sr-only">Orange</span></a>
                                      <a href="index1622.html?id_product=8&amp;id_product_attribute=286&amp;rewrite=faded-short-sleeves-tshirt&amp;controller=product&amp;id_lang=1#/1-size-s/14-color-blue"
                                      class="color"
                                      title="Blue"
                                      
                                      style="background-color: #5D9CEC"           ><span class="sr-only">Blue</span></a>
                                      <a href="indexe74a.html?id_product=8&amp;id_product_attribute=285&amp;rewrite=faded-short-sleeves-tshirt&amp;controller=product&amp;id_lang=1#/1-size-s/16-color-yellow"
                                      class="color"
                                      title="Yellow"
                                      
                                      style="background-color: #F1C40F"           ><span class="sr-only">Yellow</span></a>
                                      <span class="js-count count"></span>
                                    </div>
                                    
                                  </div>
                                </div>
                              </div>

                            </li>
                             */ ?>
                          <?php } ?>
                            
                          </ul>
                          
                          <div class="customNavigation">
                            <a class="btn prev newproduct_prev">&nbsp;</a>
                            <a class="btn next newproduct_next">&nbsp;</a>
                          </div>
                          
                        </div>
                      </section>


                    </div>
                    <div id="bestseller" class="cz_productinner tab-pane">
                      
                      <section class="bestseller-products">
                        <h2 class="h1 products-section-title text-uppercase">
                          Best Sellers
                        </h2>
                        <div class="products">  
                         <!-- Define Number of product for SLIDER -->
                         <ul id="bestseller-carousel" class="cz-carousel product_list">
                          
                            <?php 
                                $product= $this->Product_model->ProductListBytype('3');
                               foreach($product->result() as $products){ ?>
                               
                            <li class="item">
                              
                              <div class="product-miniature js-product-miniature" data-id-product="15" data-id-product-attribute="268" itemscope itemtype="#">
                                <div class="thumbnail-container">
                                  
                                  <a href="<?php echo base_url(); ?>single_ProductDetail<?php echo base64_encode('pd1234'); ?>_page?ee=<?php echo base64_encode($products->id); ?>" class="thumbnail product-thumbnail">
                                    <img
                                    src = "<?php echo IMAGE_URL; ?><?php echo $products->image; ?>"
                                    alt = "Accusantium Voluptatem"
                                    data-full-size-image-url = "<?php echo base_url(); ?>assets/img/p/2/5/25-large_default.jpg"
                                    >
                                    
                                    <img class="fliper_image img-responsive" src="<?php echo IMAGE_URL; ?><?php echo $products->image; ?>" data-full-size-image-url="<?php echo base_url(); ?>assets/img/p/2/5/25-large_default.jpg" alt="" />

                                  </a>
                                  
                                  
                                  
                                  <!-- <ul class="product-flags">
                                    <li class="new" style="background:#1d9dff;">New</li>
                                  </ul> -->
                                  
                                  
                                  <div class="outer-functional">
                                    <div class="functional-buttons">
                                      
                                      <a href="<?php echo base_url(); ?>single_ProductDetail<?php echo base64_encode('pd1234'); ?>_page?ee=<?php echo base64_encode($products->id); ?>" class="quick-view" >
                                        <i class="material-icons search">&#xE417;</i> Quick view
                                      </a>
                            
                                      
                                      <!-- <div class="product-actions">
                                        <form action="<?php echo base_url(); ?>Cart/add" method="post" class="add-to-cart-or-refresh">
                                          <input type="hidden" name="token" value="f6ea937a766343139d0cc27dc915cb03">
                                            <input type="hidden" name="p_id" value="<?php echo $products->id; ?>" > 
                                            <input type="hidden" name="p_name" value="<?php echo $products->name; ?>" > 
                                            <input type="hidden" name="p_category" value="<?php echo $products->category_id; ?>" > 
                                            <input type="hidden" name="p_subcategoryId" value="<?php echo $products->subcategory_id; ?>" > 
                                            <input type="hidden" name="p_qty" value="1" > 
                                            <textarea style="display: none;" name="p_description">
                                               <?php echo $products->description; ?>
                                             </textarea>  
                                            <input type="hidden" name="p_price" value="<?php echo $products->price; ?>" >
                                            <input type="hidden" name="p_image" value="<?php echo $products->image; ?>" > 
                                            <?php $total_price = ($products->price)*(1); ?>
                                            <input type="hidden" name="p_total" value="<?php echo $total_price; ?>" > 
                                            <button class="btn btn-primary add-to-cart" data-button-action="add-to-cart" type="submit"  >
                                            Add to cart
                                          </button>
                                        </form>
                                      </div> -->
                                      
                                      
                                    </div>
                                  </div>  
                                </div>

                                <div class="product-description">
                                  
                                  <span class="h3 product-title" itemprop="name"><a href="<?php echo base_url(); ?>single_ProductDetail<?php echo base64_encode('pd1234'); ?>_page?ee=<?php echo base64_encode($products->id); ?>"><?php echo $products->name; ?></a></span>
                                  

                                  
                                  <div class="product-price-and-shipping">
                                    
                                    

                                    <span itemprop="price" class="price">₹<?php echo $products->price; ?></span>

                                    

                                    
                                  </div>
                                  
                                  
                                  
                                  
                                   <div class="comments_note">
                                     <div class="product-reference">
                                    <label class="label">Product code: </label>
                                    <span itemprop="sku"><?php echo $products->code; ?></span>
                                    </div>
                                    
                                  </div>
                                  
                                  <div class="highlighted-informations hidden-sm-down">
                                    
                                    
                                    <div class="variant-links">
                                      <a href="#"
                                      class="color"
                                      title="White"
                                      
                                      style="background-color: #ffffff"           ><span class="sr-only">White</span></a>
                                      <a href="#"
                                      class="color"
                                      title="Green"
                                      
                                      style="background-color: #A0D468"           ><span class="sr-only">Green</span></a>
                                      <a href="#"
                                      class="color"
                                      title="Yellow"
                                      
                                      style="background-color: #F1C40F"           ><span class="sr-only">Yellow</span></a>
                                      <span class="js-count count"></span>
                                    </div>
                                    
                                  </div>
                                </div>
                              </div>

                            </li>
                          <?php } ?>
                        </ul>
                        
                        <div class="customNavigation">
                          <a class="btn prev bestseller_prev">&nbsp;</a>
                          <a class="btn next bestseller_next">&nbsp;</a>
                        </div>
                        
                      </div>
                    </section>

                  </div>
                </div>                  
              </div>
            </div>
          </section>
          

          <section class="special-products">
            <div class="container">
              <div class="special-products-inner">
                <h1 class="h1 products-section-title text-uppercase">
                  Special products
                </h1>
                <div class="special-product-wrapper">
                  <div class="products">
                   <!-- Define Number of product for SLIDER -->
                   <ul id="special-carousel" class="cz-carousel product_list">
                     <?php 
                                $product= $this->Product_model->ProductListBytype('4');
                               foreach($product->result() as $products){ ?>
                    <li class="item">
                      
                      <div class="product-miniature js-product-miniature" data-id-product="14" data-id-product-attribute="260" itemscope itemtype="#">
                        <div class="thumbnail-container">
                          
                          <a href="<?php echo base_url(); ?>single_ProductDetail<?php echo base64_encode('pd1234'); ?>_page?ee=<?php echo base64_encode($products->id); ?>" class="thumbnail product-thumbnail">
                            <img
                            src = "<?php echo IMAGE_URL; ?><?php echo $products->image; ?>"
                            alt = "Occasion praesentium"
                            data-full-size-image-url = "<?php echo base_url(); ?>assets/img/p/1/0/4/104-large_default.jpg"
                            >
                            
                            <img class="fliper_image img-responsive" src="<?php echo IMAGE_URL; ?><?php echo $products->image; ?>" data-full-size-image-url="<?php echo base_url(); ?>assets/img/p/1/0/4/104-large_default.jpg" alt="" />

                          </a>
                          
                          
                          
                          <!-- <ul class="product-flags">
                            <li class="on-sale">On sale!</li>
                            <li class="new" style="background:#1d9dff;">New</li>
                          </ul> -->
                          
                          
                          <div class="outer-functional">
                            <div class="functional-buttons">
                              
                              <a href="<?php echo base_url(); ?>single_ProductDetail<?php echo base64_encode('pd1234'); ?>_page?ee=<?php echo base64_encode($products->id); ?>" class="quick-view" >
                                <i class="material-icons search">&#xE417;</i> Quick view
                              </a>
                            


                              <!-- <div class="product-actions">
                                <form action="<?php echo base_url(); ?>Cart/add" method="post" class="add-to-cart-or-refresh">
                                  <input type="hidden" name="token" value="f6ea937a766343139d0cc27dc915cb03">
                                    <input type="hidden" name="p_id" value="<?php echo $products->id; ?>" > 
                                            <input type="hidden" name="p_name" value="<?php echo $products->name; ?>" > 
                                            <input type="hidden" name="p_category" value="<?php echo $products->category_id; ?>" > 
                                            <input type="hidden" name="p_subcategoryId" value="<?php echo $products->subcategory_id; ?>" > 
                                            <input type="hidden" name="p_qty" value="1" > 
                                            
                                            <input type="hidden" name="p_price" value="<?php echo $products->price; ?>" >
                                            <input type="hidden" name="p_image" value="<?php echo $products->image; ?>" > 
                                            <?php $total_price = ($products->price)*(1); ?>
                                            <input type="hidden" name="p_total" value="<?php echo $total_price; ?>" > 
                                            <button class="btn btn-primary add-to-cart" data-button-action="add-to-cart" type="submit"  >
                                    Add to cart
                                  </button>
                                </form>
                              </div> -->
                              
                              
                            </div>
                          </div>  
                        </div>

                        <div class="product-description">
                          
                          <span class="h3 product-title" itemprop="name"><a href="<?php echo base_url(); ?>single_ProductDetail<?php echo base64_encode('pd1234'); ?>_page?ee=<?php echo base64_encode($products->id); ?>"><?php echo $products->name; ?></a></span>
                          

                          
                          <div class="product-price-and-shipping">
                            

                            <span class="regular-price">₹<?php echo $products->price; ?></span>
                            <span class="discount-percentage">0%</span>
                            
                            

                            <span itemprop="price" class="price">₹<?php echo $products->price; ?></span>

                            

                            
                          </div>
                          
                          
                          
                          
                           <div class="comments_note">
                             <div class="product-reference">
                            <label class="label">Product code: </label>
                            <span itemprop="sku"><?php echo $products->code; ?></span>
                            </div>
                            
                          </div> 
                          
                          <div class="highlighted-informations hidden-sm-down">
                            
                            
                            <div class="variant-links">
                              <a href="#"
                              class="color"
                              title="Grey"
                              
                              style="background-color: #AAB2BD"           ><span class="sr-only">Grey</span></a>
                              <a href="#"
                              class="color"
                              title="Black"
                              
                              style="background-color: #434A54"           ><span class="sr-only">Black</span></a>
                              <a href="#"
                              class="color"
                              title="Green"
                              
                              style="background-color: #A0D468"           ><span class="sr-only">Green</span></a>
                              <span class="js-count count"></span>
                            </div>
                            
                          </div>
                        </div>
                      </div>

                    </li>
                  <?php /* <li class="item">
                      
                      <div class="product-miniature js-product-miniature" data-id-product="9" data-id-product-attribute="169" itemscope itemtype="http://schema.org/Product">
                        <div class="thumbnail-container">
                          
                          <a href="indexfb10.html?id_product=9&amp;id_product_attribute=169&amp;rewrite=blouse&amp;controller=product&amp;id_lang=1#/2-size-m/14-color-blue" class="thumbnail product-thumbnail">
                            <img
                            src = "<?php echo base_url(); ?>assets/img/p/7/2/72-home_default.jpg"
                            alt = "Laborum eveniet"
                            data-full-size-image-url = "<?php echo base_url(); ?>assets/img/p/7/2/72-large_default.jpg"
                            >
                            
                            <img class="fliper_image img-responsive" src="<?php echo base_url(); ?>assets/img/p/7/4/74-home_default.jpg" data-full-size-image-url="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/7/4/74-large_default.jpg" alt="" />

                          </a>
                          
                          
                          
                          <ul class="product-flags">
                            <li class="on-sale">On sale!</li>
                            <li class="new" style="background:#1d9dff;">New</li>
                          </ul>
                          
                          
                          <div class="outer-functional">
                            <div class="functional-buttons">
                              
                              <a href="#" class="quick-view" data-toggle="modal" data-target="#myModal" data-link-action="quickview">
                                <i class="material-icons search">&#xE417;</i> Quick view
                              </a>
                              
                              
                              
                              <div class="product-actions">
                                <form action="https://codezeel.com/prestashop/PRS06/PRS060129/index.php?controller=cart" method="post" class="add-to-cart-or-refresh">
                                  <input type="hidden" name="token" value="f6ea937a766343139d0cc27dc915cb03">
                                  <input type="hidden" name="id_product" value="9" class="product_page_product_id">
                                  <input type="hidden" name="id_customization" value="0" class="product_customization_id">
                                  <button class="btn btn-primary add-to-cart" data-button-action="add-to-cart" type="submit"  data-toggle="modal" data-target="#blockcart-modal">
                                    Add to cart
                                  </button>
                                </form>
                              </div>
                              
                              
                            </div>
                          </div>  
                        </div>

                        <div class="product-description">
                          
                          <span class="h3 product-title" itemprop="name"><a href="indexfb10.html?id_product=9&amp;id_product_attribute=169&amp;rewrite=blouse&amp;controller=product&amp;id_lang=1#/2-size-m/14-color-blue">Laborum eveniet</a></span>
                          

                          
                          <div class="product-price-and-shipping">
                            

                            <span class="regular-price">$99.00</span>
                            <span class="discount-percentage">-5%</span>
                            
                            

                            <span itemprop="price" class="price">$94.05</span>

                            

                            
                          </div>
                          
                          
                          
                          
                          <!-- <div class="comments_note">
                            <div class="star_content clearfix">
                              <div class="star"></div>
                              <div class="star"></div>
                              <div class="star"></div>
                              <div class="star"></div>
                              <div class="star"></div>
                            </div>
                            <span class="total-rating">0 Review(s)&nbsp</span>
                          </div> -->
                          
                          <div class="highlighted-informations hidden-sm-down">
                            
                            
                            <div class="variant-links">
                              <a href="index5021.html?id_product=9&amp;id_product_attribute=170&amp;rewrite=blouse&amp;controller=product&amp;id_lang=1#/2-size-m/13-color-orange"
                              class="color"
                              title="Orange"
                              
                              style="background-color: #F39C11"           ><span class="sr-only">Orange</span></a>
                              <a href="indexfb10.html?id_product=9&amp;id_product_attribute=169&amp;rewrite=blouse&amp;controller=product&amp;id_lang=1#/2-size-m/14-color-blue"
                              class="color"
                              title="Blue"
                              
                              style="background-color: #5D9CEC"           ><span class="sr-only">Blue</span></a>
                              <a href="indexa70b.html?id_product=9&amp;id_product_attribute=171&amp;rewrite=blouse&amp;controller=product&amp;id_lang=1#/2-size-m/15-color-green"
                              class="color"
                              title="Green"
                              
                              style="background-color: #A0D468"           ><span class="sr-only">Green</span></a>
                              <span class="js-count count"></span>
                            </div>
                            
                          </div>
                        </div>
                      </div>

                    </li>
                    <li class="item">
                      
                      <div class="product-miniature js-product-miniature" data-id-product="5" data-id-product-attribute="109" itemscope itemtype="http://schema.org/Product">
                        <div class="thumbnail-container">
                          
                          <a href="index7b5e.html?id_product=5&amp;id_product_attribute=109&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/3-size-l/14-color-blue/20-shoes_size-37" class="thumbnail product-thumbnail">
                            <img
                            src = "<?php echo base_url(); ?>assets/img/p/4/7/47-home_default.jpg"
                            alt = "Nostrud exercitation"
                            data-full-size-image-url = "<?php echo base_url(); ?>assets/img/p/4/7/47-large_default.jpg"
                            >
                            
                            <img class="fliper_image img-responsive" src="<?php echo base_url(); ?>assets/img/p/5/5/55-home_default.jpg" data-full-size-image-url="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/5/5/55-large_default.jpg" alt="" />

                          </a>
                          
                          
                          
                          <ul class="product-flags">
                            <li class="on-sale">On sale!</li>
                            <li class="new" style="background:#1d9dff;">New</li>
                          </ul>
                          
                          
                          <div class="outer-functional">
                            <div class="functional-buttons">
                              
                              <a href="#" class="quick-view" data-toggle="modal" data-target="#myModal" data-link-action="quickview">
                                <i class="material-icons search">&#xE417;</i> Quick view
                              </a>
                              
                              
                              
                              <div class="product-actions">
                                <form action="https://codezeel.com/prestashop/PRS06/PRS060129/index.php?controller=cart" method="post" class="add-to-cart-or-refresh">
                                  <input type="hidden" name="token" value="f6ea937a766343139d0cc27dc915cb03">
                                  <input type="hidden" name="id_product" value="5" class="product_page_product_id">
                                  <input type="hidden" name="id_customization" value="0" class="product_customization_id">
                                  <button class="btn btn-primary add-to-cart" data-button-action="add-to-cart" type="submit"  data-toggle="modal" data-target="#blockcart-modal">
                                    Add to cart
                                  </button>
                                </form>
                              </div>
                              
                              
                            </div>
                          </div>  
                        </div>

                        <div class="product-description">
                          
                          <span class="h3 product-title" itemprop="name"><a href="index7b5e.html?id_product=5&amp;id_product_attribute=109&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/3-size-l/14-color-blue/20-shoes_size-37">Nostrud exercitation</a></span>
                          

                          
                          <div class="product-price-and-shipping">
                            

                            <span class="regular-price">$98.00</span>
                            <span class="discount-percentage">-5%</span>
                            
                            

                            <span itemprop="price" class="price">$93.10</span>

                            

                            
                          </div>
                          
                          
                          
                          
                          <!-- <div class="comments_note">
                            <div class="star_content clearfix">
                              <div class="star star_on"></div>
                              <div class="star star_on"></div>
                              <div class="star star_on"></div>
                              <div class="star star_on"></div>
                              <div class="star star_on"></div>
                            </div>
                            <span class="total-rating">1 Review(s)&nbsp</span>
                          </div> -->
                          
                          <div class="highlighted-informations hidden-sm-down">
                            
                            
                            <div class="variant-links">
                              <a href="index3e01.html?id_product=5&amp;id_product_attribute=112&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/2-size-m/14-color-blue/20-shoes_size-37"
                              class="color"
                              title="Blue"
                              
                              style="background-color: #5D9CEC"           ><span class="sr-only">Blue</span></a>
                              <a href="indexe051.html?id_product=5&amp;id_product_attribute=110&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/3-size-l/15-color-green/20-shoes_size-37"
                              class="color"
                              title="Green"
                              
                              style="background-color: #A0D468"           ><span class="sr-only">Green</span></a>
                              <a href="index0fe1.html?id_product=5&amp;id_product_attribute=111&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/3-size-l/16-color-yellow/20-shoes_size-37"
                              class="color"
                              title="Yellow"
                              
                              style="background-color: #F1C40F"           ><span class="sr-only">Yellow</span></a>
                              <span class="js-count count"></span>
                            </div>
                            
                          </div>
                        </div>
                      </div>

                    </li>
                    <li class="item">
                      
                      <div class="product-miniature js-product-miniature" data-id-product="11" data-id-product-attribute="190" itemscope itemtype="http://schema.org/Product">
                        <div class="thumbnail-container">
                          
                          <a href="index6c33.html?id_product=11&amp;id_product_attribute=190&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/3-size-l/14-color-blue/20-shoes_size-37" class="thumbnail product-thumbnail">
                            <img
                            src = "<?php echo base_url(); ?>assets/img/p/8/6/86-home_default.jpg"
                            alt = "Occaecat voluptas"
                            data-full-size-image-url = "<?php echo base_url(); ?>assets/img/p/8/6/86-large_default.jpg"
                            >
                            
                            <img class="fliper_image img-responsive" src="<?php echo base_url(); ?>assets/img/p/8/7/87-home_default.jpg" data-full-size-image-url="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/8/7/87-large_default.jpg" alt="" />

                          </a>
                          
                          
                          
                          <ul class="product-flags">
                            <li class="on-sale">On sale!</li>
                            <li class="new" style="background:#1d9dff;">New</li>
                          </ul>
                          
                          
                          <div class="outer-functional">
                            <div class="functional-buttons">
                              
                              <a href="#" class="quick-view" data-toggle="modal" data-target="#myModal" data-link-action="quickview">
                                <i class="material-icons search">&#xE417;</i> Quick view
                              </a>
                              
                              
                              
                              <div class="product-actions">
                                <form action="https://codezeel.com/prestashop/PRS06/PRS060129/index.php?controller=cart" method="post" class="add-to-cart-or-refresh">
                                  <input type="hidden" name="token" value="f6ea937a766343139d0cc27dc915cb03">
                                  <input type="hidden" name="id_product" value="11" class="product_page_product_id">
                                  <input type="hidden" name="id_customization" value="0" class="product_customization_id">
                                  <button class="btn btn-primary add-to-cart" data-button-action="add-to-cart" type="submit"  data-toggle="modal" data-target="#blockcart-modal">
                                    Add to cart
                                  </button>
                                </form>
                              </div>
                              
                              
                            </div>
                          </div>  
                        </div>

                        <div class="product-description">
                          
                          <span class="h3 product-title" itemprop="name"><a href="index6c33.html?id_product=11&amp;id_product_attribute=190&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/3-size-l/14-color-blue/20-shoes_size-37">Occaecat voluptas</a></span>
                          

                          
                          <div class="product-price-and-shipping">
                            

                            <span class="regular-price">$94.00</span>
                            <span class="discount-percentage">-2%</span>
                            
                            

                            <span itemprop="price" class="price">$92.12</span>

                            

                            
                          </div>
                          
                          
                          
                          
                          <!-- <div class="comments_note">
                            <div class="star_content clearfix">
                              <div class="star"></div>
                              <div class="star"></div>
                              <div class="star"></div>
                              <div class="star"></div>
                              <div class="star"></div>
                            </div>
                            <span class="total-rating">0 Review(s)&nbsp</span>
                          </div> -->
                          
                          <div class="highlighted-informations hidden-sm-down">
                            
                            
                            <div class="variant-links">
                              <a href="index2a10.html?id_product=11&amp;id_product_attribute=193&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/2-size-m/14-color-blue/20-shoes_size-37"
                              class="color"
                              title="Blue"
                              
                              style="background-color: #5D9CEC"           ><span class="sr-only">Blue</span></a>
                              <a href="index064a.html?id_product=11&amp;id_product_attribute=197&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/3-size-l/15-color-green/19-shoes_size-36"
                              class="color"
                              title="Green"
                              
                              style="background-color: #A0D468"           ><span class="sr-only">Green</span></a>
                              <a href="indexf7e5.html?id_product=11&amp;id_product_attribute=195&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/2-size-m/16-color-yellow/20-shoes_size-37"
                              class="color"
                              title="Yellow"
                              
                              style="background-color: #F1C40F"           ><span class="sr-only">Yellow</span></a>
                              <span class="js-count count"></span>
                            </div>
                            
                          </div>
                        </div>
                      </div>

                    </li>
                    <li class="item">
                      
                      <div class="product-miniature js-product-miniature" data-id-product="13" data-id-product-attribute="241" itemscope itemtype="http://schema.org/Product">
                        <div class="thumbnail-container">
                          
                          <a href="index9863.html?id_product=13&amp;id_product_attribute=241&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/1-size-s/8-color-white" class="thumbnail product-thumbnail">
                            <img
                            src = "<?php echo base_url(); ?>assets/img/p/9/6/96-home_default.jpg"
                            alt = "Laudant doloremque"
                            data-full-size-image-url = "<?php echo base_url(); ?>assets/img/p/9/6/96-large_default.jpg"
                            >
                            
                            <img class="fliper_image img-responsive" src="<?php echo base_url(); ?>assets/img/p/9/9/99-home_default.jpg" data-full-size-image-url="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/9/9/99-large_default.jpg" alt="" />

                          </a>
                          
                          
                          
                          <ul class="product-flags">
                            <li class="on-sale">On sale!</li>
                            <li class="new" style="background:#1d9dff;">New</li>
                          </ul>
                          
                          
                          <div class="outer-functional">
                            <div class="functional-buttons">
                              
                              <a href="#" class="quick-view" data-toggle="modal" data-target="#myModal" data-link-action="quickview">
                                <i class="material-icons search">&#xE417;</i> Quick view
                              </a>
                              
                              
                              
                              <div class="product-actions">
                                <form action="https://codezeel.com/prestashop/PRS06/PRS060129/index.php?controller=cart" method="post" class="add-to-cart-or-refresh">
                                  <input type="hidden" name="token" value="f6ea937a766343139d0cc27dc915cb03">
                                  <input type="hidden" name="id_product" value="13" class="product_page_product_id">
                                  <input type="hidden" name="id_customization" value="0" class="product_customization_id">
                                  <button class="btn btn-primary add-to-cart" data-button-action="add-to-cart" type="submit"  data-toggle="modal" data-target="#blockcart-modal">
                                    Add to cart
                                  </button>
                                </form>
                              </div>
                              
                              
                            </div>
                          </div>  
                        </div>

                        <div class="product-description">
                          
                          <span class="h3 product-title" itemprop="name"><a href="index9863.html?id_product=13&amp;id_product_attribute=241&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/1-size-s/8-color-white">Laudant doloremque</a></span>
                          

                          
                          <div class="product-price-and-shipping">
                            

                            <span class="regular-price">$91.00</span>
                            
                            

                            <span itemprop="price" class="price">$85.00</span>

                            

                            
                          </div>
                          
                          
                          
                          
                         <!--  <div class="comments_note">
                            <div class="star_content clearfix">
                              <div class="star"></div>
                              <div class="star"></div>
                              <div class="star"></div>
                              <div class="star"></div>
                              <div class="star"></div>
                            </div>
                            <span class="total-rating">0 Review(s)&nbsp</span>
                          </div> -->
                          
                          <div class="highlighted-informations hidden-sm-down">
                            
                            
                            <div class="variant-links">
                              <a href="index7222.html?id_product=13&amp;id_product_attribute=235&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/3-size-l/8-color-white"
                              class="color"
                              title="White"
                              
                              style="background-color: #ffffff"           ><span class="sr-only">White</span></a>
                              <a href="indexf601.html?id_product=13&amp;id_product_attribute=236&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/3-size-l/14-color-blue"
                              class="color"
                              title="Blue"
                              
                              style="background-color: #5D9CEC"           ><span class="sr-only">Blue</span></a>
                              <a href="indexef55.html?id_product=13&amp;id_product_attribute=237&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/3-size-l/15-color-green"
                              class="color"
                              title="Green"
                              
                              style="background-color: #A0D468"           ><span class="sr-only">Green</span></a>
                              <span class="js-count count"></span>
                            </div>
                            
                          </div>
                        </div>
                      </div>

                    </li>
                    <li class="item">
                      
                      <div class="product-miniature js-product-miniature" data-id-product="2" data-id-product-attribute="56" itemscope itemtype="http://schema.org/Product">
                        <div class="thumbnail-container">
                          
                          <a href="index13b2.html?id_product=2&amp;id_product_attribute=56&amp;rewrite=blouse&amp;controller=product&amp;id_lang=1#/1-size-s/14-color-blue" class="thumbnail product-thumbnail">
                            <img
                            src = "<?php echo base_url(); ?>assets/img/p/3/0/30-home_default.jpg"
                            alt = "Exercitat Virginia"
                            data-full-size-image-url = "<?php echo base_url(); ?>assets/img/p/3/0/30-large_default.jpg"
                            >
                            
                            <img class="fliper_image img-responsive" src="<?php echo base_url(); ?>assets/img/p/3/1/31-home_default.jpg" data-full-size-image-url="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/3/1/31-large_default.jpg" alt="" />

                          </a>
                          
                          
                          
                          <ul class="product-flags">
                            <li class="on-sale">On sale!</li>
                            <li class="new" style="background:#1d9dff;">New</li>
                          </ul>
                          
                          
                          <div class="outer-functional">
                            <div class="functional-buttons">
                              
                              <a href="#" class="quick-view" data-toggle="modal" data-target="#myModal" data-link-action="quickview">
                                <i class="material-icons search">&#xE417;</i> Quick view
                              </a>
                              
                              
                              
                              <div class="product-actions">
                                <form action="https://codezeel.com/prestashop/PRS06/PRS060129/index.php?controller=cart" method="post" class="add-to-cart-or-refresh">
                                  <input type="hidden" name="token" value="f6ea937a766343139d0cc27dc915cb03">
                                  <input type="hidden" name="id_product" value="2" class="product_page_product_id">
                                  <input type="hidden" name="id_customization" value="0" class="product_customization_id">
                                  <button class="btn btn-primary add-to-cart" data-button-action="add-to-cart" type="submit"  data-toggle="modal" data-target="#blockcart-modal">
                                    Add to cart
                                  </button>
                                </form>
                              </div>
                              
                              
                            </div>
                          </div>  
                        </div>

                        <div class="product-description">
                          
                          <span class="h3 product-title" itemprop="name"><a href="index13b2.html?id_product=2&amp;id_product_attribute=56&amp;rewrite=blouse&amp;controller=product&amp;id_lang=1#/1-size-s/14-color-blue">Exercitat Virginia</a></span>
                          

                          
                          <div class="product-price-and-shipping">
                            

                            <span class="regular-price">$87.00</span>
                            <span class="discount-percentage">-5%</span>
                            
                            

                            <span itemprop="price" class="price">$82.65</span>

                            

                            
                          </div>
                          
                          
                          
                          
                          <!-- <div class="comments_note">
                            <div class="star_content clearfix">
                              <div class="star"></div>
                              <div class="star"></div>
                              <div class="star"></div>
                              <div class="star"></div>
                              <div class="star"></div>
                            </div>
                            <span class="total-rating">0 Review(s)&nbsp</span>
                          </div> -->
                          
                          <div class="highlighted-informations hidden-sm-down">
                            
                            
                            <div class="variant-links">
                              <a href="index741d.html?id_product=2&amp;id_product_attribute=58&amp;rewrite=blouse&amp;controller=product&amp;id_lang=1#/2-size-m/8-color-white"
                              class="color"
                              title="White"
                              
                              style="background-color: #ffffff"           ><span class="sr-only">White</span></a>
                              <a href="indexf85f.html?id_product=2&amp;id_product_attribute=55&amp;rewrite=blouse&amp;controller=product&amp;id_lang=1#/2-size-m/14-color-blue"
                              class="color"
                              title="Blue"
                              
                              style="background-color: #5D9CEC"           ><span class="sr-only">Blue</span></a>
                              <a href="indexfa11.html?id_product=2&amp;id_product_attribute=61&amp;rewrite=blouse&amp;controller=product&amp;id_lang=1#/2-size-m/16-color-yellow"
                              class="color"
                              title="Yellow"
                              
                              style="background-color: #F1C40F"           ><span class="sr-only">Yellow</span></a>
                              <span class="js-count count"></span>
                            </div>
                            
                          </div>
                        </div>
                      </div>

                    </li>
                    <li class="item">
                      
                      <div class="product-miniature js-product-miniature" data-id-product="7" data-id-product-attribute="275" itemscope itemtype="http://schema.org/Product">
                        <div class="thumbnail-container">
                          
                          <a href="index54ae.html?id_product=7&amp;id_product_attribute=275&amp;rewrite=printed-chiffon-dress&amp;controller=product&amp;id_lang=1#/1-size-s/15-color-green" class="thumbnail product-thumbnail">
                            <img
                            src = "<?php echo base_url(); ?>assets/img/p/6/0/60-home_default.jpg"
                            alt = "Praesentium voluptatum"
                            data-full-size-image-url = "<?php echo base_url(); ?>assets/img/p/6/0/60-large_default.jpg"
                            >
                            
                            <img class="fliper_image img-responsive" src="<?php echo base_url(); ?>assets/img/p/6/3/63-home_default.jpg" data-full-size-image-url="https://codezeel.com/prestashop/PRS06/PRS060129/img/p/6/3/63-large_default.jpg" alt="" />

                          </a>
                          
                          
                          
                          <ul class="product-flags">
                            <li class="discount">Reduced price</li>
                            <li class="new" style="background:#1d9dff;">New</li>
                          </ul>
                          
                          
                          <div class="outer-functional">
                            <div class="functional-buttons">
                              
                              <a href="#" class="quick-view" data-toggle="modal" data-target="#myModal" data-link-action="quickview">
                                <i class="material-icons search">&#xE417;</i> Quick view
                              </a>
                              
                              
                              
                              <div class="product-actions">
                                <form action="https://codezeel.com/prestashop/PRS06/PRS060129/index.php?controller=cart" method="post" class="add-to-cart-or-refresh">
                                  <input type="hidden" name="token" value="f6ea937a766343139d0cc27dc915cb03">
                                  <input type="hidden" name="id_product" value="7" class="product_page_product_id">
                                  <input type="hidden" name="id_customization" value="0" class="product_customization_id">
                                  <button class="btn btn-primary add-to-cart" data-button-action="add-to-cart" type="submit"  data-toggle="modal" data-target="#blockcart-modal">
                                    Add to cart
                                  </button>
                                </form>
                              </div>
                              
                              
                            </div>
                          </div>  
                        </div>

                        <div class="product-description">
                          
                          <span class="h3 product-title" itemprop="name"><a href="index54ae.html?id_product=7&amp;id_product_attribute=275&amp;rewrite=printed-chiffon-dress&amp;controller=product&amp;id_lang=1#/1-size-s/15-color-green">Praesentium voluptatum</a></span>
                          

                          
                          <div class="product-price-and-shipping">
                            

                            <span class="regular-price">$79.00</span>
                            
                            

                            <span itemprop="price" class="price">$75.00</span>

                            

                            
                          </div>
                          
                          
                          
                          
                          <!-- <div class="comments_note">
                            <div class="star_content clearfix">
                              <div class="star"></div>
                              <div class="star"></div>
                              <div class="star"></div>
                              <div class="star"></div>
                              <div class="star"></div>
                            </div>
                            <span class="total-rating">0 Review(s)&nbsp</span>
                          </div> -->
                          
                          <div class="highlighted-informations hidden-sm-down">
                            
                            
                            <div class="variant-links">
                              <a href="index74ca.html?id_product=7&amp;id_product_attribute=277&amp;rewrite=printed-chiffon-dress&amp;controller=product&amp;id_lang=1#/1-size-s/5-color-grey"
                              class="color"
                              title="Grey"
                              
                              style="background-color: #AAB2BD"           ><span class="sr-only">Grey</span></a>
                              <a href="indexff6f.html?id_product=7&amp;id_product_attribute=276&amp;rewrite=printed-chiffon-dress&amp;controller=product&amp;id_lang=1#/1-size-s/14-color-blue"
                              class="color"
                              title="Blue"
                              
                              style="background-color: #5D9CEC"           ><span class="sr-only">Blue</span></a>
                              <a href="indexa5bf.html?id_product=7&amp;id_product_attribute=278&amp;rewrite=printed-chiffon-dress&amp;controller=product&amp;id_lang=1#/2-size-m/15-color-green"
                              class="color"
                              title="Green"
                              
                              style="background-color: #A0D468"           ><span class="sr-only">Green</span></a>
                              <span class="js-count count"></span>
                            </div>
                            
                          </div>
                        </div>
                      </div>

                    </li>*/?>
                  <?php } ?>
                  </ul>
                  
                  <div class="customNavigation">
                    <a class="btn prev special_prev">&nbsp;</a>
                    <a class="btn next special_next">&nbsp;</a>
                  </div>
                  
                </div>
              </div>
            </div>
          </div>
        </section>

        <!-- Block Last post-->
        <div class="lastest_block block homeblog-latest"> 
          <div class="container">
            <div class="main-title">
              <h2 class="h1 products-section-title text-uppercase">
                <span>From The Blog</span>
              </h2>
            </div>
            
            <div class="homeblog-inner">
             <!-- Define Number of product for SLIDER -->
             <ul id="blog-carousel" class="ps-carousel product_list">
              
              <li class="blog-post item">
                <div class="blog-item">
                  <div class="blog-image-meta">
                    <div class="blog-image text-xs-center">
                      <a href="indexa3af.html?fc=module&amp;module=psblog&amp;id=6&amp;controller=blog&amp;id_lang=1" title="Curabitur at elit Vestibulum" class="link">
                        <img src="<?php echo base_url(); ?>assets/img/psblog/b/6/892_554/b-blog-4.jpg" alt="Curabitur at elit Vestibulum" class="img-fluid"/>
                        <span class="post-image-hover"></span>
                      </a>
                      <span class="blogicons">
                        <a title="Click to view Full Image" href="img/psblog/b/6/892_554/b-blog-4.jpg" data-lightbox="example-set" class="icon zoom">&nbsp;</a> 
                        <a title="Click to view Read More" href="indexa3af.html?fc=module&amp;module=psblog&amp;id=6&amp;controller=blog&amp;id_lang=1" class="icon readmore_link">&nbsp;</a>
                      </span>
                    </div>
                    <div class="blog-meta">                         
                      
                      <span class="blog-created">
                        <!-- day of week -->
                        18  <!-- day of month -->
                        Dec     <!-- month-->
                        2017        <!-- year -->
                      </time>
                    </span>
                    
                    
                  </div>  
                </div>
                
                <div class="blog-content-wrap">     
                  
                  <h4 class="title">
                    <a href="indexa3af.html?fc=module&amp;module=psblog&amp;id=6&amp;controller=blog&amp;id_lang=1" title="Curabitur at elit Vestibulum">Curabitur at elit Vestibulum</a>
                  </h4>
                  
                  <div class="blog-shortinfo">
                    Mi vitae magnis Fusce laoreet nibh felis porttitor laoreet Vestibulum...    
                  </div>              
                </div>
              </div>
            </li>
            <li class="blog-post item">
              <div class="blog-item">
                <div class="blog-image-meta">
                  <div class="blog-image text-xs-center">
                    <a href="indexa739.html?fc=module&amp;module=psblog&amp;id=7&amp;controller=blog&amp;id_lang=1" title="Morbi condimentum molestie Nam" class="link">
                      <img src="<?php echo base_url(); ?>assets/img/psblog/b/7/892_554/b-blog-5.jpg" alt="Morbi condimentum molestie Nam" class="img-fluid"/>
                      <span class="post-image-hover"></span>
                    </a>
                    <span class="blogicons">
                      <a title="Click to view Full Image" href="img/psblog/b/7/892_554/b-blog-5.jpg" data-lightbox="example-set" class="icon zoom">&nbsp;</a> 
                      <a title="Click to view Read More" href="indexa739.html?fc=module&amp;module=psblog&amp;id=7&amp;controller=blog&amp;id_lang=1" class="icon readmore_link">&nbsp;</a>
                    </span>
                  </div>
                  <div class="blog-meta">                         
                    
                    <span class="blog-created">
                      <!-- day of week -->
                      18  <!-- day of month -->
                      Dec     <!-- month-->
                      2017        <!-- year -->
                    </time>
                  </span>
                  
                  
                </div>  
              </div>
              
              <div class="blog-content-wrap">     
                
                <h4 class="title">
                  <a href="indexa739.html?fc=module&amp;module=psblog&amp;id=7&amp;controller=blog&amp;id_lang=1" title="Morbi condimentum molestie Nam">Morbi condimentum molestie Nam</a>
                </h4>
                
                <div class="blog-shortinfo">
                  Sed mauris Pellentesque elit Aliquam at lacus interdum nascetur elit ipsum....  
                </div>              
              </div>
            </div>
          </li>
          <li class="blog-post item">
            <div class="blog-item">
              <div class="blog-image-meta">
                <div class="blog-image text-xs-center">
                  <a href="indexa118.html?fc=module&amp;module=psblog&amp;id=8&amp;controller=blog&amp;id_lang=1" title="Turpis at eleifend Aenean porta" class="link">
                    <img src="<?php echo base_url(); ?>assets/img/psblog/b/8/892_554/b-blog-6.jpg" alt="Turpis at eleifend Aenean porta" class="img-fluid"/>
                    <span class="post-image-hover"></span>
                  </a>
                  <span class="blogicons">
                    <a title="Click to view Full Image" href="img/psblog/b/8/892_554/b-blog-6.jpg" data-lightbox="example-set" class="icon zoom">&nbsp;</a> 
                    <a title="Click to view Read More" href="indexa118.html?fc=module&amp;module=psblog&amp;id=8&amp;controller=blog&amp;id_lang=1" class="icon readmore_link">&nbsp;</a>
                  </span>
                </div>
                <div class="blog-meta">                         
                  
                  <span class="blog-created">
                    <!-- day of week -->
                    18  <!-- day of month -->
                    Dec     <!-- month-->
                    2017        <!-- year -->
                  </time>
                </span>
                
                
              </div>  
            </div>
            
            <div class="blog-content-wrap">     
              
              <h4 class="title">
                <a href="indexa118.html?fc=module&amp;module=psblog&amp;id=8&amp;controller=blog&amp;id_lang=1" title="Turpis at eleifend Aenean porta">Turpis at eleifend Aenean porta</a>
              </h4>
              
              <div class="blog-shortinfo">
                Turpis at eleifend ps mi elit Aenean porta ac sed faucibus. Nunc urna Morbi...  
              </div>              
            </div>
          </div>
        </li>
        <li class="blog-post item">
          <div class="blog-item">
            <div class="blog-image-meta">
              <div class="blog-image text-xs-center">
                <a href="indexa564.html?fc=module&amp;module=psblog&amp;id=9&amp;controller=blog&amp;id_lang=1" title="Nullam ullamcorper ornare molestie" class="link">
                  <img src="<?php echo base_url(); ?>assets/img/psblog/b/9/892_554/b-blog-7.jpg" alt="Nullam ullamcorper ornare molestie" class="img-fluid"/>
                  <span class="post-image-hover"></span>
                </a>
                <span class="blogicons">
                  <a title="Click to view Full Image" href="img/psblog/b/9/892_554/b-blog-7.jpg" data-lightbox="example-set" class="icon zoom">&nbsp;</a> 
                  <a title="Click to view Read More" href="indexa564.html?fc=module&amp;module=psblog&amp;id=9&amp;controller=blog&amp;id_lang=1" class="icon readmore_link">&nbsp;</a>
                </span>
              </div>
              <div class="blog-meta">                         
                
                <span class="blog-created">
                  <!-- day of week -->
                  18  <!-- day of month -->
                  Dec     <!-- month-->
                  2017        <!-- year -->
                </time>
              </span>
              
              
            </div>  
          </div>
          
          <div class="blog-content-wrap">     
            
            <h4 class="title">
              <a href="indexa564.html?fc=module&amp;module=psblog&amp;id=9&amp;controller=blog&amp;id_lang=1" title="Nullam ullamcorper ornare molestie">Nullam ullamcorper ornare molestie</a>
            </h4>
            
            <div class="blog-shortinfo">
              Suspendisse posuere, diam in bibendum lobortis, turpis ipsum aliquam risus,...  
            </div>              
          </div>
        </div>
      </li>
      <li class="blog-post item">
        <div class="blog-item">
          <div class="blog-image-meta">
            <div class="blog-image text-xs-center">
              <a href="index11b5.html?fc=module&amp;module=psblog&amp;id=5&amp;controller=blog&amp;id_lang=1" title="Urna pretium elit mauris cursus" class="link">
                <img src="<?php echo base_url(); ?>assets/img/psblog/b/5/892_554/b-blog-3.jpg" alt="Urna pretium elit mauris cursus" class="img-fluid"/>
                <span class="post-image-hover"></span>
              </a>
              <span class="blogicons">
                <a title="Click to view Full Image" href="img/psblog/b/5/892_554/b-blog-3.jpg" data-lightbox="example-set" class="icon zoom">&nbsp;</a> 
                <a title="Click to view Read More" href="index11b5.html?fc=module&amp;module=psblog&amp;id=5&amp;controller=blog&amp;id_lang=1" class="icon readmore_link">&nbsp;</a>
              </span>
            </div>
            <div class="blog-meta">                         
              
              <span class="blog-created">
                <!-- day of week -->
                16  <!-- day of month -->
                Dec     <!-- month-->
                2017        <!-- year -->
              </time>
            </span>
            
            
          </div>  
        </div>
        
        <div class="blog-content-wrap">     
          
          <h4 class="title">
            <a href="index11b5.html?fc=module&amp;module=psblog&amp;id=5&amp;controller=blog&amp;id_lang=1" title="Urna pretium elit mauris cursus">Urna pretium elit mauris cursus</a>
          </h4>
          
          <div class="blog-shortinfo">
            Mi vitae magnis Fusce laoreet nibh felis porttitor laoreet Vestibulum...    
          </div>              
        </div>
      </div>
    </li>
  </ul>
  
  <div class="customNavigation">
    <a class="btn prev blog_prev">&nbsp;</a>
    <a class="btn next blog_next">&nbsp;</a>
  </div>
</div>
</div>
</div>
<!-- /Block Last Post -->




</section>

</section>



</div>



</div>
</div>

</section>

<!-- footer -->
<?php $this->load->view('common/imt/footer1'); ?>
<!-- //footer -->
</main>


<script type="text/javascript" src="<?php echo base_url(); ?>assets/themes/Fashcod/assets/cache/bottom-9149e8.js" ></script>

<?php $this->load->view('common/imt/customer'); ?>




</body>



</html>
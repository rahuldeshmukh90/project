<body id="module-psblog-list" class="lang-en country-us currency-usd layout-left-column page-module-psblog-list tax-display-disabled">
	<main id="page">
		<header id="header">
			<div class="header-banner">
			</div>
			<nav class="header-nav">
				<div class="container">
					<div class="left-nav">
					</div>
					<div class="right-nav">
					</div>
				</div>
			</nav>
			<!-- header-bot -->
			<?php $this->load->view('common/imt/header'); ?>
			<!-- //header-bot -->
			<!-- banner -->
			<?php $this->load->view('common/imt/navbar'); ?>

		</header>



		<aside id="notifications">
			<div class="container">



			</div>
		</aside>



		<nav data-depth="1" class="breadcrumb">
			<div class="container">
				<ol itemscope itemtype="#">

					<li itemprop="itemListElement" itemscope itemtype="#">
						<a itemprop="item" href="index.html">
							<span itemprop="name">Home</span>
						</a>
						<meta itemprop="position" content="1">
					</li>

				</ol>
			</div>
		</nav>


		<section id="wrapper">

			<div class="container">
				<div id="columns_inner">

					<div id="left-column" class="col-xs-12" style="width:24.4%">



						<div class="block-categories block">
							<h4 class="block_title hidden-md-down">
								<a href="#">Home</a>
							</h4>
							<h4 class="block_title hidden-lg-up" data-target="#block_categories_toggle" data-toggle="collapse">
								<a href="#">Home</a>
								<span class="pull-xs-right">
									<span class="navbar-toggler collapse-icons">
										<i class="fa-icon add"></i>
										<i class="fa-icon remove"></i>
									</span>
								</span>
							</h4>
							<div id="block_categories_toggle" class="block_content collapse">
								<ul class="category-top-menu">
									<li>
										<ul class="category-sub-menu">
											<?php $category = $this->Product_model->getCategoryListlimit('8');  

											foreach ($category->result() as $menus) { ?>
											<li data-depth="0">
												<?php $subcategory = $this->Product_model->getSubcategoryBycatId($menus->id); 
												$value = sizeof($subcategory->result());  ?>

												<a href="#"><?php echo $menus->name; ?></a>
												<?php if (($value)!=0) { ?>
												<div class="navbar-toggler collapse-icons" data-toggle="collapse" data-target="#exCollapsingNavbar<?php echo $menus->id; ?>">
													<span class="add"></span>
													<span class="remove"></span>
												</div>
												<?php  } ?>
												<?php if (($value)!=0) { ?>
												<div class="collapse" id="exCollapsingNavbar<?php echo $menus->id; ?>">
													<ul class="category-sub-menu">
														<?php foreach ($subcategory->result() as $subcatList) { ?>
														<li data-depth="1">
															<a href="<?php echo base_url(); ?><?php echo base64_encode('list/')?>LIST?D=<?php echo base64_encode($subcatList->id); ?>"> <?php echo $subcatList->name; ?></a>


														</li>
														<?php } ?> 
													</ul>
												</div>
												<?php } ?> 
											</li>
											<?php } ?> 
									<!-- <li data-depth="0"><a href="indexe734.html?id_category=12&amp;controller=category&amp;id_lang=1">Electronics</a></li>
									<li data-depth="0"><a href="indexd9ce.html?id_category=13&amp;controller=category&amp;id_lang=1">Baby &amp; Kids</a></li>
									<li data-depth="0"><a href="indexf052.html?id_category=14&amp;controller=category&amp;id_lang=1">Automobiles</a></li>
									<li data-depth="0"><a href="indexb34f.html?id_category=15&amp;controller=category&amp;id_lang=1">Jewellery</a></li>
									<li data-depth="0"><a href="index63be.html?id_category=16&amp;controller=category&amp;id_lang=1">Furniture</a></li>
									<li data-depth="0"><a href="indexcd48.html?id_category=17&amp;controller=category&amp;id_lang=1">Featured</a></li> -->
								</ul>
							</li>
						</ul>
					</div>
				</div>

				<div id="czleftbanner">
					<ul>
						<li class="slide czleftbanner-container">
							<a href="#" title="LeftBanner 1">
								<img src="<?php echo base_url();?>assets/modules/cz_leftbanner/views/img/left-banner-1.jpg" alt="LeftBanner 1" title="LeftBanner 1" />
							</a>				
						</li>
					</ul>
				</div>			

				<div id="newproduct_block" class="block products-block">
					<h4 class="block_title hidden-md-down">
						New products
					</h4>
					<h4 class="block_title hidden-lg-up" data-target="#newproduct_block_toggle" data-toggle="collapse">
						New products
						<span class="pull-xs-right">
							<span class="navbar-toggler collapse-icons">
								<i class="fa-icon add"></i>
								<i class="fa-icon remove"></i>
							</span>
						</span>
					</h4>
					<div id="newproduct_block_toggle" class="block_content  collapse">

						<ul class="products">
							 <?php $i=-1;  foreach($product->result() as $products){  $i++; if($i<=3){?>
							<li class="product_item">

								<div class="product-miniature js-product-miniature" data-id-product="15" data-id-product-attribute="268" itemscope itemtype="#">
									<div class="product_thumbnail">

										<a href="<?php echo base_url(); ?>single_ProductDetail<?php echo base64_encode('pd1234'); ?>_page?ee=<?php echo base64_encode($products->id); ?>" class="thumbnail product-image">
											<img style="width:85px; height:97px;"
											src = "<?php echo IMAGE_URL; ?><?php echo $products->image; ?>"
											alt = "<?php echo $products->name; ?>"
											>
										</a>

									</div>

									<div class="product-info">

										<h1 class="h3 product-title" itemprop="name"><a href="<?php echo base_url(); ?>single_ProductDetail<?php echo base64_encode('pd1234'); ?>_page?ee=<?php echo base64_encode($products->id); ?>"><?php echo $products->name; ?></a></h1>



										<div class="product-price-and-shipping">



											<span itemprop="price" class="price">₹<?php echo $products->price; ?></span>




										</div>


										<!-- <div class="comments_note">
											<div class="star_content clearfix">
												<div class="star"></div>
												<div class="star"></div>
												<div class="star"></div>
												<div class="star"></div>
												<div class="star"></div>
											</div>
											<span class="total-rating">0 Review(s)&nbsp</span>
										</div> -->


									</div>
								</div>	


							</li>

						<?php } }?>
							<!-- <li class="product_item">

								<div class="product-miniature js-product-miniature" data-id-product="14" data-id-product-attribute="260" itemscope itemtype="http://schema.org/Product">
									<div class="product_thumbnail">

										<a href="index4304.html?id_product=14&amp;id_product_attribute=260&amp;rewrite=printed-chiffon-dress&amp;controller=product&amp;id_lang=1#/15-color-green" class="thumbnail product-image">
											<img
											src = "img/p/1/0/4/104-small_default.jpg"
											alt = "Occasion praesentium"
											>
										</a>

									</div>

									<div class="product-info">

										<h1 class="h3 product-title" itemprop="name"><a href="index4304.html?id_product=14&amp;id_product_attribute=260&amp;rewrite=printed-chiffon-dress&amp;controller=product&amp;id_lang=1#/15-color-green">Occasion praesentium</a></h1>



										<div class="product-price-and-shipping">


											<span class="regular-price">$99.00</span>
											<span class="discount-percentage">-3%</span>



											<span itemprop="price" class="price">$96.03</span>




										</div>


										<div class="comments_note">
											<div class="star_content clearfix">
												<div class="star star_on"></div>
												<div class="star star_on"></div>
												<div class="star star_on"></div>
												<div class="star star_on"></div>
												<div class="star star_on"></div>
											</div>
											<span class="total-rating">1 Review(s)&nbsp</span>
										</div>


									</div>
								</div>	


							</li>
							<li class="product_item">

								<div class="product-miniature js-product-miniature" data-id-product="13" data-id-product-attribute="241" itemscope itemtype="http://schema.org/Product">
									<div class="product_thumbnail">

										<a href="index9863.html?id_product=13&amp;id_product_attribute=241&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/1-size-s/8-color-white" class="thumbnail product-image">
											<img
											src = "img/p/9/6/96-small_default.jpg"
											alt = "Laudant doloremque"
											>
										</a>

									</div>

									<div class="product-info">

										<h1 class="h3 product-title" itemprop="name"><a href="index9863.html?id_product=13&amp;id_product_attribute=241&amp;rewrite=printed-summer-dress&amp;controller=product&amp;id_lang=1#/1-size-s/8-color-white">Laudant doloremque</a></h1>



										<div class="product-price-and-shipping">


											<span class="regular-price">$91.00</span>



											<span itemprop="price" class="price">$85.00</span>




										</div>


										<div class="comments_note">
											<div class="star_content clearfix">
												<div class="star"></div>
												<div class="star"></div>
												<div class="star"></div>
												<div class="star"></div>
												<div class="star"></div>
											</div>
											<span class="total-rating">0 Review(s)&nbsp</span>
										</div>


									</div>
								</div>	


							</li>
 -->
						</ul>

						<div class="view_more">
							<a class="all-product-link btn btn-primary" href="#">
								All new products
							</a>
						</div>

					</div>
				</div>


				<!-- Block categories module -->
				<div id="categories_blog_menu" class="block blog-menu">
					<h4 class="block_title hidden-md-down">
					Blog Categories		</h4>
					<h4 class="block_title hidden-lg-up" data-target="#categories_blog_toggle" data-toggle="collapse">
						Blog Categories			<span class="pull-xs-right">
							<span class="navbar-toggler collapse-icons">
								<i class="fa-icon add"></i>
								<i class="fa-icon remove"></i>
							</span>
						</span>
					</h4>
					<div id="categories_blog_toggle" class="block_content  collapse">
						<ul class="level1 tree dhtml ">
							<li id="list_3" class=" ">
								<a href="#" title="Vestibulum consequat"><span>Vestibulum consequat</span></a>
								 <ul class="level2 ">
								 	<li id="list_4" class=" "><a href="#" title="Pellentesque condimentum"><span>Pellentesque condimentum</span></a> 
								 	</li>
								 	<li id="list_5" class=" "><a href="#" title="Suspendisse turpis"><span>Suspendisse turpis</span></a> </li>
								 </ul>
							</li>
						</ul>
					</div>
				</div>
				<!-- /Block categories module -->

			</div>



			<div id="content-wrapper" class="left-column col-xs-12 col-sm-8 col-md-9" style="width:75.6%">



				<div id="blog-listing" class="blogs-container box">
					<h1 class="blog-heading">Latest Blogs</h1>

					<div class="inner">

						<div class="secondary-blog">
							<div class="row">
								<div class="col-lg-6">

									<article class="blog-item">
										<div class="blog-image-meta">
											<div class="blog-image">
												<a href="#" title="Nullam ullamcorper ornare molestie" class="link">
													<img src="<?php echo  base_url(); ?>assets/img/psblog/b/9/892_554/b-blog-7.jpg" title="Nullam ullamcorper ornare molestie" alt="" class="img-fluid" />
													<span class="post-image-hover"></span>
												</a>
												<span class="blogicons">
													<a title="Click to view Full Image" href="<?php echo  base_url(); ?>assets/img/psblog/b/9/892_554/b-blog-7.jpg" data-lightbox="example-set" class="icon zoom">&nbsp;</a> 
													<a title="Click to view Read More" href="#">&nbsp;</a>
												</span>
											</div>

											<div class="blog-meta">



												<span class="blog-created">
													<i class="fa fa-calendar"></i> <!--On: -->
													<time class="date" datetime="2017">
														<!--Monday,	--><!-- day of week -->
														18	   <!-- day of month -->
														Dec		<!-- month-->
														2017		<!-- year -->
													</time>
												</span>



											</div>

										</div>

										<div class="blog-content-wrap">

											<h4 class="title"><a href="#" title="Nullam ullamcorper ornare molestie">Nullam ullamcorper ornare...</a></h4>

											<div class="blog-shortinfo">
												Suspendisse posuere, diam in bibendum lobortis, turpis...
											</div>

										</div>

									</article>

								</div>	
								<div class="col-lg-6">

									<article class="blog-item">
										<div class="blog-image-meta">
											<div class="blog-image">
												<a href="#" title="Turpis at eleifend Aenean porta" class="link">
													<img src="<?php echo  base_url(); ?>assets/img/psblog/b/8/892_554/b-blog-6.jpg" title="Turpis at eleifend Aenean porta" alt="" class="img-fluid" />
													<span class="post-image-hover"></span>
												</a>
												<span class="blogicons">
													<a title="Click to view Full Image" href="<?php echo  base_url(); ?>assets/img/psblog/b/8/892_554/b-blog-6.jpg" data-lightbox="example-set" class="icon zoom">&nbsp;</a> 
													<a title="Click to view Read More" href="#">&nbsp;</a>
												</span>
											</div>

											<div class="blog-meta">



												<span class="blog-created">
													<i class="fa fa-calendar"></i> <!--On: -->
													<time class="date" datetime="2017">
														<!--Monday,	--><!-- day of week -->
														18	   <!-- day of month -->
														Dec		<!-- month-->
														2017		<!-- year -->
													</time>
												</span>



											</div>

										</div>

										<div class="blog-content-wrap">

											<h4 class="title"><a href="#" title="Turpis at eleifend Aenean porta">Turpis at eleifend Aenean...</a></h4>

											<div class="blog-shortinfo">
												Turpis at eleifend ps mi elit Aenean porta ac sed...
											</div>

										</div>

									</article>

								</div>	
							</div>
							<div class="row">
								<div class="col-lg-6">

									<article class="blog-item">
										<div class="blog-image-meta">
											<div class="blog-image">
												<a href="#" title="Morbi condimentum molestie Nam" class="link">
													<img src="<?php echo  base_url(); ?>assets/img/psblog/b/7/892_554/b-blog-5.jpg" title="Morbi condimentum molestie Nam" alt="" class="img-fluid" />
													<span class="post-image-hover"></span>
												</a>
												<span class="blogicons">
													<a title="Click to view Full Image" href="<?php echo  base_url(); ?>assets/img/psblog/b/7/892_554/b-blog-5.jpg" data-lightbox="example-set" class="icon zoom">&nbsp;</a> 
													<a title="Click to view Read More" href="#">&nbsp;</a>
												</span>
											</div>

											<div class="blog-meta">



												<span class="blog-created">
													<i class="fa fa-calendar"></i> <!--On: -->
													<time class="date" datetime="2017">
														<!--Monday,	--><!-- day of week -->
														18	   <!-- day of month -->
														Dec		<!-- month-->
														2017		<!-- year -->
													</time>
												</span>



											</div>

										</div>

										<div class="blog-content-wrap">

											<h4 class="title"><a href="#" title="Morbi condimentum molestie Nam">Morbi condimentum molestie Nam</a></h4>

											<div class="blog-shortinfo">
												Sed mauris Pellentesque elit Aliquam at lacus interdum...
											</div>

										</div>

									</article>

								</div>	
								<div class="col-lg-6">

									<article class="blog-item">
										<div class="blog-image-meta">
											<div class="blog-image">
												<a href="#" class="link">
													<img src="<?php echo  base_url(); ?>assets/img/psblog/b/6/892_554/b-blog-4.jpg" title="Curabitur at elit Vestibulum" alt="" class="img-fluid" />
													<span class="post-image-hover"></span>
												</a>
												<span class="blogicons">
													<a title="Click to view Full Image" href="<?php echo  base_url(); ?>assets/img/psblog/b/6/892_554/b-blog-4.jpg" data-lightbox="example-set" class="icon zoom">&nbsp;</a> 
													<a title="Click to view Read More" href="#" class="icon readmore_link">&nbsp;</a>
												</span>
											</div>

											<div class="blog-meta">



												<span class="blog-created">
													<i class="fa fa-calendar"></i> <!--On: -->
													<time class="date" datetime="2017">
														<!--Monday,	--><!-- day of week -->
														18	   <!-- day of month -->
														Dec		<!-- month-->
														2017		<!-- year -->
													</time>
												</span>



											</div>

										</div>

										<div class="blog-content-wrap">

											<h4 class="title"><a href="#">Curabitur at elit Vestibulum</a></h4>

											<div class="blog-shortinfo">
												Mi vitae magnis Fusce laoreet nibh felis porttitor...
											</div>

										</div>

									</article>

								</div>	
							</div>
							<div class="row">
								<div class="col-lg-6">

									<article class="blog-item">
										<div class="blog-image-meta">
											<div class="blog-image">
												<a href="#" class="link">
													<img src="<?php echo  base_url(); ?>assets/img/psblog/b/5/892_554/b-blog-3.jpg" title="Urna pretium elit mauris cursus" alt="" class="img-fluid" />
													<span class="post-image-hover"></span>
												</a>
												<span class="blogicons">
													<a title="Click to view Full Image" href="<?php echo  base_url(); ?>assets/img/psblog/b/5/892_554/b-blog-3.jpg" data-lightbox="example-set" class="icon zoom">&nbsp;</a> 
													<a title="Click to view Read More" href="#">&nbsp;</a>
												</span>
											</div>

											<div class="blog-meta">



												<span class="blog-created">
													<i class="fa fa-calendar"></i> <!--On: -->
													<time class="date" datetime="2017">
														<!--Saturday,	--><!-- day of week -->
														16	   <!-- day of month -->
														Dec		<!-- month-->
														2017		<!-- year -->
													</time>
												</span>



											</div>

										</div>

										<div class="blog-content-wrap">

											<h4 class="title"><a href="#" title="Urna pretium elit mauris cursus">Urna pretium elit mauris...</a></h4>

											<div class="blog-shortinfo">
												Mi vitae magnis Fusce laoreet nibh felis porttitor...
											</div>

										</div>

									</article>

								</div>	
								<div class="col-lg-6">

									<article class="blog-item">
										<div class="blog-image-meta">
											<div class="blog-image">
												<a href="#" title="Ipsum cursus vestibulum Vivamus" class="link">
													<img src="<?php echo  base_url(); ?>assets/img/psblog/b/4/892_554/b-blog-2.jpg" title="Ipsum cursus vestibulum Vivamus" alt="" class="img-fluid" />
													<span class="post-image-hover"></span>
												</a>
												<span class="blogicons">
													<a title="Click to view Full Image" href="<?php echo  base_url(); ?>assets/img/psblog/b/4/892_554/b-blog-2.jpg" data-lightbox="example-set" class="icon zoom">&nbsp;</a> 
													<a title="Click to view Read More" href="#" class="icon readmore_link">&nbsp;</a>
												</span>
											</div>

											<div class="blog-meta">



												<span class="blog-created">
													<i class="fa fa-calendar"></i> <!--On: -->
													<time class="date" datetime="2017">
														<!--Monday,	--><!-- day of week -->
														4	   <!-- day of month -->
														Dec		<!-- month-->
														2017		<!-- year -->
													</time>
												</span>



											</div>

										</div>

										<div class="blog-content-wrap">

											<h4 class="title"><a href="#" title="Ipsum cursus vestibulum Vivamus">Ipsum cursus vestibulum...</a></h4>

											<div class="blog-shortinfo">
												Donec tellus Nulla lorem Nullam elit id ut elit feugiat...
											</div>

										</div>

									</article>

								</div>	
							</div>
						</div>
						<div class="ps_sortPagiBar clearfix bottom-line">




							<!-- Pagination -->
							<div id="pagination" class="pagination float-xs-left clearfix">

								<ul class="pagination">
									<li id="pagination_previous" class="previous disabled pagination_previous"><span class="previous"><i class="fa fa-long-arrow-left"></i> </span></li>

									<li class="active current"><span><span>1</span></span></li>
									<li><a  href="#"><span>2</span></a></li>
									<li id="pagination_next" class="pagination_next">	
										<a  href="#" class="next"><i class="fa fa-long-arrow-right"></i></a>
									</li>
								</ul>
							</div>

							<div class="product-count float-xs-right">

							</div>

							<!-- /Pagination -->
						</div>


					</div>
				</div>


			</div>



		</div>
	</div>

</section>

<!-- footer -->
<?php $this->load->view('common/imt/footer1'); ?>
<!-- //footer -->
</main>


<script type="text/javascript" src="<?php echo base_url(); ?>assets/themes/Fashcod/assets/cache/bottom-9149e8.js" ></script>

<?php $this->load->view('common/imt/customer'); ?>




</body>

</html>
  <body id="contact" class="lang-en country-us currency-usd layout-left-column page-contact tax-display-disabled">

    
    	
    

    <main id="page">
      
              

      <header id="header">
        
          
  <div class="header-banner">
    
  </div>



<nav class="header-nav">
	<div class="container">
        
		
			<div class="left-nav">
				
			</div>
			
			<div class="right-nav">
				
			</div>
		
		
		
        
	</div>
</nav>



	   <!-- header-bot -->
      <?php $this->load->view('common/imt/header'); ?>
      <!-- //header-bot -->
      <!-- banner -->
      <?php $this->load->view('common/imt/navbar'); ?>
        
      </header>

      
        
<aside id="notifications">
  <div class="container">
    
    
    
      </div>
</aside>
      
      			
	  
	  		<nav data-depth="1" class="breadcrumb">
   <div class="container">
  <ol itemscope itemtype="#">
          
      <li itemprop="itemListElement" itemscope itemtype="#">
        <a itemprop="item" href="<?php echo base_url(); ?>">
          <span itemprop="name">Home</span>
        </a>
        <meta itemprop="position" content="1">
      </li>
      
      </ol>
  </div>
</nav>
	  
	  
	  <section id="wrapper">
		 
		<div class="container">
		  <div id="columns_inner">
			  
  <div id="left-column" class="col-xs-12 col-sm-3"  style="width:24.4%">
    
<div id="contact-rich" class="contact-rich block">
	<h4 class="block_title hidden-md-down">Store information</h4>
	<h4 class="block_title hidden-lg-up" data-target="#contact_rich_toggle" data-toggle="collapse">
		Store information
		<span class="pull-xs-right">
		  <span class="navbar-toggler collapse-icons">
			<i class="fa-icon add"></i>
			<i class="fa-icon remove"></i>
		  </span>
		</span>
	</h4>

  <div id="contact_rich_toggle" class="block_content collapse">
	  <div class="">
		<div class="icon"><i class="fa fa-map-marker"></i></div>
		<div class="data"><?php echo $contact->address; ?></div>
	  </div>
	  		<hr/>
		<div class="">
		  <div class="icon"><i class="fa fa-phone"></i></div>
		  <div class="data">
			Call us:<br/>
			<a href="#"><?php echo $contact->contact_no; ?></a>
		   </div>
		</div>
	  	  		<hr/>
		<div class="">
		  <div class="icon"><i class="fa fa-fax"></i></div>
		  <div class="data">
			Fax:<br/>
			
		  </div>
		</div>
	  	  		<hr/>
		<div class="">
		  <div class="icon"><i class="fa fa-envelope-o"></i></div>
		  <div class="data email">
			Email us:<br/>
		   	<a href="#"><?php echo $contact->email; ?></a>
		   </div>		   
		</div>
	  	</div>
</div>

  </div>


			  
  <div id="content-wrapper" class="left-column col-xs-12 col-sm-8 col-md-9" style="width:75.6%">

    

  <section id="main">

    

    
      <section id="content" class="page-content card card-block">
        
        
  <section class="contact-form">
  <form action="https://codezeel.com/prestashop/PRS06/PRS060129/index.php?controller=contact" method="post" enctype="multipart/form-data">

    
        <section class="form-fields">

      <div class="form-group row">
        <div class="col-md-9 col-md-offset-3">
            <h3>Contact us</h3>
        </div>
      </div>

      <div class="form-group row">
        <label class="col-md-3 form-control-label">Subject</label>
        <div class="col-md-6">
          <select name="id_contact" class="form-control form-control-select">
                          <option value="2">Customer service</option>
                          <option value="1">Webmaster</option>
                      </select>
        </div>
      </div>

      <div class="form-group row">
        <label class="col-md-3 form-control-label">Email address</label>
        <div class="col-md-6">
          <input
            class="form-control"
            name="from"
            type="email"
            value=""
            placeholder="your@email.com"
          >
        </div>
      </div>

      
              <div class="form-group row">
          <label class="col-md-3 form-control-label">Attachment</label>
          <div class="col-md-6">
            <input type="file" name="fileUpload" class="filestyle" data-buttonText="Choose file">
          </div>
          <span class="col-md-3 form-control-comment">
            optional
          </span>
        </div>
      
      <div class="form-group row">
        <label class="col-md-3 form-control-label">Message</label>
        <div class="col-md-9">
          <textarea
            class="form-control"
            name="message"
            placeholder="How can we help?"
            rows="3"
          ></textarea>
        </div>
      </div>

    </section>

    <footer class="form-footer text-xs-right">
      <input class="btn btn-primary" type="submit" name="submitMessage" value="Send">
    </footer>
    
  </form>
</section>


      </section>
    

    
      <footer class="page-footer">
        
          <!-- Footer content -->
        
      </footer>
    

  </section>


    
  </div>


			  
		  </div>
        </div>

      </section>

  
<!-- footer -->
<?php $this->load->view('common/imt/footer1'); ?>
<!-- //footer -->
</main>


<script type="text/javascript" src="<?php echo base_url(); ?>assets/themes/Fashcod/assets/cache/bottom-9149e8.js" ></script>

<?php $this->load->view('common/imt/customer'); ?>



  </body>


<!-- Mirrored from codezeel.com/prestashop/PRS06/PRS060129/index.php?controller=contact by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 17 Jul 2018 16:20:40 GMT -->
</html>

<style type="text/css">
  .not-allowed {
    cursor: not-allowed;
    opacity: .5;
}
</style>

<body id="checkout" class="lang-en country-us currency-usd layout-left-column page-order tax-display-disabled">


  <main id="page">


   <header id="header">
    <div class="header-banner">
    </div>
    <nav class="header-nav">
      <div class="container">
        <div class="left-nav">
        </div>
        <div class="right-nav">
        </div>
      </div>
    </nav>
    <!-- header-bot -->
    <?php $this->load->view('common/imt/header'); ?>
    <!-- //header-bot -->
    <!-- banner -->
    <?php $this->load->view('common/imt/navbar'); ?>
  </header>





  <aside id="notifications">
    <div class="container">



    </div>
  </aside>


  <section id="wrapper">

    <div class="container ggdg">


      <section id="content">
        <div class="row">
          <div class="col-md-8">

              <section id="checkout-personal-information-step" class="checkout-step    -reachable <?php if($this->Users->is_logged_in()){  ?>  -complete<?php } else{ ?>-current js-current-step<?php } ?>">
                <h1 class="step-title h3">
                  <i class="material-icons done">&#xE876;</i>
                  <span class="step-number">1</span>
                  Personal Information
                  <?php if($this->Users->is_logged_in()){  ?>
                  <span class="step-edit text-muted"><i class="material-icons edit">mode_edit</i> Edit</span>
              <?php } ?>
                </h1>

                <div class="content">
               		<?php if($this->Users->is_logged_in()){
               			$userdata=$this->Users->get_logged_in_user_info();
               		  ?>
               			 <p class="identity">
      
					      Connected as <a href='<?php echo site_url('user/personal_info')?>'><?php echo $userdata->name; ?></a>.
					    </p>
					    <p>
					      
					      Not you? <a href='<?php echo site_url('user/logout')?>'>Log out</a>
					    </p>
				          <p><small>If you sign out now, your cart will be emptied.</small></p>
				    
               		<?php } else{ ?> 	
                    <ul class="nav nav-inline my-2" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" data-toggle="tab" href="#checkout-guest-form" role="tab" aria-controls="checkout-guest-form" aria-selected="true">
                            Order as a guest
                          </a>
                        </li>

                        <li class="nav-item">
                            <span href="nav-separator"> | </span>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link " data-link-action="show-login-form" data-toggle="tab" href="#checkout-login-form" role="tab" aria-controls="checkout-login-form">
                          Sign in
                        </a>
                        </li>
                    </ul>

                    <div class="tab-content">
                        <div class="tab-pane active" id="checkout-guest-form" role="tabpanel">

                            <form action="<?php echo base_url(); ?>User/registration" id="customer-form" class="js-customer-form" method="post">
                                <section>

                                    <input type="hidden" name="id_customer" value="">

                                    

                                    <div class="form-group row ">
                                        <label class="col-md-3 form-control-label required">
                                             Full Name
                                        </label>
                                        <div class="col-md-6">

                                            <input class="form-control" name="name" type="text" value="" required>

                                        </div>

                                        <div class="col-md-3 form-control-comment">

                                        </div>
                                    </div>

                                    <div class="form-group row ">
                                        <label class="col-md-3 form-control-label required">
                                            Mobile Number
                                        </label>
                                        <div class="col-md-6">

                                            <input class="form-control" name="contact" type="text" value="" required>

                                        </div>

                                        <div class="col-md-3 form-control-comment">

                                        </div>
                                    </div>

                                    <div class="form-group row ">
                                        <label class="col-md-3 form-control-label required">Email</label>
                                        <div class="col-md-6">
                                          <input class="form-control" name="email" type="email" value="" required>
                                        </div>
                                        <div class="col-md-3 form-control-comment"></div>
                                    </div>

                                    <div class="form-group row ">
                                        <label class="col-md-3 form-control-label">Password</label>
                                        <div class="col-md-6">
                                          <div class="input-group js-parent-focus">
                                            <input class="form-control js-child-focus js-visible-password" name="password" type="password" value="" pattern=".{5,}">
                                            <span class="input-group-btn"><button class="btn" type="button" data-action="show-password" data-text-show="Show" data-text-hide="Hide"> Show </button></span>
                                          </div>
                                        </div>
                                        <div class="col-md-3 form-control-comment"></div>
                                    </div>

                                    <div class="form-group row ">
                                        <label class="col-md-3 form-control-label">
                                            Confirm Password
                                        </label>
                                        <div class="col-md-6">

                                            <div class="input-group js-parent-focus">
                                                <input class="form-control js-child-focus js-visible-password" name="cpassword" type="password" value="" pattern=".{5,}">
                                                <span class="input-group-btn">
                                                    <button
                                                    class="btn"
                                                    type="button"
                                                    data-action="show-password"
                                                    data-text-show="Show"
                                                    data-text-hide="Hide"
                                                    >
                                                    Show
                                                  </button>
                                                </span>
                                            </div>

                                        </div>

                                        <div class="col-md-3 form-control-comment">

                                           

                                        </div>
                                    </div>

                                       
                                    <div class="form-group row ">
                                        <label class="col-md-3 form-control-label required">
                                                  Address
                                              </label>
                                        <div class="col-md-6">
                                      <input class="form-control" name="addess"  type="text" value="" required   >
                                       </div>

                                        <div class="col-md-3 form-control-comment">
                                          
                                                  
                                        </div>
                                      </div>

                                      
                                    <div class="form-group row ">
                                        <label class="col-md-3 form-control-label required">
                                                  City
                                              </label>
                                        <div class="col-md-6">
                                      <input class="form-control" name="city"  type="text" value="" required   >
                                       </div>

                                        <div class="col-md-3 form-control-comment">
                                          
                                                  
                                        </div>
                                      </div>

                                      
                                    <div class="form-group row ">
                                        <label class="col-md-3 form-control-label required">
                                                  State
                                              </label>
                                        <div class="col-md-6">
                                      <input class="form-control" name="state"  type="text" value="" required   >
                                       </div>

                                        <div class="col-md-3 form-control-comment">
                                          
                                                  
                                        </div>
                                      </div>

                                      
                                    <div class="form-group row ">
                                        <label class="col-md-3 form-control-label required">
                                                  Postal Code
                                              </label>
                                        <div class="col-md-6">
                                      <input class="form-control" name="postal_code"  type="text" value="" required   >
                                       </div>

                                        <div class="col-md-3 form-control-comment">
                                          
                                                  
                                        </div>
                                      </div>
                                      
                                    <div class="form-group row ">
                                        <label class="col-md-3 form-control-label required">
                                                 Country
                                              </label>
                                        <div class="col-md-6">
                                      <input class="form-control" name="country"  type="text" value="" required   >
                                       </div>

                                        <div class="col-md-3 form-control-comment">
                                          
                                                  
                                        </div>
                                      </div>
                                       
                                     
                                     
                                    

                                </section>

                                <footer class="form-footer clearfix">
                                    <input type="hidden" name="submitCreate" value="1">

                                    <button class="continue btn btn-primary float-xs-right" name="continue" data-link-action="register-new-customer" type="submit" value="1">
                                        Continue
                                    </button>

                                </footer>

                            </form>

                        </div>
                        <div class="tab-pane " id="checkout-login-form" role="tabpanel" aria-hidden="true">

                            <form id="login-form" action="<?php echo base_url(); ?>Access=login_451<?php echo base64_encode('lg-1'); ?>P" method="post">

                                <section>
                                  <input type="hidden" name="back" value="">
                                    <div class="form-group row ">
                                      <label class="col-md-3 form-control-label required">
                                          Email
                                      </label>
                                      <div class="col-md-6">
                                        <input class="form-control" name="username" type="text" value="" required>
                                      </div>
                                      <div class="col-md-3 form-control-comment">
                                      </div>
                                    </div>
                                    <div class="form-group row ">
                                      <label class="col-md-3 form-control-label required">
                                          Password
                                        </label>
                                        <div class="col-md-6">

                                            <div class="input-group js-parent-focus">
                                                <input class="form-control js-child-focus js-visible-password" name="password" type="password" value="" pattern=".{5,}" required>
                                                <span class="input-group-btn">
                                                    <button
                                                    class="btn"
                                                    type="button"
                                                    data-action="show-password"
                                                    data-text-show="Show"
                                                    data-text-hide="Hide"
                                                    >
                                                    Show
                                                  </button>
                                                </span>
                                            </div>

                                        </div>

                                        <div class="col-md-3 form-control-comment">

                                        </div>
                                    </div>

                                    <div class="forgot-password">
                                        <a href="#" rel="nofollow">
                                          Forgot your password?
                                        </a>
                                    </div>
                                </section>

                                <footer class="form-footer text-sm-center clearfix">
                                    <input type="hidden" name="submitLogin" value="1">

                                    <button class="continue btn btn-primary float-xs-right" name="continue" data-link-action="sign-in" type="submit" value="1">
                                        Continue
                                    </button>

                                </footer>

                            </form>

                        </div>
                    </div>
                <?php } ?>

                </div>
              </section>

				<?php $addit =0; if($this->Users->is_logged_in()){  
                		$useraddress= $this->addressbook->get_all_byuser($userdata->id);
                		$addit =$useraddress->num_rows();
				}
                		?>
              <section class="checkout-step  <?php if($this->Users->is_logged_in() &&  $addit >0){  ?>-reachable -complete<?php }elseif($this->Users->is_logged_in()){ ?>-current js-current-step <?php } else{ ?>-unreachable <?php } ?>" id="checkout-addresses-step">
                <h1 class="step-title h3">
                  <i class="material-icons done">&#xE876;</i>
                  <span class="step-number">2</span> Addresses
                  <?php if($this->Users->is_logged_in()){  ?>
                  <span class="step-edit text-muted"><i class="material-icons edit">mode_edit</i> Edit</span>
                  <?php } ?>
                </h1>
                
                
                <div class="content">
                	<?php if($this->Users->is_logged_in() &&  $addit >0){  
                		


                		?>
                		
                		<div class="js-address-form">
    						<form  method="POST"  action="#" data-refresh-url="#" id="addressform" >

      
             				<p>
					          The selected address will be used both as your personal address (for invoice) and as your delivery address.
					        </p>
      
            <div id="delivery-addresses" class="address-selector js-address-selector">
          		<?php foreach($useraddress->result() as $val){ ?>
			    <article class="address-item selected" id="id-address-delivery-address-8" 
			    data-rowid="<?php echo $val->id; ?>">
			      	<header class="h4">
			        <label class="radio-block">
			          <span class="custom-radio">
			            <input
			              type="radio"
			              name="id_address_delivery"
			              value="<?php echo $val->id; ?>"
			              checked            >
			            <span></span>
			          </span>
			          <span class="address-alias h4">My Address</span>
			          <div class="address"><?php echo $val->name; ?><br><?php echo $val->company; ?><br><?php echo $val->address; ?><br><?php echo $val->city; ?>,<?php echo $val->state; ?> <?php echo $val->postal_code; ?><br><?php echo $val->country; ?><br><?php echo $val->phone; ?></div>
			        </label>
			      </header>
			      <hr>
			      <footer class="address-footer">
			                  <a
			            class="edit-address text-muted"
			            data-link-action="edit-address"
			            data-id="<?php echo $val->id; ?>"
			          >
			            <i class="material-icons edit">&#xE254;</i>Edit
			          </a>
			          <a
			            class="delete-address text-muted"
			            data-link-action="delete-address"
			            href="#" data-id="<?php echo $val->id; ?>"
			          >
			            <i class="material-icons delete">&#xE872;</i>Delete
			          </a>
			              </footer>
			    </article>
			<?php } ?>
			        <p>
			      <button class="ps-hidden-by-js form-control-submit center-block" type="submit">Save</button>
			    </p>
			  
        </div>
<div class="editaddressdiv">
	

</div>
<p class="add-address">
          <a href="#" class="add-address"><i class="material-icons">&#xE145;</i>add new address</a>
        </p>

                  <p>
            <!-- <a href="#">
              Billing address differs from shipping address
            </a> -->
          </p>
        
        
      
      
              <div class="clearfix">
          <button type="submit" class="btn btn-primary continue float-xs-right" name="confirm-addresses" value="1">
              Continue
          </button>
        </div>
      
    </form>





 					








  </div>

                	<?php } else if($this->Users->is_logged_in()){ ?>
                  <div class="js-address-form">
                    <form method="POST" action="<?php echo site_url('user/add_address'); ?>" data-refresh-url="#" >
                      <p>
                        The selected address will be used both as your personal address (for invoice) and as your delivery address.
                      </p>
                      <div id="delivery-address">
                        <div class="js-address-form">
                          
                            <section class="form-fields">
                              <!-- <input type="hidden" name="id_address" value="">-->
                              <input type="hidden" name="id" value="<?php echo $userdata->id; ?>">
                             <!-- <input type="hidden" name="back" value="">
                              <input type="hidden" name="token" value="6104f9107807db38ccab22b7aa44453c"> -->
                              <div class="form-group row ">
                                <label class="col-md-3 form-control-label required">
                                  Full name
                                </label>
                                <div class="col-md-6">
                                  <input class="form-control" name="name"type="text" value="<?php echo $userdata->name; ?>" maxlength="32"   required >
                                </div>
                                <div class="col-md-3 form-control-comment">
                                </div>
                              </div>
                              <div class="form-group row ">
                                <label class="col-md-3 form-control-label required">
                                 company	
                                </label>
                                <div class="col-md-6">
                                  <input class="form-control" name="company"   type="text" value="<?php echo $userdata->company; ?>" maxlength="32" required >
                                </div>
                                 <div class="col-md-3 form-control-comment">
                                  Optional
                                </div>
                              </div>
                              
                              <div class="form-group row ">
                                <label class="col-md-3 form-control-label required">
                                  Address
                                </label>
                                <div class="col-md-6">
                                  <input class="form-control" name="address" type="text" value="<?php echo $userdata->address; ?>" maxlength="128" required >
                                </div>

                                <div class="col-md-3 form-control-comment">
                                </div>
                              </div>
                             
                              <div class="form-group row ">
                                <label class="col-md-3 form-control-label required">
                                  City
                                </label>
                                <div class="col-md-6">
                                  <input class="form-control" name="city" type="text"
                                  value="<?php echo $userdata->city; ?>" maxlength="64" required >
                                </div>
                                <div class="col-md-3 form-control-comment">
                                </div>
                              </div>
                              <div class="form-group row ">
                                <label class="col-md-3 form-control-label required">
                                  State
                                </label>
                                <div class="col-md-6">
                                	<input class="form-control" name="state"  type="text" value="<?php echo $userdata->state; ?>" required   >
                                </div>
                                <div class="col-md-3 form-control-comment">
                                </div>
                              </div>
                              <div class="form-group row ">
                                <label class="col-md-3 form-control-label required">
                                  Zip/Postal Code
                                </label>
                                <div class="col-md-6">
                                  <input class="form-control" name="postal_code" type="text" value="<?php echo $userdata->postal_code; ?>" maxlength="12" required >
                                </div>
                                <div class="col-md-3 form-control-comment">
                                </div>
                              </div>
                              <div class="form-group row ">
                                <label class="col-md-3 form-control-label required">
                                  Country
                                </label>
                                <div class="col-md-6">

                                	<input class="form-control" name="country"  type="text" value="<?php echo $userdata->country; ?>" required   >
                                 
                                </div>
                                <div class="col-md-3 form-control-comment">
                                </div>
                              </div>
                              <div class="form-group row ">
                                <label class="col-md-3 form-control-label">
                                  Phone
                                </label>
                                <div class="col-md-6">
                                  <input class="form-control" name="contact" type="text"
                                  value="<?php echo $userdata->phone; ?>" maxlength="32" >
                                </div>
                                <div class="col-md-3 form-control-comment">
                                  Optional
                                </div>
                              </div>
                              
                            </section>
                            <footer class="form-footer clearfix">
                              <input type="hidden" name="submitAddress" value="1">
                              
                                <button type="submit" class="continue btn btn-primary float-xs-right" name="confirm-addresses" value="1">
                                  Continue
                                </button>
                             
                            </footer>
                         
                        </div>
                      </div>
                    </form>
                  </div>
              <?php } ?>
                </div>
              </section>



              <section class="checkout-step <?php if($step==4){?> -reachable -complete<?php }else if($this->Users->is_logged_in() &&  $addit >0 ){  ?>   -reachable  -current js-current-step<?php } else{ ?> -unreachable <?php } ?>" id="checkout-delivery-step">
               <h1 class="step-title h3">
                <i class="material-icons done">&#xE876;</i>
                <span class="step-number">3</span>
                Shipping Method
                <span class="step-edit text-muted"><i class="material-icons edit">mode_edit</i> Edit</span>
              </h1>

              <div class="content">
                
                <div id="hook-display-before-carrier">
                  
                </div>

                <div class="delivery-options-list">
                  <form
                  class="clearfix"
                  id="js-delivery"
                  data-url-update="#"
                  method="post"
                  action="<?php echo site_url('cart/checkout')?>"
                  >
                  <div class="form-fields">
                    <?php $userdata=$this->Users->get_logged_in_user_info(); ?>
                    <div class="delivery-options">
                      <div class="row delivery-option">
                        <div class="col-sm-1">
                          <span class="custom-radio float-xs-left">
                            <input type="radio" name="delivery_option" id="delivery_option_2" value="1" checked>
                            
                            <span></span>
                          </span>
                        </div>
                        <input type="hidden" name="id" value="<?php echo $userdata->id;?>">
                        <label for="delivery_option_2" class="col-sm-11 delivery-option-2">
                          <div class="row">
                            <div class="col-sm-5 col-xs-12">
                              <div class="row">
                                <div class="col-xs-3">
                                  <img src="<?php echo base_url();?>assets/img/track.jpg" alt="My carrier" />
                                </div>
                                <div class="col-xs-9">
                                  <span class="h6 carrier-name">My carrier</span>
                                </div>
                              </div>
                            </div>
                            <div class="col-sm-4 col-xs-12">
                              <span class="carrier-delay">Delivery next day!</span>
                            </div>
                            <div class="col-sm-3 col-xs-12">
                              <span class="carrier-price">Free</span>
                            </div>
                          </div>
                        </label>
                      </div>
                      <div class="row carrier-extra-content">
                        
                      </div>
                      <div class="clearfix"></div>
                    </div>
                    
                    <div class="order-options">
                      <div id="delivery">
                        <label for="delivery_message">If you would like to add a comment about your order, please write it in the field below.</label>
                        <textarea rows="2" cols="120" id="delivery_message" name="delivery_message"></textarea>
                      </div>

                      
                      
                    </div>
                  </div>
                  <button type="submit" class="continue btn btn-primary float-xs-right" name="confirmDeliveryOption" value="1">
                    Continue
                  </button>
                </form>
              </div>

              <div id="hook-display-after-carrier">
                
              </div>

              <div id="extra_carrier"></div>

            </div>
          </section>



              <section class="checkout-step <?php if($step==4){?> -reachable -current js-current-step<?php } else{ ?> -unreachable <?php } ?>" id="checkout-payment-step">
                <h1 class="step-title h3">
    <i class="material-icons done">&#xE876;</i>
    <span class="step-number">4</span>
    Payment
    <span class="step-edit text-muted"><i class="material-icons edit">mode_edit</i> Edit</span>
  </h1>

  <div class="content">
    <form id="conditions-to-approve" method="post"
                  action="<?php echo site_url('order/checkout_order')?>">
    <div class="payment-options ">
     <!--  <div>
        <div id="payment-option-1-container" class="payment-option clearfix">

          <span class="custom-radio float-xs-left">
            <input
            class="ps-shown-by-js "
            id="payment-option-1"
            data-module-name="ps_checkpayment"
            name="payment-option"
            type="radio"
            required
            >
            <span></span>
          </span>

          <form method="GET" class="ps-hidden-by-js">
            <button class="ps-hidden-by-js" type="submit" name="select_payment_option" value="payment-option-1">
              Choose
            </button>
          </form>

          <label for="payment-option-1">
            <span>Pay by Check</span>
          </label>

        </div>
      </div>

      <div id="payment-option-1-additional-information" class="js-additional-information definition-list additional-information ps-hidden ">
        <section>
          <p>Please send us your check including the following details:
            <dl>
              <dt>Amount</dt>
              <dd>$78.00 (tax incl.)</dd>
              <dt>Payee</dt>
              <dd>___________</dd>
              <dt>Send your check to this address</dt>
              <dd>___________</dd>
            </dl>
          </p>
        </section>
      </div>
      <div id="pay-with-payment-option-1-form" class="js-payment-option-form  ps-hidden " >
        <form id="payment-form" method="POST" action="https://codezeel.com/prestashop/PRS06/PRS060129/index.php?fc=module&module=ps_checkpayment&controller=validation&id_lang=1">
          <button style="display:none" id="pay-with-payment-option-1" type="submit"></button>
        </form>
      </div>
    <div>
    <div id="payment-option-2-container" class="payment-option clearfix">

      <span class="custom-radio float-xs-left">
        <input class="ps-shown-by-js" id="payment-option-2" data-module-name="ps_wirepayment" name="payment-option" type="radio" required >
        <span></span>
      </span>
      <form method="GET" class="ps-hidden-by-js">
        <button class="ps-hidden-by-js" type="submit" name="select_payment_option" value="payment-option-2">
        Choose
        </button>
      </form>
      <label for="payment-option-2">
        <span>Pay by bank wire</span>
      </label>
    </div>
  </div>
  <div id="payment-option-2-additional-information" class="js-additional-information definition-list additional-information ps-hidden " >
    <section>
      <p>
        Please transfer the invoice amount to our bank account. You will receive our order confirmation by email containing bank details and order number.
        Goods will be reserved 7 days for you and we'll process the order immediately after receiving the payment.
      </p>
      <div class="modal fade" id="bankwire-modal" tabindex="-1" role="dialog" aria-labelledby="Bankwire information" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
              <h2>Bankwire</h2>
            </div>
            <div class="modal-body">
              <p>Payment is made by transfer of the invoice amount to the following account:</p>
              <dl>
                <dt>Amount</dt>
                <dd>$78.00 (tax incl.)</dd>
                <dt>Name of account owner</dt>
                <dd>___________</dd>
                <dt>Please include these details</dt>
                <dd>___________</dd>
                <dt>Bank name</dt>
                <dd>___________</dd>
              </dl>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
  <div id="pay-with-payment-option-2-form" class="js-payment-option-form  ps-hidden ">
    <form id="payment-form" method="POST" action="#">
      <button style="display:none" id="pay-with-payment-option-2" type="submit"></button>
    </form>
  </div> -->
  <div>
    <div id="payment-option-3-container" class="payment-option clearfix">
      <span class="custom-radio float-xs-left">
        <input class="ps-shown-by-js "  id="payment-option-3" data-module-name="ps_cashondelivery" name="payment-option" type="radio" value="1" required  >
        <span></span>
      </span>
      <div method="GET" class="ps-hidden-by-js">
        <button class="ps-hidden-by-js" type="submit" name="select_payment_option" value="payment-option-3">
          Choose
        </button>
      </div>
      <label for="payment-option-3">
        <span>Pay by Cash on Delivery</span>
      </label>
    </div>
  </div>
  <div id="payment-option-3-additional-information" class="js-additional-information definition-list additional-information ps-hidden " >
  <section>
    <p>
      You pay for the merchandise upon delivery
    </p>
  </section>
</div>
<div id="pay-with-payment-option-3-form" class="js-payment-option-form  ps-hidden "
>
   
</div>
</div>
<p class="ps-hidden-by-js">
  By confirming the order, you certify that you have read and agree with all of the conditions below:
</p>

  <ul>
    <li>
      <div class="float-xs-left">
        <span class="custom-checkbox">
          <input  id    = "conditions_to_approve[terms-and-conditions]"
          name  = "conditions_to_approve[terms-and-conditions]"
          required
          type  = "checkbox"
          value = "1"
          class = "ps-shown-by-js"
          >
          <span><i class="material-icons checkbox-checked">&#xE5CA;</i></span>
        </span>
      </div>
      <div class="condition-label">
        <label class="js-terms" for="conditions_to_approve[terms-and-conditions]">
          I agree to the <a href="#" id="cta-terms-and-conditions-0">terms of service</a> and will adhere to them unconditionally.
        </label>
      </div>
    </li>
  </ul>

<div id="payment-confirmation">
  <div class="ps-shown-by-js">
    <button type="submit"  disabled  class="btn btn-primary center-block">
      Order with an obligation to pay
    </button>
  </div>
  <div class="ps-hidden-by-js">
  </div>
</div>
<div class="modal fade" id="modal">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
      <div class="js-modal-content"></div>
    </div>
  </div>
</div>
</form>
</div>
              </section>




          </div>
          <div class="col-md-4">


            <section id="js-checkout-summary" class="card js-cart" data-refresh-url="#">
              <div class="card-block">





                <div class="cart-summary-products">

                  <p> <?php echo $this->cart->total_items(); ?> items</p>

                  <p>
                    <a href="#" data-toggle="collapse" data-target="#cart-summary-product-list">
                      Show Details
                    </a>
                  </p>

        
                  <div class="collapse" id="cart-summary-product-list">
                    <?php $grand_total=0; if ($cart = $this->cart->contents()){ ?> 
                    <ul class="media-list">
                       <?php  foreach ($cart as $item): ?>
                       <li class="media">
                            <div class="media-left">
                                <a href="#" title="Voluptas assumenda">
                            <img class="media-object" src="<?php echo IMAGE_URL; ?><?php echo $item['image']; ?>" alt="Voluptas assumenda">
                          </a>
                            </div>
                            <div class="media-body">
                          <span class="product-name"><?php echo $item['name']; ?></span>
                          <span class="product-quantity">x<?php echo $item['qty']; ?></span>
                          <span class="product-price float-xs-right">₹ <?php echo number_format($item['price'],2); ?></span>

                             </div>

                      </li>
                     <?php $grand_total = $grand_total + $item['subtotal']; ?>
                      <?php endforeach; ?>
                    </ul>
                    <?php } else {?>
                  <span class="no-items"> There are no more items in your cart </span>
                <?php } ?> 
                  </div>
                  
                </div>



                <div class="cart-summary-line cart-summary-subtotals" id="cart-subtotal-products">
                  <span class="label">Subtotal</span>
                  <span class="value">₹ <?php echo $grand_total; ?> </span>
                </div>
                <div class="cart-summary-line cart-summary-subtotals" id="cart-subtotal-shipping">
                  <span class="label">Shipping</span>
                  <span class="value">Free</span>
                </div>


              </div>

              <hr class="separator">


              <div class="card-block cart-summary-totals">


                <div class="cart-summary-line cart-total">
                  <span class="label">Total <!-- (tax excl.) --></span>
                  <span class="value">₹ <?php echo $grand_total; ?></span>
                </div>

                <!-- <div class="cart-summary-line">
                  <span class="label sub">Taxes</span>
                  <span class="value sub">$0.00</span>
                </div> -->


              </div>


            </section>


            <!-- <div id="block-reassurance">
              <ul>
                <li>
                  <div class="block-reassurance-item">
                    <img src="https://codezeel.com/prestashop/PRS06/PRS060129/modules/blockreassurance/img/ic_verified_user_black_36dp_1x.png" alt="Security policy (edit with module Customer reassurance)">
                    <span class="h6">Security policy (edit with module Customer reassurance)</span>
                  </div>
                </li>
                <li>
                  <div class="block-reassurance-item">
                    <img src="https://codezeel.com/prestashop/PRS06/PRS060129/modules/blockreassurance/img/ic_local_shipping_black_36dp_1x.png" alt="Delivery policy (edit with module Customer reassurance)">
                    <span class="h6">Delivery policy (edit with module Customer reassurance)</span>
                  </div>
                </li>
                <li>
                  <div class="block-reassurance-item">
                    <img src="https://codezeel.com/prestashop/PRS06/PRS060129/modules/blockreassurance/img/ic_swap_horiz_black_36dp_1x.png" alt="Return policy (edit with module Customer reassurance)">
                    <span class="h6">Return policy (edit with module Customer reassurance)</span>
                  </div>
                </li>
              </ul>
            </div> -->

          </div>
        </div>
      </section>

    </div>

  </section>




<!-- footer -->
<?php $this->load->view('common/imt/footer1'); ?>
<!-- //footer -->
</main>


<script type="text/javascript" src="<?php echo base_url(); ?>assets/themes/Fashcod/assets/cache/bottom-9149e8.js" ></script>

<?php $this->load->view('common/imt/customer'); ?>
<script type="text/javascript">
	$(document).ready(function(){
		$("a.edit-address").click(function(event){
			 event.preventDefault();
			 var dataset = event.currentTarget.dataset;
			$.ajax({
				url:"<?php echo site_url('user/edit_address'); ?>/"+dataset.id,
				
				method:'get',
				success:function(dataurl)
				{
					$('#addressform').attr('action','<?php echo site_url('user/edit_address'); ?>/'+dataset.id);
					$('.checkout-step').addClass('not-allowed');
					$('#checkout-addresses-step').removeClass('not-allowed');
					$('.editaddressdiv').html(dataurl);
				}
			});

		});
		$("a.add-address").click(function(event){
			 event.preventDefault();
			 var dataset = event.currentTarget.dataset;
			$.ajax({
				url:"<?php echo site_url('user/add_address'); ?>",
				
				method:'get',
				success:function(dataurl)
				{
					$('#addressform').attr('action','<?php echo site_url('user/add_address'); ?>');
					$('.checkout-step').addClass('not-allowed');
					$('#checkout-addresses-step').removeClass('not-allowed');
					$('.editaddressdiv').html(dataurl);
				}
			});

		});
		
		$("a.delete-address").click(function(event){
			 event.preventDefault();
			 var dataset = event.currentTarget.dataset;
			$.ajax({
				url:"<?php echo site_url('user/delete_address'); ?>/"+dataset.id,
				
				method:'get',
				success:function(dataurl)
				{
					$("article[data-rowid='"+dataset.id+"']").remove();
				}
			});

		});
		
	});
$('.editaddressdiv').delegate("#cancel", "click", function(){ 
			$('.checkout-step').removeClass('not-allowed');
			
			$('.editaddressdiv').html('');
			$('#checkout-addresses-step').addClass(' -current js-current-step');
		});

</script>





</body>

</html>
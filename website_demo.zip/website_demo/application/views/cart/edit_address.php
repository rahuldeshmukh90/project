<form method="POST" action="<?php echo site_url('user/edit_address').$id_address; ?>"  >
                      <p>
                        The selected address will be used both as your personal address (for invoice) and as your delivery address.
                      </p>
                      <div id="delivery-address">
                        <div class="js-address-form">
                          <?php $userdata= $this->addressbook->get_info($id_address);?>
                            <section class="form-fields">
                             <input type="hidden" name="id_address" value="<?php echo $id_address; ?>">
                              <input type="hidden" name="id" value="<?php echo $userdata->user_id; ?>">
                             <!-- <input type="hidden" name="back" value="">
                              <input type="hidden" name="token" value="6104f9107807db38ccab22b7aa44453c"> -->
                              <div class="form-group row ">
                                <label class="col-md-3 form-control-label required">
                                  Full name
                                </label>
                                <div class="col-md-6">
                                  <input class="form-control" name="name"type="text" value="<?php echo $userdata->name; ?>" maxlength="32"   required >
                                </div>
                                <div class="col-md-3 form-control-comment">
                                </div>
                              </div>
                              <div class="form-group row ">
                                <label class="col-md-3 form-control-label required">
                                 company	
                                </label>
                                <div class="col-md-6">
                                  <input class="form-control" name="company"   type="text" value="<?php echo $userdata->company; ?>" maxlength="32" required >
                                </div>
                                 <div class="col-md-3 form-control-comment">
                                  Optional
                                </div>
                              </div>
                              
                              <div class="form-group row ">
                                <label class="col-md-3 form-control-label required">
                                  Address
                                </label>
                                <div class="col-md-6">
                                  <input class="form-control" name="address" type="text" value="<?php echo $userdata->address; ?>" maxlength="128" required >
                                </div>

                                <div class="col-md-3 form-control-comment">
                                </div>
                              </div>
                             
                              <div class="form-group row ">
                                <label class="col-md-3 form-control-label required">
                                  City
                                </label>
                                <div class="col-md-6">
                                  <input class="form-control" name="city" type="text"
                                  value="<?php echo $userdata->city; ?>" maxlength="64" required >
                                </div>
                                <div class="col-md-3 form-control-comment">
                                </div>
                              </div>
                              <div class="form-group row ">
                                <label class="col-md-3 form-control-label required">
                                  State
                                </label>
                                <div class="col-md-6">
                                	<input class="form-control" name="state"  type="text" value="<?php echo $userdata->state; ?>" required   >
                                </div>
                                <div class="col-md-3 form-control-comment">
                                </div>
                              </div>
                              <div class="form-group row ">
                                <label class="col-md-3 form-control-label required">
                                  Zip/Postal Code
                                </label>
                                <div class="col-md-6">
                                  <input class="form-control" name="postal_code" type="text" value="<?php echo $userdata->postal_code; ?>" maxlength="12" required >
                                </div>
                                <div class="col-md-3 form-control-comment">
                                </div>
                              </div>
                              <div class="form-group row ">
                                <label class="col-md-3 form-control-label required">
                                  Country
                                </label>
                                <div class="col-md-6">

                                	<input class="form-control" name="country"  type="text" value="<?php echo $userdata->country; ?>" required   >
                                 
                                </div>
                                <div class="col-md-3 form-control-comment">
                                </div>
                              </div>
                              <div class="form-group row ">
                                <label class="col-md-3 form-control-label">
                                  Phone
                                </label>
                                <div class="col-md-6">
                                  <input class="form-control" name="contact" type="text"
                                  value="<?php echo $userdata->phone; ?>" maxlength="32" >
                                </div>
                                <div class="col-md-3 form-control-comment">
                                  Optional
                                </div>
                              </div>
                              
                            </section>
                            <footer class="form-footer clearfix">
                              <input type="hidden" name="submitAddress" value="1">
                              
                                <button type="submit" class="btn btn-primary float-xs-right" name="confirm-addresses" value="1">
                                  Save
                                </button>
                              
    <a class="js-cancel-address cancel-address float-xs-right" id="cancel" href="">Cancel</a>
  
                            </footer>
                         
                        </div>
                      </div>
                    </form>
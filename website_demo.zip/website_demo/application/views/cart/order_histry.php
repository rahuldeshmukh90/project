<style type="text/css">
    table {
    border-collapse: collapse;
    border: 1px solid #eaeaea;
}
th, td {
    padding: 5px;
}
.d_boxs{padding: 15px;}
tr th{color: black;}
  </style>
<body id="history" class="lang-en country-us currency-usd layout-full-width page-index tax-display-disabled">
<main id="page">
    
    

    <header id="header">
      <div class="header-banner">
      </div>
      <nav class="header-nav">
        <div class="container">
          <div class="left-nav">
          </div>
          <div class="right-nav">
          </div>
        </div>
      </nav>
      <!-- header-bot -->
      <?php $this->load->view('common/imt/header'); ?>
      <!-- //header-bot -->
      <!-- banner -->
      <?php $this->load->view('common/imt/navbar'); ?>
    </header>
    <aside id="notifications">
      <div class="container">
      </div>
    </aside>
    <nav data-depth="1" class="breadcrumb">
      <div class="container">
        <ol itemscope itemtype="#">
          
          <li itemprop="itemListElement" itemscope itemtype="#">
            <a itemprop="item" href="index.html">
              <span itemprop="name">Home</span>
            </a>
            <meta itemprop="position" content="1">
          </li>
          
        </ol>
      </div>
    </nav>
<?php /*
<div class=" container">
    
    <?php $CustomerId = $this->session->userdata('id'); $get_user_info = $this->Users->get_info($CustomerId); ?>
    <div class="col-sm-12 d_boxs">
        <h4 align="center"> <b><?php echo strtoupper("our Shopping Bag History"); ?></b> </h4><br>
        <div class="col-sm-2" ><b>Customer Name</b></div>
        <div class="col-sm-3" >: <?php echo $get_user_info->name; ?></div>
        <div class="col-sm-2" ><b>Mobile Number</b></div>
        <div class="col-sm-3" >: <?php echo $get_user_info->phone; ?></div>
    </div>
    <div class="col-sm-12 d_boxs">
        <div class="col-sm-2" ><b>Address</b></div>
        <div class="col-sm-3" >: <?php echo $get_user_info->address; ?></div>
        <div class="col-sm-2" ><b>Email</b></div>
        <div class="col-sm-3" >: <?php echo $get_user_info->email; ?></div>
    </div>

    <?php foreach($orders->result() as $order){ ?>

    <div class="col-sm-12 d_boxs" align="center" > <b class="date_formate">ORDER DATE : <?php echo $order->OrderDate; ?></b>
    
    
    </div>
    
    <table style="width:100%;">

		  <tr>
		  	 <th><button class="btn-blue"> <b>ORDER NUMBER : <?php echo $order->Bill_Number; ?></b> </button></th>
		    <th>Product Name</th>
		    <th>Price</th> 
		    <th>Quantity</th>
		    <th>Total Price</th>
		  </tr>
		<?php $userHistory = $this->Order_model->UserorderDetail($order->id);
        foreach ($userHistory->result() as $value) { 
        $total_price = ($value->price)*($value->quantity);
        $Product = $this->Product_model->productdetailById($value->ItemId);
        ?>
        <tr>
		  	<td><img src="<?php echo IMAGE_URL; ?><?php echo $Product->image; ?>" width="60px"/> </td>
		    <td><?php echo $Product->name; ?></td>
		    <td><?php echo $value->price; ?></td>
		    <td><?php echo $value->quantity; ?></td>
		    <td><?php echo $total_price; ?></td>
		</tr>
        <?php } ?>
        <tr style="border-top:1px solid #eaeaea;"><td colspan="5"> <span><b> Ordered Date :</b> <?php echo $order->OrderDate; ?> </span></td></tr>
		 	 <tr style="border-top:1px solid #eaeaea;"><td><b>Address :</b> ggfgg</td>  <td colspan="4" style="text-align:right;"> <b> Status : </b> <?php if($order->status==0){ ?> <span class="label label-danger"> Order is Pendding </span> <?php }elseif($order->status==1){ ?> <span class="label label-info"> Order is Proccess.. </span> <?php }elseif($order->status==2){ ?>
    <span class="label label-success"> Order is Delivered </span>
    <?php } ?></td></tr>
    </table>
    <?php } ?>
   
</div>    
    
    <h2 align="center"> Thankyou </h2>

    */ ?>
</div>
<section id="wrapper">
     
    <div class="container">
      <div id="columns_inner"><div id="left-column" class="col-xs-12" style="width:24.4%">
                    


<div class="block-categories block">
   <h4 class="block_title hidden-md-down">
      <a href="#">Handbags</a>
   </h4>
   <h4 class="block_title hidden-lg-up" data-target="#block_categories_toggle" data-toggle="collapse">
    <a href="#">Handbags</a>
    <span class="pull-xs-right">
      <span class="navbar-toggler collapse-icons">
      <i class="fa-icon add"></i>
      <i class="fa-icon remove"></i>
      </span>
    </span>
  </h4>
   <div id="block_categories_toggle" class="block_content collapse">
     <ul class="category-top-menu">
    <li>  </li>
    </ul>
  </div>
</div>

  <div id="czleftbanner">
    <ul>
              <li class="slide czleftbanner-container">
          <a href="#" title="LeftBanner 1">
            <img src="<?php echo base_url()?>assets/img/left-banner-1.jpg" alt="LeftBanner 1" title="LeftBanner 1">
          </a>        
        </li>
          </ul>
  </div>      

<div id="newproduct_block" class="block products-block">
    <h4 class="block_title hidden-md-down">
    New products
  </h4>
  <h4 class="block_title hidden-lg-up" data-target="#newproduct_block_toggle" data-toggle="collapse">
    New products
    <span class="pull-xs-right">
      <span class="navbar-toggler collapse-icons">
      <i class="fa-icon add"></i>
      <i class="fa-icon remove"></i>
      </span>
    </span>
  </h4>
  <div id="newproduct_block_toggle" class="block_content  collapse">
     
    <ul class="products">
              <li class="product_item">
         
<div class="product-miniature js-product-miniature" data-id-product="15" data-id-product-attribute="268" itemscope="" itemtype="#">
  <div class="product_thumbnail">
    
      <a href="#" class="thumbnail product-image">
      <img src="<?php echo base_url()?>assets/img/108-small_default.jpg" alt="Accusantium Voluptatem">
      </a>
     
  </div>

  <div class="product-info">
    
      <h1 class="h3 product-title" itemprop="name"><a href="#">Accusantium Voluptatem</a></h1>
    
  
    
              <div class="product-price-and-shipping">
              
        
      
        <span itemprop="price" class="price">₹ 80.00</span>
      
        
      
        
        </div>
          
    
      <div class="comments_note">
            <div class="star_content clearfix">
                                                <div class="star"></div>
                                                                <div class="star"></div>
                                                                <div class="star"></div>
                                                                <div class="star"></div>
                                                                <div class="star"></div>
                                    </div>
        <span class="total-rating">0 Review(s)&nbsp;</span>
    </div>
    
    
  </div>
</div>  


        </li>
              <li class="product_item">
         
<div class="product-miniature js-product-miniature" data-id-product="14" data-id-product-attribute="260" itemscope="" itemtype="#">
  <div class="product_thumbnail">
    
      <a href="#" class="thumbnail product-image">
      <img src="<?php echo base_url()?>assets/img/104-small_default.jpg" alt="Occasion praesentium">
      </a>
     
  </div>

  <div class="product-info">
    
      <h1 class="h3 product-title" itemprop="name"><a href="#">Occasion praesentium</a></h1>
    
  
    
              <div class="product-price-and-shipping">
                  
      
          <span class="regular-price">₹ 99.00</span>
                    <span class="discount-percentage">-3%</span>
                        
        
      
        <span itemprop="price" class="price">₹ 96.03</span>
      
        
      
        
        </div>
          
    
      <div class="comments_note">
            <div class="star_content clearfix">
                                                <div class="star star_on"></div>
                                                                <div class="star star_on"></div>
                                                                <div class="star star_on"></div>
                                                                <div class="star star_on"></div>
                                                                <div class="star star_on"></div>
                                    </div>
        <span class="total-rating">1 Review(s)&nbsp;</span>
    </div>
    
    
  </div>
</div>  


        </li>
              <li class="product_item">
         
<div class="product-miniature js-product-miniature" data-id-product="13" data-id-product-attribute="241" itemscope="" itemtype="#">
  <div class="product_thumbnail">
    
      <a href="#" class="thumbnail product-image">
      <img src="<?php echo base_url()?>assets/img/96-small_default.jpg" alt="Laudant doloremque">
      </a>
     
  </div>

  <div class="product-info">
    
      <h1 class="h3 product-title" itemprop="name"><a href="#">Laudant doloremque</a></h1>
    
  
    
              <div class="product-price-and-shipping">
                  
      
          <span class="regular-price">₹ 91.00</span>
                        
        
      
        <span itemprop="price" class="price">₹ 85.00</span>
      
        
      
        
        </div>
          
    
      <div class="comments_note">
            <div class="star_content clearfix">
                                                <div class="star"></div>
                                                                <div class="star"></div>
                                                                <div class="star"></div>
                                                                <div class="star"></div>
                                                                <div class="star"></div>
                                    </div>
        <span class="total-rating">0 Review(s)&nbsp;</span>
    </div>
    
    
  </div>
</div>  


        </li>
        
    </ul>
     
    <!-- <div class="view_more">
      <a class="all-product-link btn btn-primary" href="#">
        All new products
      </a>
    </div> -->
    
  </div>
</div>


<!-- Block categories module -->
        <!-- <div id="categories_blog_menu" class="block blog-menu">
      <h4 class="block_title hidden-md-down">
        Blog Categories   </h4>
    <h4 class="block_title hidden-lg-up" data-target="#categories_blog_toggle" data-toggle="collapse">
      Blog Categories     <span class="pull-xs-right">
        <span class="navbar-toggler collapse-icons">
        <i class="fa-icon add"></i>
        <i class="fa-icon remove"></i>
        </span>
      </span>
    </h4>
        <div id="categories_blog_toggle" class="block_content  collapse">
            <ul class="level1 tree dhtml "><li id="list_3" class=" "><a href="#" title="Vestibulum consequat"><span>Vestibulum consequat</span></a> <ul class="level2 "><li id="list_4" class=" "><a href="#" title="Pellentesque condimentum"><span>Pellentesque condimentum</span></a> </li><li id="list_5" class=" "><a href="#" title="Suspendisse turpis"><span>Suspendisse turpis</span></a> </li></ul></li></ul>
        </div>
    </div> -->
        <!-- /Block categories module -->

                  </div>
        
        
        

        
  <div id="content-wrapper" class="left-column col-xs-12 col-sm-8 col-md-9" style="width:75.6%">

    

  <section id="main">

    
      
        <header class="page-header">
          <h1>
  Order history
</h1>
        </header>
      
    

    
  <section id="content" class="page-content">
    
      
        
<aside id="notifications">
  <div class="container">
    
    
    
      </div>
</aside>
      
    
    
  <h6>Here are the orders you've placed since your account was created.</h6>

      <table class="table table-striped table-bordered table-labeled hidden-sm-down">
      <thead class="thead-default">
        <tr>
          <th>Order Number</th>
          <th>Quntity</th>
          <th>Order Date</th>
          <th>Total price</th>
          <th class="hidden-md-down">Payment</th>
          <th class="hidden-md-down">Status</th>
          <!-- <th>Invoice</th>
          <th>&nbsp;</th> -->
        </tr>
      </thead>
      <tbody>
         <?php foreach($orders->result() as $order){ ?>
         <?php $userHistory = $this->Order_model->UserorderDetail($order->id);
          $total_price=$total_item=0;
        foreach ($userHistory->result() as $value) { 
        $total_price =$total_price + ($value->price)*($value->quantity);
        $total_item=$total_item+$value->quantity;
                }
        ?>
                  <tr>
            <th scope="row"><?php echo $order->Bill_Number; ?></th>
            <td><?php echo $total_item; ?></td>
            
            <td><?php echo $order->OrderDate; ?></td>
            <td class="text-xsright"><?php echo $total_price; ?></td>
            <td class="hidden-md-down">Cash on delivery (COD)</td>
            <td>
              <?php if($order->status==0){ ?> 
                <span class="label label-pill dark" style="background-color:red"> Order is Pendding </span> 
              <?php }elseif($order->status==1){ ?> 
                <span class="label label-pill dark" style="background-color:#FF8C00">
                Processing in progress
              </span>
                 <?php }elseif($order->status==2){ ?>
    
    <span class="label label-pill dark" style="background-color:green"> Order is Delivered </span>
    <?php } ?>

            </td>
            <!-- <td class="text-sm-center hidden-md-down">
              <a href="#"><i class="material-icons"></i></a>
            </td>
            <td class="text-sm-center order-actions">
              <a href="<?php echo base_url(); ?>order/order_details" data-link-action="view-order-details">
                Details
              </a>
              <a href="<?php echo base_url(); ?>cart/checkout">Reorder</a>
            </td> -->
          </tr>
          
           <?php } ?>
         <!--          <tr>
            <th scope="row">MOUYVEUCG</th>
            <td><img src="<?php echo base_url()?>assets/img/96-small_default.jpg" alt="Laudant doloremque"></td>
            <td>pro</td>
            <td>766</td>
            <td>7489</td>
            <td>08/11/2018</td>
            <td class="text-xsright">$290.65</td>
            <td class="hidden-md-down">Bank transfer</td>
            <td>
              <span class="label label-pill bright" style="background-color:#4169E1">
                Awaiting bank wire payment
              </span>
            </td>
            <td class="text-sm-center hidden-md-down">
                              -
                          </td>
            <td class="text-sm-center order-actions">
              <a href="<?php echo base_url(); ?>order/order_details" data-link-action="view-order-details">
                Details
              </a>
                              <a href="<?php echo base_url(); ?>cart/checkout">Reorder</a>
                          </td>
          </tr>
                  <tr>
            <th scope="row">XCKPRZFHI</th>
            <td><img src="<?php echo base_url()?>assets/img/96-small_default.jpg" alt="Laudant doloremque"></td>
            <td>pro</td>
            <td>766</td>
            <td>7489</td>
            <td>07/26/2018</td>
            <td class="text-xsright">$156.00</td>
            <td class="hidden-md-down">Payments by check</td>
            <td>
              <span class="label label-pill bright" style="background-color:#4169E1">
                Awaiting check payment
              </span>
            </td>
            <td class="text-sm-center hidden-md-down">
                              -
                          </td>
            <td class="text-sm-center order-actions">
              <a href="<?php echo base_url(); ?>order/order_details" data-link-action="view-order-details">
                Details
              </a>
                              <a href="<?php echo base_url(); ?>cart/checkout">Reorder</a>
                          </td>
          </tr>
                  <tr>
            <th scope="row">MLZOSVBKE</th>
            <td><img src="<?php echo base_url()?>assets/img/96-small_default.jpg" alt="Laudant doloremque"></td>
            <td>pro</td>
            <td>766</td>
            <td>7489</td>
            <td>07/24/2018</td>
            <td class="text-xsright">$78.00</td>
            <td class="hidden-md-down">Cash on delivery (COD)</td>
            <td>
              <span class="label label-pill dark" style="background-color:#FF8C00">
                Processing in progress
              </span>
            </td>
            <td class="text-sm-center hidden-md-down">
                              <a href="#"><i class="material-icons"></i></a>
                          </td>
            <td class="text-sm-center order-actions">
              <a href="<?php echo base_url(); ?>order/order_details" data-link-action="view-order-details">
                Details
              </a>
                              <a href="<?php echo base_url(); ?>cart/checkout">Reorder</a>
                          </td>
          </tr> -->
              </tbody>
    </table>

    <div class="orders hidden-md-up">
              <div class="order">
          <div class="row">
            <div class="col-xs-10">
              <a href="#"><h3>KIQELIOQM</h3></a>
              <div class="date">08/11/2018</div>
              <div class="total">$98.00</div>
              <div class="status">
                <span class="label label-pill dark" style="background-color:#FF8C00">
                  Processing in progress
                </span>
              </div>
            </div>
            <div class="col-xs-2 text-xsright">
                <div>
                  <a href="#" data-link-action="view-order-details" title="Details">
                    <i class="material-icons"></i>
                  </a>
                </div>
                                  <div>
                    <a href="#" title="Reorder">
                      <i class="material-icons"></i>
                    </a>
                  </div>
                            </div>
          </div>
        </div>
              <div class="order">
          <div class="row">
            <div class="col-xs-10">
              <a href="#"><h3>MOUYVEUCG</h3></a>
              <div class="date">08/11/2018</div>
              <div class="total">₹ 290.65</div>
              <div class="status">
                <span class="label label-pill bright" style="background-color:#4169E1">
                  Awaiting bank wire payment
                </span>
              </div>
            </div>
            <div class="col-xs-2 text-xsright">
                <div>
                  <a href="#" data-link-action="view-order-details" title="Details">
                    <i class="material-icons"></i>
                  </a>
                </div>
                                  <div>
                    <a href="#" title="Reorder">
                      <i class="material-icons"></i>
                    </a>
                  </div>
                            </div>
          </div>
        </div>
              <div class="order">
          <div class="row">
            <div class="col-xs-10">
              <a href="#"><h3>XCKPRZFHI</h3></a>
              <div class="date">07/26/2018</div>
              <div class="total">₹ 156.00</div>
              <div class="status">
                <span class="label label-pill bright" style="background-color:#4169E1">
                  Awaiting check payment
                </span>
              </div>
            </div>
            <div class="col-xs-2 text-xsright">
                <div>
                  <a href="#" data-link-action="view-order-details" title="Details">
                    <i class="material-icons"></i>
                  </a>
                </div>
                                  <div>
                    <a href="#" title="Reorder">
                      <i class="material-icons"></i>
                    </a>
                  </div>
                            </div>
          </div>
        </div>
              <div class="order">
          <div class="row">
            <div class="col-xs-10">
              <a href="#"><h3>MLZOSVBKE</h3></a>
              <div class="date">07/24/2018</div>
              <div class="total">₹ 78.00</div>
              <div class="status">
                <span class="label label-pill dark" style="background-color:#FF8C00">
                  Processing in progress
                </span>
              </div>
            </div>
            <div class="col-xs-2 text-xsright">
                <div>
                  <a href="#" data-link-action="view-order-details" title="Details">
                    <i class="material-icons"></i>
                  </a>
                </div>
                                  <div>
                    <a href="#" title="Reorder">
                      <i class="material-icons"></i>
                    </a>
                  </div>
                            </div>
          </div>
        </div>
          </div>

  
  </section>


    
      <footer class="page-footer">
        
  
    
  <a href="#" class="account-link">
    <i class="material-icons"></i>
    <span>Back to your account</span>
  </a>
  <a href="#" class="account-link">
    <i class="material-icons"></i>
    <span>Home</span>
  </a>

  

      </footer>
    

  </section>


    
  </div>


        
      </div>
        </div>

      </section>
<!-- footer -->
<?php $this->load->view('common/imt/footer1'); ?>
<!-- //footer -->
<!-- login -->
<script type="text/javascript" src="<?php echo base_url(); ?>assets/themes/Fashcod/assets/cache/bottom-9149e8.js" ></script>

<?php $this->load->view('common/imt/customer'); ?>
<script type="text/javascript">
$('ul.nav li.dropdown').hover(function() {
  $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn(500);
}, function() {
  $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(500);
});
</script>
<!-- Mirrored from p.w3layouts.com/demos/apr-2016/05-04-2016/smart_shop/web/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 15 Jun 2018 06:05:39 GMT -->
</main>
</body>
</html>


  <body id="cart" class="lang-en country-us currency-usd layout-full-width page-cart tax-display-disabled cart-empty">

    
    	
    

    <main id="page">
      
              

      <header id="header">
        
          
  <div class="header-banner">
    
  </div>



<nav class="header-nav">
	<div class="container">
        
		
			<div class="left-nav">
				
			</div>
			
			<div class="right-nav">
				
			</div>
		
		
		
        
	</div>
</nav>

 <!-- header-bot -->
      <?php $this->load->view('common/imt/header'); ?>
      <!-- //header-bot -->
      <!-- banner -->
      <?php $this->load->view('common/imt/navbar'); ?>
        
      </header>

      
        
<aside id="notifications">
  <div class="container">
    
    
    
      </div>
</aside>
      
      			
	  
	  		<nav data-depth="1" class="breadcrumb">
   <div class="container">
  <ol itemscope itemtype="#">
          
      <li itemprop="itemListElement" itemscope itemtype="#">
        <a itemprop="item" href="index.html">
          <span itemprop="name">Home</span>
        </a>
        <meta itemprop="position" content="1">
      </li>
      
      </ol>
  </div>
</nav>
	  
	  
	  <section id="wrapper">
		 
		<div class="container">
		  <div id="columns_inner">
			  

			  
  <div id="content-wrapper">
    
    

  <section id="main">
    <div class="cart-grid row">

      <!-- Left Block: cart product informations & shpping -->
      <div class="cart-grid-body col-xs-12 col-lg-8">

        <!-- cart products detailed -->
        <div class="card cart-container">
          <div class="card-block">
            <h1 class="h1">Shopping Cart</h1>
          </div>
          <hr class="separator">
          
            
  <div class="cart-overview js-cart" data-refresh-url="<?php echo base_url().'Cart/detail'; ?>">
          
          <?php $grand_total=0; if ($cart = $this->cart->contents()){ ?>  
          <ul class="cart-items">
            <?php  foreach ($cart as $item): ?>
          <li class="cart-item">
          
            <div class="product-line-grid">
              <!--  product left content: image-->
              <div class="product-line-grid-left col-md-3 col-xs-4">
                <span class="product-image media-middle">
                  <img src="<?php echo IMAGE_URL; ?><?php echo $item['image']; ?>" alt="<?php echo $item['name']; ?>">
                </span>
              </div>

              <!--  product left body: description -->
              <div class="product-line-grid-body col-md-4 col-xs-8">
                <div class="product-line-info">
                  <a class="label" href="#" data-id_customization="0"><?php echo $item['name']; ?></a>
                </div>

                <div class="product-line-info product-price h5 has-discount">
                          <div class="product-discount">
                      <span class="regular-price">₹ <?php echo number_format($item['price'],2); ?></span>
                                  <span class="discount discount-percentage">
                            0%
                          </span>
                              </div>
                        <div class="current-price">
                    <span class="price">₹ <?php echo number_format($item['price'],2); ?></span>
                          </div>
                </div>

                <br>
                
                  
                <?php if($item['color'] !='' ){ ?> 
                <div class="product-line-info">
                    <span class="label">Color </span>: &nbsp;&nbsp;&nbsp;&nbsp;
                    <span class="color" style="background-color: <?php echo $item['color']; ?>"> </span>
                </div>
                <?php } ?>

                <?php if($item['size'] !='' ){ ?> 
                <div class="product-line-info">
                    <span class="label">Size</span>&nbsp;&nbsp;&nbsp;&nbsp; : &nbsp;&nbsp;&nbsp;
                    <span class="size">  <?php echo $item['size']; ?></span>
                </div>
                <?php } ?>
    
              </div>

              <!--  product left body: description -->
              <div class="product-line-grid-right product-line-actions col-md-5 col-xs-12">
                <div class="row">
                  <div class="col-xs-4 hidden-md-up"></div>
                  <div class="col-md-10 col-xs-6">
                    <div class="row">
                      <div class="col-md-6 col-xs-6 qty">
                        <div class="input-group bootstrap-touchspin"><span class="input-group-addon bootstrap-touchspin-prefix" style="display: none;"></span><input class="js-cart-line-product-quantity form-control" data-down-url="<?php echo base_url();?>Cart/update" data-up-url="<?php echo base_url();?>Cart/update" data-update-url="<?php echo base_url();?>Cart/update" data-product-id="<?php echo $item['rowid']; ?>" data-price="<?php echo $item['price']; ?>" value="<?php echo $item['qty']; ?>" name="product-quantity-spin" min="1" style="display: block;" type="text"><span class="input-group-addon bootstrap-touchspin-postfix" style="display: none;"></span><span class="input-group-btn-vertical"><button class="btn btn-touchspin js-touchspin js-increase-product-quantity bootstrap-touchspin-up" type="button"><i class="material-icons touchspin-up"></i></button><button class="btn btn-touchspin js-touchspin js-decrease-product-quantity bootstrap-touchspin-down" type="button"><i class="material-icons touchspin-down"></i></button></span></div>
                      </div>
                      <div class="col-md-6 col-xs-2 price">
                        <span class="product-price">
                          <strong>
                            ₹<?php echo number_format($item['subtotal'],2); ?>
                          </strong>
                        </span>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-2 col-xs-2 text-xsright">
                    <div class="cart-line-product-actions">
                      <a class="" rel="nofollow" href="<?php echo site_url('Cart/remove/'.$item['rowid']); ?>" >
                        <i class="material-icons float-xs-left">delete</i>
                      </a>





                    </div>
                  </div>
                </div>
              </div>

              <div class="clearfix"></div>
            </div>

          </li>
           <?php $grand_total = $grand_total + $item['subtotal']; ?>
          <?php endforeach; ?>
        </ul>
                <?php } else {?>
                  <span class="no-items">There are no more items in your cart</span>
                <?php } ?>  
      </div>

          
        </div>

        
  <a class="label" href="<?php echo base_url();?>">
    <i class="material-icons">chevron_left</i>Continue shopping
  </a>


        <!-- shipping informations -->
        
          
        
      </div>

      <!-- Right Block: cart subtotal & cart total -->
      <div class="cart-grid-right col-xs-12 col-lg-4">

        
          <div class="card cart-summary">

            
              
            

            
              
<div class="cart-detailed-totals">

  <div class="card-block">
                  <div class="cart-summary-line" id="cart-subtotal-products">
          <span class="label js-subtotal">
                         <?php echo $this->cart->total_items(); ?> items
                      </span>
          <span class="value">₹<?php echo $grand_total; ?></span>
                  </div>
                                  <div class="cart-summary-line" id="cart-subtotal-shipping">
          <span class="label">
                          Shipping
                      </span>
          <span class="value">Free</span>
                        <div><small class="value"></small></div>
                  </div>
                      </div>

  

  <hr class="separator">

  <div class="card-block">
    <div class="cart-summary-line cart-total">
      <span class="label">Total </span>
      <span class="value">₹<?php echo $grand_total; ?></span>
    </div>

    <!-- <div class="cart-summary-line">
      <small class="label">Taxes</small>
      <small class="value">$0.00</small>
    </div> -->
  </div>

  <hr class="separator">
</div>

            

            
  <div class="checkout text-sm-center card-block">
 <a href="<?php echo base_url(); ?>Cart/checkout" class="btn btn-primary ">Checkout</a>
  </div>


          </div>
      </div>

    </div>
  </section>

<section class="featured-products clearfix">
  <h1 class="h1 products-section-title text-uppercase ">
    Popular Products
  </h1>
  <div class="featured-products-wrapper">
    <div class="products">
      <ul class="featured_grid product_list grid row gridcount">
        <?php $subproduct = $this->Product_model->ProductListBytype('3','12');
        foreach($subproduct->result() as $p_value){?>
        <li class="product_item col-xs-12 col-sm-6 col-md-4 col-lg-3">
          <div class="product-miniature js-product-miniature" data-id-product="1" data-id-product-attribute="49" itemscope itemtype="#">
            <div class="thumbnail-container">
              <a href="<?php echo base_url(); ?>single_ProductDetail<?php echo base64_encode('pd1234'); ?>_page?ee=<?php echo base64_encode($p_value->id); ?>" class="thumbnail product-thumbnail">
                <img
                  src = "<?php echo IMAGE_URL; ?><?php echo $p_value->image; ?>"
                  alt = "Consectetur Hampden"
                  data-full-size-image-url = "<?php echo IMAGE_URL; ?><?php echo $p_value->image; ?>"
                >
                <img class="fliper_image img-responsive" src="<?php echo IMAGE_URL; ?><?php echo $p_value->image; ?>" data-full-size-image-url="<?php echo IMAGE_URL; ?><?php echo $p_value->image; ?>" alt="" />
              </a>
              <div class="outer-functional">
                <div class="functional-buttons">
                  <a href="<?php echo base_url(); ?>single_ProductDetail<?php echo base64_encode('pd1234'); ?>_page?ee=<?php echo base64_encode($p_value->id); ?>" class="quick-view" data-link-action="quickview">
                    <i class="material-icons search">&#xE417;</i> Quick view
                  </a>
                  <div class="product-actions">
                    <form action="<?php echo base_url(); ?>Cart/add" method="post" class="add-to-cart-or-refresh">
                     <input type="hidden" name="p_id" value="<?php echo $p_value->id; ?>" > 
                    <input type="hidden" name="p_name" value="<?php echo $p_value->name; ?>" > 
                    <input type="hidden" name="p_category" value="<?php echo $p_value->category_id; ?>" > 
                    <input type="hidden" name="p_subcategoryId" value="<?php echo $p_value->subcategory_id; ?>" > 
                    <input type="hidden" name="p_qty" value="1" > 
                    <input type="hidden" name="p_price" value="<?php echo $p_value->price; ?>" >
                    <input type="hidden" name="p_image" value="<?php echo $p_value->image; ?>" > 
                    <?php $total_price = ($p_value->price)*(1); ?>
                    <input type="hidden" name="p_total" value="<?php echo $total_price; ?>" > 
                      <button class="btn btn-primary add-to-cart" data-button-action="add-to-cart" type="submit" >
                        Add to cart
                      </button>
                    </form>
                  </div>
                </div>
              </div>	
            </div>
            <div class="product-description">
              <span class="h3 product-title" itemprop="name"><a href="<?php echo base_url(); ?>single_ProductDetail<?php echo base64_encode('pd1234'); ?>_page?ee=<?php echo base64_encode($p_value->id); ?>"><?php echo $p_value->name; ?></a></span>
              <div class="product-price-and-shipping">
                <span itemprop="price" class="price">$<?php echo $p_value->price; ?></span>
              </div>
              <div class="comments_note">
                <div class="star_content clearfix">
                  <div class="star star_on"></div>
                  <div class="star star_on"></div>
                  <div class="star star_on"></div>
                  <div class="star star_on"></div>
                  <div class="star star_on"></div>
                </div>
                <span class="total-rating">1 Review(s)&nbsp</span>
              </div>
              <div class="highlighted-informations hidden-sm-down">
                <div class="variant-links">
                  <a href="#" class="color" title="Black" style="background-color: #434A54"><span class="sr-only">Black</span></a>
                  <a href="#" class="color" title="Orange" style="background-color: #F39C11"><span class="sr-only">Orange</span></a>
                  <a href="#" class="color" title="Green" style="background-color: #A0D468"><span class="sr-only">Green</span></a>
                  <span class="js-count count"></span>
                </div>
              </div>
            </div>
          </div>
        </li>
      <?php } ?>
      </ul>
      <div class="view_more">
        <a class="all-product-link" href="#">All products</a>
      </div>
    </div>
  </div>
</section>
</div>
</div>
</div>
</section>

     
<!-- footer -->
<?php $this->load->view('common/imt/footer1'); ?>
<!-- //footer -->
</main>


<script type="text/javascript" src="<?php echo base_url(); ?>assets/themes/Fashcod/assets/cache/bottom-9149e8.js" ></script>

<?php $this->load->view('common/imt/customer'); ?>



    

    
    	
    
  </body>


<!-- Mirrored from codezeel.com/prestashop/PRS06/PRS060129/index.php?controller=cart&action=show by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 17 Jul 2018 15:48:09 GMT -->
</html>
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-01-04 06:24:21 --> Config Class Initialized
INFO - 2019-01-04 06:24:21 --> Hooks Class Initialized
DEBUG - 2019-01-04 06:24:21 --> UTF-8 Support Enabled
INFO - 2019-01-04 06:24:21 --> Utf8 Class Initialized
INFO - 2019-01-04 06:24:21 --> URI Class Initialized
DEBUG - 2019-01-04 06:24:21 --> No URI present. Default controller set.
INFO - 2019-01-04 06:24:21 --> Router Class Initialized
INFO - 2019-01-04 06:24:21 --> Output Class Initialized
INFO - 2019-01-04 06:24:21 --> Security Class Initialized
DEBUG - 2019-01-04 06:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-04 06:24:21 --> Input Class Initialized
INFO - 2019-01-04 06:24:21 --> Language Class Initialized
INFO - 2019-01-04 06:24:21 --> Loader Class Initialized
INFO - 2019-01-04 06:24:21 --> Controller Class Initialized
INFO - 2019-01-04 06:24:21 --> File loaded: /home/impetqry/public_html/schoolManagment/application/views/welcome_message.php
INFO - 2019-01-04 06:24:21 --> Final output sent to browser
DEBUG - 2019-01-04 06:24:21 --> Total execution time: 0.0094
ERROR - 2019-01-04 06:24:21 --> Severity: Core Warning --> APM cannot be enabled, '/var/php/apm/db' is not directory Unknown 0
INFO - 2019-01-04 06:24:23 --> Config Class Initialized
INFO - 2019-01-04 06:24:23 --> Hooks Class Initialized
DEBUG - 2019-01-04 06:24:23 --> UTF-8 Support Enabled
INFO - 2019-01-04 06:24:23 --> Utf8 Class Initialized
INFO - 2019-01-04 06:24:23 --> URI Class Initialized
DEBUG - 2019-01-04 06:24:23 --> No URI present. Default controller set.
INFO - 2019-01-04 06:24:23 --> Router Class Initialized
INFO - 2019-01-04 06:24:23 --> Output Class Initialized
INFO - 2019-01-04 06:24:23 --> Security Class Initialized
DEBUG - 2019-01-04 06:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-04 06:24:23 --> Input Class Initialized
INFO - 2019-01-04 06:24:23 --> Language Class Initialized
INFO - 2019-01-04 06:24:23 --> Loader Class Initialized
INFO - 2019-01-04 06:24:23 --> Controller Class Initialized
INFO - 2019-01-04 06:24:23 --> File loaded: /home/impetqry/public_html/schoolManagment/application/views/welcome_message.php
INFO - 2019-01-04 06:24:23 --> Final output sent to browser
DEBUG - 2019-01-04 06:24:23 --> Total execution time: 0.0095
ERROR - 2019-01-04 06:24:23 --> Severity: Core Warning --> APM cannot be enabled, '/var/php/apm/db' is not directory Unknown 0
INFO - 2019-01-04 06:31:40 --> Config Class Initialized
INFO - 2019-01-04 06:31:40 --> Hooks Class Initialized
DEBUG - 2019-01-04 06:31:40 --> UTF-8 Support Enabled
INFO - 2019-01-04 06:31:40 --> Utf8 Class Initialized
INFO - 2019-01-04 06:31:40 --> URI Class Initialized
DEBUG - 2019-01-04 06:31:40 --> No URI present. Default controller set.
INFO - 2019-01-04 06:31:40 --> Router Class Initialized
INFO - 2019-01-04 06:31:40 --> Output Class Initialized
INFO - 2019-01-04 06:31:40 --> Security Class Initialized
DEBUG - 2019-01-04 06:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-04 06:31:40 --> Input Class Initialized
INFO - 2019-01-04 06:31:40 --> Language Class Initialized
INFO - 2019-01-04 06:31:40 --> Loader Class Initialized
INFO - 2019-01-04 06:31:40 --> Database Driver Class Initialized
ERROR - 2019-01-04 06:31:40 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'root'@'localhost' (using password: NO) /home/impetqry/public_html/schoolManagment/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2019-01-04 06:31:40 --> Unable to connect to the database
INFO - 2019-01-04 06:31:40 --> Language file loaded: language/english/db_lang.php
ERROR - 2019-01-04 06:31:40 --> Severity: Core Warning --> APM cannot be enabled, '/var/php/apm/db' is not directory Unknown 0
INFO - 2019-01-04 06:34:37 --> Config Class Initialized
INFO - 2019-01-04 06:34:37 --> Hooks Class Initialized
DEBUG - 2019-01-04 06:34:37 --> UTF-8 Support Enabled
INFO - 2019-01-04 06:34:37 --> Utf8 Class Initialized
INFO - 2019-01-04 06:34:37 --> URI Class Initialized
DEBUG - 2019-01-04 06:34:37 --> No URI present. Default controller set.
INFO - 2019-01-04 06:34:37 --> Router Class Initialized
INFO - 2019-01-04 06:34:37 --> Output Class Initialized
INFO - 2019-01-04 06:34:37 --> Security Class Initialized
DEBUG - 2019-01-04 06:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-04 06:34:37 --> Input Class Initialized
INFO - 2019-01-04 06:34:37 --> Language Class Initialized
INFO - 2019-01-04 06:34:37 --> Loader Class Initialized
INFO - 2019-01-04 06:34:37 --> Database Driver Class Initialized
INFO - 2019-01-04 06:34:37 --> Email Class Initialized
DEBUG - 2019-01-04 06:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-04 06:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-04 06:34:37 --> Controller Class Initialized
INFO - 2019-01-04 06:34:37 --> File loaded: /home/impetqry/public_html/schoolManagment/application/views/welcome_message.php
INFO - 2019-01-04 06:34:37 --> Final output sent to browser
DEBUG - 2019-01-04 06:34:37 --> Total execution time: 0.0199
ERROR - 2019-01-04 06:34:37 --> Severity: Core Warning --> APM cannot be enabled, '/var/php/apm/db' is not directory Unknown 0
INFO - 2019-01-04 06:34:40 --> Config Class Initialized
INFO - 2019-01-04 06:34:40 --> Hooks Class Initialized
DEBUG - 2019-01-04 06:34:40 --> UTF-8 Support Enabled
INFO - 2019-01-04 06:34:40 --> Utf8 Class Initialized
INFO - 2019-01-04 06:34:40 --> URI Class Initialized
DEBUG - 2019-01-04 06:34:40 --> No URI present. Default controller set.
INFO - 2019-01-04 06:34:40 --> Router Class Initialized
INFO - 2019-01-04 06:34:40 --> Output Class Initialized
INFO - 2019-01-04 06:34:40 --> Security Class Initialized
DEBUG - 2019-01-04 06:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-04 06:34:40 --> Input Class Initialized
INFO - 2019-01-04 06:34:40 --> Language Class Initialized
INFO - 2019-01-04 06:34:40 --> Loader Class Initialized
INFO - 2019-01-04 06:34:40 --> Database Driver Class Initialized
INFO - 2019-01-04 06:34:40 --> Email Class Initialized
DEBUG - 2019-01-04 06:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-04 06:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-04 06:34:40 --> Controller Class Initialized
INFO - 2019-01-04 06:34:40 --> File loaded: /home/impetqry/public_html/schoolManagment/application/views/welcome_message.php
INFO - 2019-01-04 06:34:40 --> Final output sent to browser
DEBUG - 2019-01-04 06:34:40 --> Total execution time: 0.0203
ERROR - 2019-01-04 06:34:40 --> Severity: Core Warning --> APM cannot be enabled, '/var/php/apm/db' is not directory Unknown 0
INFO - 2019-01-04 06:34:44 --> Config Class Initialized
INFO - 2019-01-04 06:34:44 --> Hooks Class Initialized
DEBUG - 2019-01-04 06:34:44 --> UTF-8 Support Enabled
INFO - 2019-01-04 06:34:44 --> Utf8 Class Initialized
INFO - 2019-01-04 06:34:44 --> URI Class Initialized
DEBUG - 2019-01-04 06:34:44 --> No URI present. Default controller set.
INFO - 2019-01-04 06:34:44 --> Router Class Initialized
INFO - 2019-01-04 06:34:44 --> Output Class Initialized
INFO - 2019-01-04 06:34:44 --> Security Class Initialized
DEBUG - 2019-01-04 06:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-04 06:34:44 --> Input Class Initialized
INFO - 2019-01-04 06:34:44 --> Language Class Initialized
INFO - 2019-01-04 06:34:44 --> Loader Class Initialized
INFO - 2019-01-04 06:34:44 --> Database Driver Class Initialized
INFO - 2019-01-04 06:34:44 --> Email Class Initialized
DEBUG - 2019-01-04 06:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-04 06:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-04 06:34:44 --> Controller Class Initialized
INFO - 2019-01-04 06:34:44 --> File loaded: /home/impetqry/public_html/schoolManagment/application/views/welcome_message.php
INFO - 2019-01-04 06:34:44 --> Final output sent to browser
DEBUG - 2019-01-04 06:34:44 --> Total execution time: 0.0221
ERROR - 2019-01-04 06:34:44 --> Severity: Core Warning --> APM cannot be enabled, '/var/php/apm/db' is not directory Unknown 0
INFO - 2019-01-04 06:38:11 --> Config Class Initialized
INFO - 2019-01-04 06:38:11 --> Hooks Class Initialized
DEBUG - 2019-01-04 06:38:11 --> UTF-8 Support Enabled
INFO - 2019-01-04 06:38:11 --> Utf8 Class Initialized
INFO - 2019-01-04 06:38:11 --> URI Class Initialized
DEBUG - 2019-01-04 06:38:11 --> No URI present. Default controller set.
INFO - 2019-01-04 06:38:11 --> Router Class Initialized
INFO - 2019-01-04 06:38:11 --> Output Class Initialized
INFO - 2019-01-04 06:38:11 --> Security Class Initialized
DEBUG - 2019-01-04 06:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-04 06:38:11 --> Input Class Initialized
INFO - 2019-01-04 06:38:11 --> Language Class Initialized
INFO - 2019-01-04 06:38:11 --> Loader Class Initialized
INFO - 2019-01-04 06:38:11 --> Database Driver Class Initialized
INFO - 2019-01-04 06:38:11 --> Email Class Initialized
DEBUG - 2019-01-04 06:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-04 06:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-04 06:38:11 --> Controller Class Initialized
INFO - 2019-01-04 06:38:11 --> File loaded: /home/impetqry/public_html/schoolManagment/application/views/welcome_message.php
INFO - 2019-01-04 06:38:11 --> Final output sent to browser
DEBUG - 2019-01-04 06:38:11 --> Total execution time: 0.0200
ERROR - 2019-01-04 06:38:11 --> Severity: Core Warning --> APM cannot be enabled, '/var/php/apm/db' is not directory Unknown 0
INFO - 2019-01-04 06:45:47 --> Config Class Initialized
INFO - 2019-01-04 06:45:47 --> Hooks Class Initialized
DEBUG - 2019-01-04 06:45:47 --> UTF-8 Support Enabled
INFO - 2019-01-04 06:45:47 --> Utf8 Class Initialized
INFO - 2019-01-04 06:45:47 --> URI Class Initialized
DEBUG - 2019-01-04 06:45:47 --> No URI present. Default controller set.
INFO - 2019-01-04 06:45:47 --> Router Class Initialized
INFO - 2019-01-04 06:45:47 --> Output Class Initialized
INFO - 2019-01-04 06:45:47 --> Security Class Initialized
DEBUG - 2019-01-04 06:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-04 06:45:47 --> Input Class Initialized
INFO - 2019-01-04 06:45:47 --> Language Class Initialized
INFO - 2019-01-04 06:45:47 --> Loader Class Initialized
INFO - 2019-01-04 06:45:47 --> Database Driver Class Initialized
INFO - 2019-01-04 06:45:47 --> Email Class Initialized
DEBUG - 2019-01-04 06:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-04 06:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-04 06:45:47 --> Controller Class Initialized
INFO - 2019-01-04 06:45:47 --> File loaded: /home/impetqry/public_html/schoolManagment/application/views/welcome_message.php
INFO - 2019-01-04 06:45:47 --> Final output sent to browser
DEBUG - 2019-01-04 06:45:47 --> Total execution time: 0.0235
ERROR - 2019-01-04 06:45:47 --> Severity: Core Warning --> APM cannot be enabled, '/var/php/apm/db' is not directory Unknown 0
INFO - 2019-01-04 06:49:40 --> Config Class Initialized
INFO - 2019-01-04 06:49:40 --> Hooks Class Initialized
DEBUG - 2019-01-04 06:49:40 --> UTF-8 Support Enabled
INFO - 2019-01-04 06:49:40 --> Utf8 Class Initialized
INFO - 2019-01-04 06:49:40 --> URI Class Initialized
DEBUG - 2019-01-04 06:49:40 --> No URI present. Default controller set.
INFO - 2019-01-04 06:49:40 --> Router Class Initialized
INFO - 2019-01-04 06:49:40 --> Output Class Initialized
INFO - 2019-01-04 06:49:40 --> Security Class Initialized
DEBUG - 2019-01-04 06:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-04 06:49:40 --> Input Class Initialized
INFO - 2019-01-04 06:49:40 --> Language Class Initialized
INFO - 2019-01-04 06:49:40 --> Loader Class Initialized
INFO - 2019-01-04 06:49:40 --> Database Driver Class Initialized
INFO - 2019-01-04 06:49:40 --> Email Class Initialized
DEBUG - 2019-01-04 06:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-04 06:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-04 06:49:40 --> Controller Class Initialized
INFO - 2019-01-04 06:49:40 --> File loaded: /home/impetqry/public_html/schoolManagment/application/views/welcome_message.php
INFO - 2019-01-04 06:49:40 --> Final output sent to browser
DEBUG - 2019-01-04 06:49:40 --> Total execution time: 0.0211
ERROR - 2019-01-04 06:49:40 --> Severity: Core Warning --> APM cannot be enabled, '/var/php/apm/db' is not directory Unknown 0
INFO - 2019-01-04 06:59:11 --> Config Class Initialized
INFO - 2019-01-04 06:59:11 --> Hooks Class Initialized
DEBUG - 2019-01-04 06:59:11 --> UTF-8 Support Enabled
INFO - 2019-01-04 06:59:11 --> Utf8 Class Initialized
INFO - 2019-01-04 06:59:11 --> URI Class Initialized
DEBUG - 2019-01-04 06:59:11 --> No URI present. Default controller set.
INFO - 2019-01-04 06:59:11 --> Router Class Initialized
INFO - 2019-01-04 06:59:11 --> Output Class Initialized
INFO - 2019-01-04 06:59:11 --> Security Class Initialized
DEBUG - 2019-01-04 06:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-04 06:59:11 --> Input Class Initialized
INFO - 2019-01-04 06:59:11 --> Language Class Initialized
INFO - 2019-01-04 06:59:11 --> Loader Class Initialized
INFO - 2019-01-04 06:59:11 --> Database Driver Class Initialized
INFO - 2019-01-04 06:59:11 --> Email Class Initialized
DEBUG - 2019-01-04 06:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-04 06:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-04 06:59:11 --> Controller Class Initialized
INFO - 2019-01-04 06:59:11 --> File loaded: /home/impetqry/public_html/schoolManagment/application/views/welcome_message.php
INFO - 2019-01-04 06:59:11 --> Final output sent to browser
DEBUG - 2019-01-04 06:59:11 --> Total execution time: 0.0219
ERROR - 2019-01-04 06:59:11 --> Severity: Core Warning --> APM cannot be enabled, '/var/php/apm/db' is not directory Unknown 0
INFO - 2019-01-04 06:59:26 --> Config Class Initialized
INFO - 2019-01-04 06:59:26 --> Hooks Class Initialized
DEBUG - 2019-01-04 06:59:26 --> UTF-8 Support Enabled
INFO - 2019-01-04 06:59:26 --> Utf8 Class Initialized
INFO - 2019-01-04 06:59:26 --> URI Class Initialized
DEBUG - 2019-01-04 06:59:26 --> No URI present. Default controller set.
INFO - 2019-01-04 06:59:26 --> Router Class Initialized
INFO - 2019-01-04 06:59:26 --> Output Class Initialized
INFO - 2019-01-04 06:59:26 --> Security Class Initialized
DEBUG - 2019-01-04 06:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-04 06:59:26 --> Input Class Initialized
INFO - 2019-01-04 06:59:26 --> Language Class Initialized
INFO - 2019-01-04 06:59:26 --> Loader Class Initialized
INFO - 2019-01-04 06:59:26 --> Database Driver Class Initialized
INFO - 2019-01-04 06:59:26 --> Email Class Initialized
DEBUG - 2019-01-04 06:59:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-04 06:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-04 06:59:26 --> Controller Class Initialized
INFO - 2019-01-04 06:59:26 --> File loaded: /home/impetqry/public_html/schoolManagment/application/views/welcome_message.php
INFO - 2019-01-04 06:59:26 --> Final output sent to browser
DEBUG - 2019-01-04 06:59:26 --> Total execution time: 0.0203
ERROR - 2019-01-04 06:59:26 --> Severity: Core Warning --> APM cannot be enabled, '/var/php/apm/db' is not directory Unknown 0
INFO - 2019-01-04 06:59:37 --> Config Class Initialized
INFO - 2019-01-04 06:59:37 --> Hooks Class Initialized
DEBUG - 2019-01-04 06:59:37 --> UTF-8 Support Enabled
INFO - 2019-01-04 06:59:37 --> Utf8 Class Initialized
INFO - 2019-01-04 06:59:37 --> URI Class Initialized
DEBUG - 2019-01-04 06:59:37 --> No URI present. Default controller set.
INFO - 2019-01-04 06:59:37 --> Router Class Initialized
INFO - 2019-01-04 06:59:37 --> Output Class Initialized
INFO - 2019-01-04 06:59:37 --> Security Class Initialized
DEBUG - 2019-01-04 06:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-04 06:59:37 --> Input Class Initialized
INFO - 2019-01-04 06:59:37 --> Language Class Initialized
INFO - 2019-01-04 06:59:37 --> Loader Class Initialized
INFO - 2019-01-04 06:59:37 --> Database Driver Class Initialized
INFO - 2019-01-04 06:59:37 --> Email Class Initialized
DEBUG - 2019-01-04 06:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-04 06:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-04 06:59:37 --> Controller Class Initialized
INFO - 2019-01-04 06:59:37 --> File loaded: /home/impetqry/public_html/schoolManagment/application/views/welcome_message.php
INFO - 2019-01-04 06:59:37 --> Final output sent to browser
DEBUG - 2019-01-04 06:59:37 --> Total execution time: 0.0201
ERROR - 2019-01-04 06:59:37 --> Severity: Core Warning --> APM cannot be enabled, '/var/php/apm/db' is not directory Unknown 0
INFO - 2019-01-04 07:02:14 --> Config Class Initialized
INFO - 2019-01-04 07:02:14 --> Hooks Class Initialized
DEBUG - 2019-01-04 07:02:14 --> UTF-8 Support Enabled
INFO - 2019-01-04 07:02:14 --> Utf8 Class Initialized
INFO - 2019-01-04 07:02:14 --> URI Class Initialized
DEBUG - 2019-01-04 07:02:14 --> No URI present. Default controller set.
INFO - 2019-01-04 07:02:14 --> Router Class Initialized
INFO - 2019-01-04 07:02:14 --> Output Class Initialized
INFO - 2019-01-04 07:02:14 --> Security Class Initialized
DEBUG - 2019-01-04 07:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-04 07:02:14 --> Input Class Initialized
INFO - 2019-01-04 07:02:14 --> Language Class Initialized
INFO - 2019-01-04 07:02:14 --> Loader Class Initialized
INFO - 2019-01-04 07:02:14 --> Database Driver Class Initialized
INFO - 2019-01-04 07:02:14 --> Email Class Initialized
DEBUG - 2019-01-04 07:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-04 07:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-04 07:02:14 --> Controller Class Initialized
INFO - 2019-01-04 07:02:14 --> File loaded: /home/impetqry/public_html/schoolManagment/application/views/welcome_message.php
INFO - 2019-01-04 07:02:14 --> Final output sent to browser
DEBUG - 2019-01-04 07:02:14 --> Total execution time: 0.0258
ERROR - 2019-01-04 07:02:14 --> Severity: Core Warning --> APM cannot be enabled, '/var/php/apm/db' is not directory Unknown 0
INFO - 2019-01-04 07:05:33 --> Config Class Initialized
INFO - 2019-01-04 07:05:33 --> Hooks Class Initialized
DEBUG - 2019-01-04 07:05:33 --> UTF-8 Support Enabled
INFO - 2019-01-04 07:05:33 --> Utf8 Class Initialized
INFO - 2019-01-04 07:05:33 --> URI Class Initialized
DEBUG - 2019-01-04 07:05:33 --> No URI present. Default controller set.
INFO - 2019-01-04 07:05:33 --> Router Class Initialized
INFO - 2019-01-04 07:05:33 --> Output Class Initialized
INFO - 2019-01-04 07:05:33 --> Security Class Initialized
DEBUG - 2019-01-04 07:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-04 07:05:33 --> Input Class Initialized
INFO - 2019-01-04 07:05:33 --> Language Class Initialized
INFO - 2019-01-04 07:05:33 --> Loader Class Initialized
INFO - 2019-01-04 07:05:33 --> Database Driver Class Initialized
INFO - 2019-01-04 07:05:33 --> Email Class Initialized
DEBUG - 2019-01-04 07:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-01-04 07:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-01-04 07:05:33 --> Controller Class Initialized
INFO - 2019-01-04 07:05:33 --> File loaded: /home/impetqry/public_html/schoolManagment/application/views/welcome_message.php
INFO - 2019-01-04 07:05:33 --> Final output sent to browser
DEBUG - 2019-01-04 07:05:33 --> Total execution time: 0.0221
ERROR - 2019-01-04 07:05:33 --> Severity: Core Warning --> APM cannot be enabled, '/var/php/apm/db' is not directory Unknown 0
INFO - 2019-01-04 07:05:58 --> Config Class Initialized
INFO - 2019-01-04 07:05:58 --> Hooks Class Initialized
DEBUG - 2019-01-04 07:05:58 --> UTF-8 Support Enabled
INFO - 2019-01-04 07:05:58 --> Utf8 Class Initialized
INFO - 2019-01-04 07:05:58 --> URI Class Initialized
DEBUG - 2019-01-04 07:05:58 --> No URI present. Default controller set.
INFO - 2019-01-04 07:05:58 --> Router Class Initialized
INFO - 2019-01-04 07:05:58 --> Output Class Initialized
INFO - 2019-01-04 07:05:58 --> Security Class Initialized
DEBUG - 2019-01-04 07:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-01-04 07:05:58 --> Input Class Initialized
INFO - 2019-01-04 07:05:58 --> Language Class Initialized
INFO - 2019-01-04 07:05:58 --> Loader Class Initialized
INFO - 2019-01-04 07:05:58 --> Controller Class Initialized
INFO - 2019-01-04 07:05:58 --> File loaded: /home/impetqry/public_html/schoolManagment/application/views/welcome_message.php
INFO - 2019-01-04 07:05:58 --> Final output sent to browser
DEBUG - 2019-01-04 07:05:58 --> Total execution time: 0.0120

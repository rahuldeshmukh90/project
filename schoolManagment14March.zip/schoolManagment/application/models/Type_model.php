<?php

class Type_model extends CI_Model
{
    Protected $table;
    Protected $role;
    Protected $user;

	function __construct()
	{
       $this->table = "type";
       $this->role   = base64_decode($this->session->userdata('role'));		
       $this->user   = $this->session->userdata('id');		
	}

	function save ($type_data = array()){

       $Query = $this->db->insert($this->table, $type_data);
       if($this->db->affected_rows()>0){
          
            return true;
       }else{
            return false;     
       }
  }

  function getall(){

      
      if($this->role == 1 ){
        
        $Query = $this->db->get($this->table);    
      }
      
      if($this->role != 1 ){
        
        $Query = $this->db->get_where($this->table, array( 'role_id' => $this->role, 'user_id' => $this->user));  
      }
      
      if($Query->num_rows()>0) {
        
        return $Query->result();

      }else{

        return false;  
      }   
  }
  function getinfo($type_id){

      $Query = $this->db->get_where($this->table,array('id'=>$type_id));
      
      if($Query->num_rows()>0) {
        
        return $Query->result();

      }else{

        return false;  
      }   
  }

    

}
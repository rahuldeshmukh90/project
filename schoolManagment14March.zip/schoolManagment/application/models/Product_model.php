<?php

class Product_model extends CI_Model
{
    Protected $product_table;
    Protected $assign_product;
    Protected $role;
    Protected $user;

	function __construct()
	{
       $this->product_table  = "product";
       $this->assign_product = "assign_product";
       $this->role           = base64_decode($this->session->userdata('role'));		
       $this->user           = $this->session->userdata('id');		
	}

	function save ($product_data = array(),$id=false){
    if(!$id)
    {
       $Query = $this->db->insert($this->product_table, $product_data);
    }
    else
    {
        $this->db->where('id',$id);
        $Query = $this->db->update($this->product_table, $product_data);
    }
    if($this->db->affected_rows()>0){
        return true;
    }else{
        return false;     
    }
  }

    function getproductinfoByID( $product_id = ''){
        
    
    $Query = $this->db->get_where($this->product_table, array('id' => $product_id));
      
      if($Query->num_rows()>0) {
        
        return $Query->row();
    
      }else{
    
        return false;  
      }
      
  }
  
    function update_quantity($product_id ='', $assign_qnty = ''){
       
       $this->db->where('id', $product_id);       
       $Query = $this->db->update($this->product_table, array('remaining_qnty' => $assign_qnty ) );
       if($this->db->affected_rows()>0){
          
            return true;
       }else{
            return false;     
       }
       
  }  
    function save_assign_product( $assigndata=array(),  $assign_qnty='', $product_id='',$id=false){
       if(!$id)
       {
         $product   = $this->getproductinfoByID($product_id);
         $quantity  = $product->remaining_qnty;
         $available = $quantity-$assign_qnty; 
         $Query = $this->db->insert($this->assign_product, $assigndata );
          
       }
       else
       {
          $lastquantity=$this->get_assign_productinfo($id)->assign_qnty;
          $assign_qnty=$lastquantity-$assign_qnty;
          $available = $quantity-$assign_qnty; 
          $this->db->where('id',$id);
          $Query = $this->db->update($this->assign_product, $assigndata );
         
       }
       if($this->db->affected_rows()>0){
            
            if($this->update_quantity($product_id,$available)){
                
               return true;    
            }
            
       }else{
            return false;     
       }        
  }

  function get_assign_product_list()
  {
      if($this->role == 1 ){
        
        $Query = $this->db->get($this->assign_product);    
      }
      
      if($this->role != 1 ){
        
        $Query = $this->db->get_where($this->assign_product, array( 'role_id' => $this->role, 'user_id' => $this->user));  
      }
      
      if($Query->num_rows()>0) {
        
        return $Query->result();

      }else{

        return false;  
      }   
  }
  function get_assign_productinfo($id)
  {
      $Query = $this->db->get_where($this->assign_product, array('id' => $id));  
            
      if($Query->num_rows()>0) {
        
        return $Query->row();

      }else{

        return false;  
      }   
  }

    function getProduct(){

      if($this->role == 1 ){
        
        $Query = $this->db->get($this->product_table);    
      }
      
      if($this->role != 1 ){
        
        $Query = $this->db->get_where($this->product_table, array( 'role_id' => $this->role, 'user_id' => $this->user));  
      }
      
      if($Query->num_rows()>0) {
        
        return $Query->result();

      }else{

        return false;  
      }   
  }
  
  

    function count_product(){
      
      if($this->role == 1 ){
        
        $Query = $this->db->get($this->product_table);
      }
      
      if($this->role != 1 ){
        
        $Query = $this->db->get_where($this->product_table, array( 'role_id' => $this->role, 'user_id' => $this->user));  
      }
      
      if($Query->num_rows()>0) {
        
        return $Query->num_rows();

      }else{

        return false;  
      }
      
  }   
  function deleteproduct($id)
  {
      $this->db->where('id',$id);
      $this->db->delete($this->product_table);
      if($this->db->affected_rows()>0){
        return true;
      }else{
        return false;     
      }
  }
  function deletassignproduct($id)
  {
      $this->db->where('id',$id);
      $this->db->delete($this->assign_product);
      if($this->db->affected_rows()>0){
        return true;
      }else{
        return false;     
      }
  }   

}
<?php

class School_model extends CI_Model
{
    Protected $table;
    Protected $table_assign;
    Protected $role;
    Protected $user;
  

	function __construct()
	{
       $this->table        = "school";	
       $this->table_assign = "assign_school";  
       
       $this->role   = base64_decode($this->session->userdata('role'));		
       $this->user   = $this->session->userdata('id');		
       
	}

	function save ($data = array(),$id=false){
    if(!$id)
    {
       $Query = $this->db->insert($this->table, $data);
      
    }
    else
    {
      $this->db->where('id',$id);
      $this->db->update($this->table,$data);
    }
    if($this->db->affected_rows()>0){
      return true;
    }else{
      return false;     
    }
  }
  

  function getschool(){

      
      if($this->role == 1 ){
        
        $Query = $this->db->get($this->table);    
      }
      
      if($this->role != 1 ){
        
        $Query = $this->db->get_where($this->table, array( 'role_id' => $this->role, 'user_id' => $this->user));  
      }
      
      if($Query->num_rows()>0) {
        
        return $Query->result();

      }else{

        return false;  
      }   
  }
  
    function getschoolpersonaly($user_id='', $role_id=''){

      
      $Query = $this->db->get_where($this->table, array( 'role_id' => $role_id, 'user_id' => $user_id));  
      
      if($Query->num_rows()>0) {
        
        return $Query->result();

      }else{

        return false;  
      }   
  }

  function getinfo($school_id){

      $Query = $this->db->get_where($this->table,array('id'=>$school_id));
      
      if($Query->num_rows()>0) {
        
        return $Query->row();

      }else{

        return false;  
      }   
  }
  
  function count_school(){
      
      if($this->role == 1 ){
        
        $Query = $this->db->get($this->table);
      }
      
      if($this->role != 1 ){
        
        $Query = $this->db->get_where($this->table, array( 'role_id' => $this->role, 'user_id' => $this->user));  
      }
      
      if($Query->num_rows()>0) {
        
        return $Query->num_rows();

      }else{

        return false;  
      }
      
  }
  function checkemailunquie($data,$id)
  {
     $Query = $this->db->get_where($this->table, array('id !='=>$id,'email'=>$data['email']));
      
      if($Query->num_rows()>0) {
        
        return false;

      }else{

        return true;  
      }   
  }
  function deleteschool($id)
  {
      $this->db->where('id',$id);
      $this->db->delete($this->table);
      if($this->db->affected_rows()>0){
        return true;
      }else{
        return false;     
      }
  }
  
}
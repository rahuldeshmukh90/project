<?php

class Authentication extends CI_Model
{
    Protected $be_owner;
    Protected $city;
    Protected $state;
    Protected $country;

	function __construct()
	{
       $this->be_owner = "be_owner";		
       $this->city = "cities";        
       $this->state = "states";        
       $this->country = "countries";        
	}

	function login( $username='', $password='' ){
      
        $userData = array( 'username' => $username, 'password' => md5($password), 'active_status' => 1 );
        $Query    = $this->db->get_where($this->be_owner,$userData,1);  
        if($Query->num_rows()>0){
            
            $row     = $Query->row();
            $user_id =  $row->id;
            $role_id =  base64_encode($row->role_id);
            
            $this->session->set_userdata( array( 'id' => $user_id, 'role' => $role_id ) );
            return true;

        }else{
            
            return false;
        }
    }
    function get_login_id(){
        
        return $this->session->userdata('id');
    }
    function is_logged_in(){
        
        return $this->session->userdata('id') != false;
    }
    function get_city_info($city_id)
    {
        $Query = $this->db->get_where($this->city,array('id'=>$city_id));
      
        if($Query->num_rows()>0) {
            
            return $Query->row();

        }else{

            return false;  
        }   
    }
    function get_state_info($state_id)
    {
        $Query = $this->db->get_where($this->state,array('id'=>$state_id));
      
        if($Query->num_rows()>0) {
            
            return $Query->row();

        }else{

            return false;  
        }   
    }
    function get_country_info($country_id)
    {
        $Query = $this->db->get_where($this->country,array('id'=>$country_id));
      
        if($Query->num_rows()>0) {
            
            return $Query->row();

        }else{

            return false;  
        }   
    }
    function get_country()
    {
        $Query = $this->db->get($this->country);
      
        if($Query->num_rows()>0) {
            
            return $Query->result();

        }else{

            return false;  
        }   
    }
    function get_state($country_id=false)
    {
        if($country_id)
        {
            $this->db->where(array('country_id'=>$country_id));
        }
        $Query = $this->db->get($this->state);
      
        if($Query->num_rows()>0) {
            
            return $Query->result();

        }else{

            return false;  
        }   
    }
    function get_city($state_id=false)
    {
        if($state_id)
        {
            $this->db->where(array('state_id'=>$state_id));
        }
        $Query = $this->db->get($this->city);
      
        if($Query->num_rows()>0) {
            
            return $Query->result();

        }else{

            return false;  
        }   
    }

}
<?php

class Vendor_model extends CI_Model
{   
    Protected $table_assign;
    Protected $table;
    Protected $role;
    Protected $user;

	function __construct()
	{
       $this->table        = "vendor";	
       $this->table_assign = "assign_school";  
       $this->role   = base64_decode($this->session->userdata('role'));		
       $this->user   = $this->session->userdata('id');		
       
	}

	function save ($data = array(),$id=false){
    if(!$id)
    {
       $Query = $this->db->insert($this->table, $data);
      
    }
    else
    {
      $this->db->where('id',$id);
      $Query = $this->db->update($this->table, $data);
      
    }

       if($this->db->affected_rows()>0){
          
            return true;
       }else{
            return false;     
       }
  }

  function getvendor(){

      if($this->role == 1 ){
        
        $Query = $this->db->get($this->table);    
      }
      
      if($this->role != 1 ){
        
        $Query = $this->db->get_where($this->table, array( 'role_id' => $this->role, 'user_id' => $this->user));  
      }
      
      if($Query->num_rows()>0) {
        
        return $Query->result();

      }else{

        return false;  
      }   
  }
  
  function getsuperadminvendor($user_id='', $role_id=''){
      
      $Query = $this->db->get_where($this->table, array( 'role_id' => $role_id, 'user_id' => $user_id));  
      
      if($Query->num_rows()>0) {
        
        return $Query->result();

      }else{

        return false;  
      }
      
  }

  function getVenderinfo($vender_id){


      $Query = $this->db->get_where($this->table, array('id' => $vender_id));
      
      if($Query->num_rows()>0) {
        
        return $Query->row();

      }else{

        return false;  
      }   
  }
  
  function getAssigniBYID($vendor_id=''){
      
      $Query = $this->db->get_where($this->table, array('id' => $vendor_id));
      
      if($Query->num_rows()>0) {
        
        return $Query->row();

      }else{

        return false;  
      }
      
  }

  function checkemailunquie($data,$id)
  {
     $Query = $this->db->get_where($this->table, array('id !='=>$id,'email'=>$data['email']));
      
      if($Query->num_rows()>0) {
        
        return false;

      }else{

        return true;  
      }   
  }
  function deletevendor($id)
  {
      $this->db->where('id',$id);
      $this->db->delete($this->table);
      if($this->db->affected_rows()>0){
        return true;
      }else{
        return false;     
      }
  }
  function save_assign_school($data=array()){

    $Query = $this->db->insert($this->table_assign, $data); 
    if($this->db->affected_rows()>0){
    
      return true;
    }else{
    
      return false;     
    }

  }
  function getAssigni(){

      if($this->role == 1 ){
        
        $Query = $this->db->get($this->assign);    
      }
      
      if($this->role != 1 ){
        
        $Query = $this->db->get_where($this->table_assign, array( 'role_id' => $this->role, 'user_id' => $this->user));  
      }
      
      if($Query->num_rows()>0) {
        
        return $Query->result();

      }else{

        return false;  
      }   
  }

  function getSchoolAssigni(){

      if($this->role == 1 ){
        
        $Query = $this->db->get($this->table_assign);    
      }
      
      if($this->role != 1 ){
        
        $Query = $this->db->get_where($this->table_assign, array( 'role_id' => $this->role, 'user_id' => $this->user));  
      }
      
      if($Query->num_rows()>0) {
        
        return $Query->result();

      }else{

        return false;  
      }   
  } 

  function remove_assign($assigny_id=''){

      $Query = $this->db->delete($this->table_assign, array('id' => $assigny_id ));
      if($this->db->affected_rows()>0){
        
        return true;
        
      }else{

        return false;
      }
  } 


}

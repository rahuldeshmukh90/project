<?php

class user_model extends CI_Model
{
  Protected $table;
  Protected $group;

	function __construct()
	{
       $this->table = "be_owner";		
       $this->group = "be_group";
	}

	function save ($data = array(),$id=false){

    if(!$id)
    {
       $Query = $this->db->insert($this->table, $data);
    }
    else{
      
      $this->db->where('id',$id);
      $this->db->update($this->table,$data);
    }   
    if($this->db->affected_rows()>0){
      
        return true;
    }else{
        return false;     
    }
  }

  function getuser(){

      $Query = $this->db->get($this->table);
      
      if($Query->num_rows()>0) {
        
        return $Query->result();

      }else{

        return false;  
      }   
  }
  
  function getadminuser(){

      $Query = $this->db->get_where($this->table,array('role_id'=>'2'));
      
      if($Query->num_rows()>0) {
        
        return $Query->result();

      }else{

        return false;  
      }   
  }

  function getuserinfo($user_id){

      $Query = $this->db->get_where($this->table,array('id'=>$user_id));
      
      if($Query->num_rows()>0) {
        
        return $Query->row();

      }else{

        return false;  
      }   
  }
   

  function getgroup($group_id){
     
      $Query = $this->db->get_where($this->group,array('id'=>$group_id));
      
      if($Query->num_rows()>0) {
        
        return $Query->row();

      }else{

        return false;  
      }   
  } 
  
  function groups(){

      $Query = $this->db->get_where($this->group,array('status'=>'1'));
      
      if($Query->num_rows()>0) {
        
        return $Query->result();

      }else{

        return false;  
      }   
  } 
  
  function count_users(){
      
      $Query = $this->db->get_where($this->table, array('role_id !='=>'1'));
      
      if($Query->num_rows()>0) {
        
        return $Query->num_rows();

      }else{

        return false;  
      }
      
  }
  function checkuserunquie($data,$id)
  {
     $Query = $this->db->get_where($this->table, array('id !='=>$id,'username'=>$data['username']));
      
      if($Query->num_rows()>0) {
        
        return false;

      }else{

        return true;  
      }   
  }
  function oldpassword_check($data,$id)
  {
     $Query = $this->db->get_where($this->table, array('id'=>$id,'password'=>$data['password']));
      
      if($Query->num_rows()>0) {
        
        return true;

      }else{

        return false;  
      }   
  }
  
}
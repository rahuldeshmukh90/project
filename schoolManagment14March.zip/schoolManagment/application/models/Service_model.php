<?php

class Service_model extends CI_Model
{
    Protected $table;
    Protected $role;
    Protected $user;
    Protected $assign;

	function __construct()
	{
       $this->table  = "service";	
       $this->assign = "assign_service";	
       $this->role   = base64_decode($this->session->userdata('role'));		
       $this->user   = $this->session->userdata('id');		
       
	}

	function save ($data = array(),$id=false){
    if(!$id)
    {
      $Query = $this->db->insert($this->table, $data);
      
    }
    else
    {
        $this->db->where('id',$id);
        $Query = $this->db->update($this->table, $data);
      
    }

       if($this->db->affected_rows()>0){
          
            return true;
       }else{
            return false;     
       }
  }

  function getservice(){

      if($this->role == 1 ){
        
        $Query = $this->db->get($this->table);    
      }
      
      if($this->role != 1 ){
        
        $Query = $this->db->get_where($this->table, array( 'role_id' => $this->role, 'user_id' => $this->user));  
      }
      
      if($Query->num_rows()>0) {
        
        return $Query->result();

      }else{

        return false;  
      }   
  }

  function getserviceinfo($service_id){

      $Query = $this->db->get_where($this->table,array('id'=>$service_id));
      
      if($Query->num_rows()>0) {
        
        return $Query->row();

      }else{

        return false;  
      }   
  }
  
  function save_assign_vendor($data = array(),$id=false){
      
      if(!$id)
      {
        $Query = $this->db->insert($this->assign, $data);
        
      }
      else
      {
        $this->db->where('id',$id);
         $Query = $this->db->update($this->assign, $data);
       
      }
       if($this->db->affected_rows()>0){
          
            return true;
       }else{
            return false;     
       }
       
  }
  
  function getAssigni(){

      if($this->role == 1 ){
        
        $Query = $this->db->get($this->assign);    
      }
      
      if($this->role != 1 ){
        
        $Query = $this->db->get_where($this->assign, array( 'role_id' => $this->role, 'user_id' => $this->user));  
      }
      
      if($Query->num_rows()>0) {
        
        return $Query->result();

      }else{

        return false;  
      }   
  }
  function getAssign_info($id){

      
        $Query = $this->db->get_where($this->assign, array( 'id' => $id));  
      
      if($Query->num_rows()>0) {
        
        return $Query->row();

      }else{

        return false;  
      }   
  }
    function count_service(){
      
      if($this->role == 1 ){
        
        $Query = $this->db->get($this->table);
      }
      
      if($this->role != 1 ){
        
        $Query = $this->db->get_where($this->table, array( 'role_id' => $this->role, 'user_id' => $this->user));  
      }
      
      if($Query->num_rows()>0) {
        
        return $Query->num_rows();

      }else{

        return false;  
      }
      
  }
  
  function deleteassignservice($id)
  {
      $this->db->where('id',$id);
      $this->db->delete($this->assign);
      if($this->db->affected_rows()>0){
        return true;
      }else{
        return false;     
      }
  }
  function deleteservice($id)
  {
      $this->db->where('id',$id);
      $this->db->delete($this->table);
      if($this->db->affected_rows()>0){
        return true;
      }else{
        return false;     
      }
  }
  
  
}
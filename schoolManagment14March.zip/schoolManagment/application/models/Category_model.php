<?php

class Category_model extends CI_Model
{
    Protected $category_table;
    Protected $role;
    Protected $user;

	function __construct()
	{
       $this->category_table = "category";		
       $this->role           = base64_decode($this->session->userdata('role'));		
       $this->user           = $this->session->userdata('id');		
	}

	function save($category_data = array(),$id=false){
    if(!$id)
    {
       $Query = $this->db->insert($this->category_table, $category_data);
      
    }
    else
    {
      $this->db->where('id',$id);
      $Query = $this->db->update($this->category_table, $category_data);
      
    }
    
      if($this->db->affected_rows()>0){
          
            return true;
       }else{
            return false;     
       }
  }

  function getCategory(){

      $Query = $this->db->get_where($this->category_table, array( 'role_id' => $this->role, 'user_id' => $this->user));
      
      if($Query->num_rows()>0) {
        
        return $Query->result();

      }else{

        return false;  
      }   
  }

  function getInfo($id){

      $Query = $this->db->get_where($this->category_table, array( 'id' => $id));
      
      if($Query->num_rows()>0) {
        
        return $Query->row();

      }else{

        return false;  
      }   
  }
  function deletecategory($id)
  {
      $this->db->where('id',$id);
      $this->db->delete($this->category_table);
      if($this->db->affected_rows()>0){
        return true;
      }else{
        return false;     
      }
  }  

}
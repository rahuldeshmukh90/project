<!doctype html>
<html class="no-js" lang="en">
<?php $this->load->view('common/head'); ?>
<body>
    <?php $this->load->view('common/sidebar'); ?>
    <!-- Start Welcome area -->
    <div class="all-content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="logo-pro">
                        <a href="index.html"><img class="main-logo" src="<?php echo base_url(); ?>Assets/img/logo/logo.png" alt="" /></a>
                    </div>
                </div>
            </div>
        </div>
        <?php $this->load->view('common/header'); ?>
        <!-- Basic Form Start -->
        <div class="basic-form-area mg-tb-15">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="sparkline8-list mt-b-30">

                            <?php if(!empty($success)){ ?>

                            <div class="alert alert-dismissible alert-success">
                              <button type="button" class="close" data-dismiss="alert">&times;</button>
                              <a href="" class="alert-link"><?php echo $success; ?></a> 
                            </div>

                            <?php } ?>

                            <?php if(!empty($error)){ ?>
                            
                            <div class="alert alert-dismissible alert-danger">
                              <button type="button" class="close" data-dismiss="alert">&times;</button>
                              <a href="" class="alert-link"><?php echo $error; ?></a>
                            </div>  
                            
                            <?php } ?>

                            <div class="sparkline8-hd">
                                <div class="main-sparkline8-hd">
                                    <h1><?php echo $page_title; ?></h1>
                                </div>
                            </div>
                            <div class="sparkline8-graph">
                                <div class="basic-login-form-ad">
                                    <div class="row">
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            <div class="basic-login-inner">
                                                <!-- <h3>Sign In</h3> -->
                                                <p>Update All Information</p>
                                                <?php $attrib = array('id' => 'loginForm', "method" => "post"); echo form_open($url_second, $attrib); ?>
                                                    <div class="form-group-inner col-md-12 ">
                                                        <label> Select Vendor ( Assign to )</label>
                                                        <?php $vendor = $this->vendor_model->getsuperadminvendor(); ?>
                                                        <select name="vendor" id="vendor" class="form-control" >
                                                            <option value="">Select Vendor</option>
                                                            <?php $contact=''; foreach($vendor as $vendors ){ ?> 
                                                            <option value="<?php echo $vendors->id; ?>" data-contact="<?php echo $vendors->contact; ?>" <?php if($vendors->id == $vendorid ){ 
                                                                $contact=$vendors->contact;
                                                                echo "selected"; }?> ><?php echo $vendors->name; ?></option>
                                                            <?php } ?>
                                                        </select>
                                                        <?php echo form_error("vendor","<div class='error text-danger'>","</div>"); ?> 
                                                    </div>
                                                    
                                                    <div class="form-group-inner col-md-12 ">
                                                        <label>Vendor Contact</label>
                                                        <input type="contact" name="contact" id="contact" class="form-control"  value="<?php if(!empty($contact)){ echo $contact; }; ?>" placeholder="Vendor Mobile Number" readonly="readonly" />
                                                        <input type="hidden" name="form_text" id="contact" value="<?php echo $form_text; ?>" />
                                                        <?php echo form_error("cantact","<div class='error text-danger'>","</div>"); ?> 
                                                    </div>
                                                    
                                                    <div class="form-group-inner col-md-12 ">
                                                        <label> Service </label>
                                                        <input type="text" name="service" id="service" class="form-control"  value="<?php if(!empty($service)){ echo $service->name; }; ?>" placeholder="service" readonly="true" />
                                                        <?php echo form_error("service","<div class='error text-danger'>","</div>"); ?> 
                                                    </div>
                                                    
                                                    <div class="form-group-inner col-md-12 ">
                                                        <label>Service description</label>
                                                        <input type="text" name="description" id="description" class="form-control"  value="<?php if(!empty($service->description)){ echo $service->description; }; ?>" placeholder="Service Description" readonly="true" />
                                                        <?php echo form_error("description","<div class='error text-danger'>","</div>"); ?> 
                                                    </div>
                                                    
                                                    <div class="login-btn-inner">
                                                        <div class="inline-remember-me">
                                                            <button class="btn btn-sm btn-primary pull-right login-submit-cs" type="submit">Update</button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Basic Form End-->
        <!--<div class="footer-copyright-area">-->
        <!--    <div class="container-fluid">-->
        <!--        <div class="row">-->
        <!--            <div class="col-lg-12">-->
        <!--                <div class="footer-copy-right">-->
        <!--                    <p>Copyright © 2018 <a href="#">Colorlib</a> All rights reserved.</p>-->
        <!--                </div>-->
        <!--            </div>-->
        <!--        </div>-->
        <!--    </div>-->
        <!--</div>-->
    </div>

    <!-- jquery
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/vendor/jquery-1.11.3.min.js"></script>
    <!-- bootstrap JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/bootstrap.min.js"></script>
    <!-- wow JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/wow.min.js"></script>
    <!-- price-slider JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/jquery-price-slider.js"></script>
    <!-- meanmenu JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/jquery.meanmenu.js"></script>
    <!-- owl.carousel JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/owl.carousel.min.js"></script>
    <!-- sticky JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/jquery.sticky.js"></script>
    <!-- scrollUp JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/jquery.scrollUp.min.js"></script>
    <!-- mCustomScrollbar JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/scrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="<?php echo base_url(); ?>Assets/js/scrollbar/mCustomScrollbar-active.js"></script>
    <!-- metisMenu JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/metisMenu/metisMenu.min.js"></script>
    <script src="<?php echo base_url(); ?>Assets/js/metisMenu/metisMenu-active.js"></script>
    <!-- tab JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/tab.js"></script>
    <!-- icheck JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/icheck/icheck.min.js"></script>
    <script src="<?php echo base_url(); ?>Assets/js/icheck/icheck-active.js"></script>
    <!-- plugins JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/plugins.js"></script>
    <!-- main JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/main.js"></script>
    <script type="text/javascript">
        
        $("body").delegate("#vendor", "change", function(){
           contact=$("#vendor option:selected").data('contact');
           $("#contact").val(contact);
        });
    </script>
</body>

</html>
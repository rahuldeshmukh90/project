    <div class="left-sidebar-pro">
        <nav id="sidebar" class="">
            <div class="sidebar-header">
                <a href="<?php echo base_url(); ?>"><img class="main-logo" src="<?php echo base_url(); ?>Assets/img/logo/rsz_sv1.png" alt="" /></a>
                <strong><img src="<?php echo base_url(); ?>Assets/img/logo/logosn.png" alt="" /></strong>
            </div>
            <div class="left-custom-menu-adp-wrap comment-scrollbar">
                <nav class="sidebar-nav left-sidebar-menu-pro">
                    <ul class="metismenu" id="menu1">
                        <li class="active">
                            <a href="<?php echo site_url(); ?>"><i class="fa big-icon fa-dashboard icon-wrap"></i><span class="mini-click-non">Dashboard</span></a>
                        </li>
                        
                        <?php if( base64_decode($this->session->userdata('role')) == 1 ){ ?>
                        <li>
                            <a class="has-arrow" href="" aria-expanded="false"><i class="fa big-icon fa-user icon-wrap"></i> <span class="mini-click-non">Admin</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="User List" href="<?php echo base_url(); ?>users"><i class="fa fa-list sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">List</span></a></li>
                                <li><a title="Add Users" href="<?php echo base_url(); ?>add-users"><i class="fa fa-user-plus sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">Add</span></a></li>
                            </ul>
                        </li>
                        <?php } ?>

                        <?php if( base64_decode($this->session->userdata('role')) != 1 ){ ?>
                        <li>
                            <a class="has-arrow" href="" aria-expanded="false"><i class="fa big-icon fa-university icon-wrap"></i> <span class="mini-click-non">School</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="schools List" href="<?php echo base_url(); ?>schools"><i class="fa fa-list sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">List</span></a></li>
                                <li><a title="Add schools" href="<?php echo base_url(); ?>add-schools"><i class="fa fa-plus-square sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">Add</span></a></li>
                            </ul>
                        </li>
                        <?php } ?>

                        <?php if( base64_decode($this->session->userdata('role')) != 1 ){ ?>
                        <li>
                            <a class="has-arrow" href="" aria-expanded="false"><i class="fa big-icon fa-bullseye icon-wrap"></i> <span class="mini-click-non">Services</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="service List" href="<?php echo base_url(); ?>services"><i class="fa fa-list sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">List</span></a></li>
                                <li><a title="Add service" href="<?php echo base_url(); ?>add-services"><i class="fa fa-plus-square sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">Add</span></a></li>
                                <li><a title="Assigni List" href="<?php echo base_url(); ?>assign-service"><i class="fa fa-list sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">Assign Services</span></a></li>
                            </ul>
                        </li>
                        <?php } ?>

                        <?php if( base64_decode($this->session->userdata('role')) != 1 ){ ?>
                        <li>
                            <a class="has-arrow" href="" aria-expanded="false"><i class="fa big-icon fa-street-view icon-wrap"></i> <span class="mini-click-non">Vendor</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="Vendor List" href="<?php echo base_url(); ?>vendor"><i class="fa fa-list sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">List</span></a></li>
                                <li><a title="Add Vendor" href="<?php echo base_url(); ?>add-vendor"><i class="fa fa-plus-square sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">Add</span></a></li>
                            </ul>
                        </li>
                        <?php } ?>

                        <?php if( base64_decode($this->session->userdata('role')) != 1 ){ ?>
                        <li>
                            <a class="has-arrow" href="" aria-expanded="false"><i class="fa big-icon fa-flask icon-wrap"></i> <span class="mini-click-non">Category</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="Category List" href="<?php echo base_url(); ?>category"><i class="fa fa-list sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">List</span></a></li>
                                <li><a title="List Category List" href="<?php echo base_url(); ?>add-category"><i class="fa fa-plus-square sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">Add</span></a></li>
                            </ul>
                        </li>
                        <?php } ?>

                        <?php if( base64_decode($this->session->userdata('role')) != 1 ){ ?>
                        <li>
                            <a class="has-arrow" href="" aria-expanded="false"><i class="fa big-icon fa-pie-chart icon-wrap"></i> <span class="mini-click-non">Products</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="Product List" href="<?php echo base_url(); ?>product"><i class="fa fa-list sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">List</span></a></li>
                                <li><a title="" tle="Add Product" href="<?php echo base_url(); ?>add-product"><i class="fa fa-plus-square sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">Add</span></a></li>
                                 <li><a title="Assigni Product List" href="<?php echo base_url(); ?>assign-product_list"><i class="fa fa-list sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">Assign Products</span></a></li>
                            </ul>
                        </li>
                        <?php } ?>

                    </ul>
                </nav>
            </div>
        </nav>
    </div>
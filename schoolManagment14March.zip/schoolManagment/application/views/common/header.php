        <div class="header-advance-area">
            <div class="header-top-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <?php $this->load->view('common/header_top'); ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php $this->load->view('common/mobile_menu'); ?>
            <div class="breadcome-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="breadcome-list single-page-breadcome">
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                                        <!--<div class="breadcome-heading">-->
                                        <!--    <form role="search" class="">-->
                                        <!--        <input type="text" placeholder="Search..." class="form-control">-->
                                        <!--        <a href=""><i class="fa fa-search"></i></a>-->
                                        <!--    </form>-->
                                        <!--</div>-->
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                                        <ul class="breadcome-menu">
                                            
                                            <?php if(!empty($path_first)){ ?> 
                                                <li><a href="<?php echo base_url().$url_first; ?>"><span class="bread-blod"><?php echo $path_first; ?></span></a> <span class="bread-slash">/</span> 
                                                </li>
                                            <?php }?>

                                            <?php if(!empty($path_second)){ ?> 
                                                <li><a href="<?php echo base_url().$url_second; ?>"><span class="bread-blod"><?php echo $path_second; ?></span></a> 
                                                </li>
                                            <?php }?>

                                            <?php if(!empty($path_third)){ ?> 
                                                <li> <span class="bread-slash">/</span> <a href="<?php echo base_url().$url_third; ?>"><span class="bread-blod"><?php echo $path_third; ?></span></a>
                                                </li>
                                            <?php }?>
                                            
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
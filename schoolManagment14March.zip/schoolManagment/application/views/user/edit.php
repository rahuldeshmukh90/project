<!doctype html>
<html class="no-js" lang="en">
<?php $this->load->view('common/head'); ?>
<body>
    <?php $this->load->view('common/sidebar'); ?>
    <!-- Start Welcome area -->
    <div class="all-content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="logo-pro">
                        <a href="index.html"><img class="main-logo" src="<?php echo base_url(); ?>Assets/img/logo/logo.png" alt="" /></a>
                    </div>
                </div>
            </div>
        </div>
        <?php $this->load->view('common/header'); ?>
        <!-- Basic Form Start -->
        <div class="basic-form-area mg-tb-15">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="sparkline8-list mt-b-30">

                            <?php if(!empty($success)){ ?>

                            <div class="alert alert-dismissible alert-success">
                              <button type="button" class="close" data-dismiss="alert">&times;</button>
                              <strong>Success ! </strong> <a href="" class="alert-link"><?php echo $success; ?></a> 
                            </div>

                            <?php } ?>

                            <?php if(!empty($error)){ ?>
                            
                            <div class="alert alert-dismissible alert-danger">
                              <button type="button" class="close" data-dismiss="alert">&times;</button>
                              <strong>Faill ! </strong> <a href="" class="alert-link"><?php echo $error; ?></a>
                            </div>  
                            
                            <?php } ?>

                            <div class="sparkline8-hd">
                                <div class="main-sparkline8-hd">
                                    <h1><?php echo $page_title; ?></h1>
                                </div>
                            </div>
                            <div class="sparkline8-graph">
                                <div class="basic-login-form-ad">
                                    <div class="row">
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            <div class="basic-login-inner">
                                                <!-- <h3>Sign In</h3> -->
                                                <p>Update All Information of Admin</p>
                                                <?php $attrib = array('id' => 'pass_validation', "method" => "post"); echo form_open($url_second, $attrib); ?>
                                                    <div class="form-group-inner col-md-6 ">
                                                        <label>First Name</label>
                                                        <input type="text" name="fname" id="fname" class="form-control"  value="<?php if(!empty($fname)){ echo $fname; }; ?>" placeholder="user first Name" />
                                                        <?php echo form_error("fname","<div class='error text-danger'>","</div>"); ?> 
                                                    </div>

                                                    <div class="form-group-inner col-md-6">
                                                        <label>Last Name</label>
                                                        <input type="text" name="lname" id="lname" class="form-control"  value="<?php if(!empty($lname)){ echo $lname; }; ?>" placeholder="user last Name" />
                                                        <?php echo form_error("lname","<div class='error text-danger'>","</div>"); ?> 
                                                    </div>
                                                    <div class="form-group-inner col-md-6 ">
                                                        <label>Email ID</label>
                                                        <input type="email" name="email" id="email" class="form-control"  value="<?php if(!empty($email)){ echo $email; }; ?>" placeholder="user Email ID" />
                                                        <?php echo form_error("email","<div class='error text-danger'>","</div>"); ?> 
                                                    </div>

                                                    <div class="form-group-inner col-md-6">
                                                        <label>Contact Number</label>
                                                        <input type="text" name="contact" id="contact" class="form-control" value="<?php if(!empty($contact)){ echo $contact; }; ?>" placeholder="Contact" />
                                                        <?php echo form_error("contact","<div class='error text-danger'>","</div>"); ?> 
                                                    </div>

                                                    <div class="form-group-inner col-md-6">
                                                        <label>Role</label>
                                                        <select class="form-control" name="user_type">
                                                            <option value="2"> Admin </option>
                                                            
                                                        </select>
                                                    </div>
                                                    
                                                    <div class="form-group-inner col-md-6">
                                                        <label>Username</label>
                                                        <input type="text" name="username" id="username" class="form-control" value="<?php if(!empty($username)){ echo $username; }; ?>" placeholder="Username" />
                                                        <?php echo form_error("username","<div class='error text-danger'>","</div>"); ?> 
                                                    </div>
                                                    
                                                    <div class="form-group-inner col-md-6">
                                                        <label>Company</label>
                                                        <input type="text" name="company" id="company" class="form-control" value="<?php if(!empty($company)){ echo $company; }; ?>" placeholder="Comapny" />
                                                        <?php echo form_error("company","<div class='error text-danger'>","</div>"); ?> 
                                                    </div>

                                                    <div class="form-group-inner col-md-12">
                                                        <label>Address</label>
                                                        <textarea name="address" id="address" placeholder="Enter Address Here..." class="form-control"> <?php if(!empty($address)){ echo $address; }; ?> </textarea>
                                                        <?php echo form_error("address","<div class='error text-danger'>","</div>"); ?> 
                                                    </div>
                                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                    
                                                    <fieldset>
                                                    <br>
                                                    <h4>Change Password : </h4><br>   
                                                    <!-- <div class="form-group-inner col-md-6">
                                                        <label>Old Password</label>
                                                        <input type="password" name="opass" id="opass" class="form-control" placeholder="Your old password" />
                                                        <?php echo form_error("opass","<div class='error text-danger'>","</div>"); ?> 
                                                    </div> -->

                                                    <div class="form-group-inner col-md-6">
                                                        <label>New Password</label>
                                                        <input type="password" name="pass" id="pass" class="form-control" placeholder="Enter your new password" />
                                                        <?php echo form_error("username","<div class='error text-danger'>","</div>"); ?> 
                                                    </div>

                                                    <div class="form-group-inner col-md-6">
                                                        <label>Confirm Password</label>
                                                        <input type="password" name="cpass" id="cpass" class="form-control"  placeholder="Confirm Password" />
                                                        <?php echo form_error("cpass","<div class='error text-danger'>","</div>"); ?> 
                                                    </div>
                                                    <br>

                                                    </fieldset>
                                                    <input type="checkbox" onclick="showPass()"> Show Password   
                                                    </div>
                                                    
                                                    
                                                    <div class="login-btn-inner">
                                                        <div class="inline-remember-me">
                                                            <button class="btn btn-sm btn-primary pull-right login-submit-cs" type="submit">Update</button>
                                                        </div>
                                                    </div>
                                                    
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Basic Form End-->
        <!--<div class="footer-copyright-area">-->
        <!--    <div class="container-fluid">-->
        <!--        <div class="row">-->
        <!--            <div class="col-lg-12">-->
        <!--                <div class="footer-copy-right">-->
        <!--                    <p>Copyright © 2018 <a href="https://colorlib.com/wp/templates/">Colorlib</a> All rights reserved.</p>-->
        <!--                </div>-->
        <!--            </div>-->
        <!--        </div>-->
        <!--    </div>-->
        <!--</div>-->
    </div>

    <!-- jquery
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/vendor/jquery-1.11.3.min.js"></script>
    <!-- bootstrap JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/bootstrap.min.js"></script>
    <!-- wow JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/wow.min.js"></script>
    <!-- price-slider JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/jquery-price-slider.js"></script>
    <!-- meanmenu JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/jquery.meanmenu.js"></script>
    <!-- owl.carousel JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/owl.carousel.min.js"></script>
    <!-- sticky JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/jquery.sticky.js"></script>
    <!-- scrollUp JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/jquery.scrollUp.min.js"></script>
    <!-- mCustomScrollbar JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/scrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="<?php echo base_url(); ?>Assets/js/scrollbar/mCustomScrollbar-active.js"></script>
    <!-- metisMenu JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/metisMenu/metisMenu.min.js"></script>
    <script src="<?php echo base_url(); ?>Assets/js/metisMenu/metisMenu-active.js"></script>
    <!-- tab JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/tab.js"></script>
    <!-- icheck JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/icheck/icheck.min.js"></script>
    <script src="<?php echo base_url(); ?>Assets/js/icheck/icheck-active.js"></script>
    <!-- plugins JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/plugins.js"></script>
    <!-- main JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/main.js"></script>

    <!-- Form Validation
		============================================ -->
	
	<script>
	function showPass() {

	  var x = document.getElementById("opass");
	  var y = document.getElementById("pass");
	  var z = document.getElementById("cpass");
	  if (x.type === "password" || y.type === "password" || z.type === "password") {
	    
	    x.type = "text";
	    y.type = "text";
	    z.type = "text";

	  } else {

	    x.type = "password";
	    y.type = "password";
	    z.type = "password";
	  }

	}

	</script>

	<script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>
    <script type="text/javascript">
	
		$('#3pass_validation').validate({
	        
	        rules :{ opass:{ required : true } },
	        messages : { opass : { required: "required" } }

		});

	</script>	

</body>

</html>
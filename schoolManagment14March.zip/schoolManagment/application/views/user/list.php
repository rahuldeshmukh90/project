<!doctype html>
<html class="no-js" lang="en">
<?php $this->load->view('common/head'); ?>
<body>
    <?php $this->load->view('common/sidebar'); ?>
    <!-- Start Welcome area -->
    <div class="all-content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="logo-pro">
                        <a href=""><img class="main-logo" src="<?php echo base_url(); ?>Assets/img/logo/logo.png" alt="" /></a>
                    </div>
                </div>
            </div>
        </div>
        <?php $this->load->view('common/header'); ?>
        <!-- Static Table Start -->
        <div class="data-table-area mg-tb-15">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="sparkline13-list">
                            
                            <?php if(!empty($success)){ ?>

                            <div class="alert alert-dismissible alert-success">
                              <button type="button" class="close" data-dismiss="alert">&times;</button>
                              <a href="" class="alert-link"><?php echo $success; ?></a> 
                            </div>

                            <?php } ?>

                            <?php if(!empty($error)){ ?>
                            
                            <div class="alert alert-dismissible alert-danger">
                              <button type="button" class="close" data-dismiss="alert">&times;</button>
                              <a href="" class="alert-link"><?php echo $error; ?></a>
                            </div>  
                            
                            <?php } ?>
                            
                            <div class="sparkline13-hd">
                                <div class="main-sparkline13-hd">
                                    <h1>Admin <span class="table-project-n"></span> List</h1>
                                </div>
                            </div>
                            <div class="sparkline13-graph">
                                <div class="datatable-dashv1-list custom-datatable-overright">
                                    
                                    <table id="table" data-toggle="table" data-pagination="true" data-search="true" data-show-columns="true" data-show-pagination-switch="true" data-show-refresh="true" data-key-events="true" data-show-toggle="true" data-resizable="true" data-cookie="true"
                                        data-cookie-id-table="saveId" data-show-export="true" data-click-to-select="true" data-toolbar="#toolbar">
                                        <thead>
                                            <tr>
                                                <th data-field="id">SN</th>
                                                <th data-field="name" >CEO Name</th>
                                                <th data-field="company" >Company Name</th>
                                                <th data-field="email" >Email</th>
                                                <th data-field="date" >User type</th>
                                                <th data-field="action">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php if(!empty($user)){ ?>
                                        <?php $i = 1; foreach($user as $users ){ ?>
                                            <tr>
                                                <td><?php echo $i++; ?></td>
                                                <td><?php echo $users->fname.' '.$users->lname; ?></td>
                                                <td><?php echo $users->company; ?></td>
                                                <td><?php echo $users->email; ?></td>
                                                <td><?php $data=$this->user_model->getgroup($users->group_id); echo $data->description; ?></td>
                                                <td>
                                                    <?php if($users->active_status==1): ?>
                                                    <a href="javascript:void(0);" class="blockuser" data-userid="<?php echo $users->id; ?>" title="Block Admin"><i class="fa fa-user"></i></a>
                                                    <?php else: ?>

                                                    <a href="javascript:void(0);" class="activeuser" data-userid="<?php echo $users->id; ?>" title="Active Admin"><i class="fa fa-user-times"></i></a>
                                                <?php endif; ?>
                                                    &nbsp;&nbsp;

                                                    <a href="<?php echo base_url(); ?>update-users/<?php echo $users->id; ?>" title="Edit Admin"><i class="fa fa-edit"></i></a></td>
                                                
                                            </tr>
                                        <?php } ?>
                                        <?php } ?>    
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Static Table End -->
        <!--<div class="footer-copyright-area">-->
        <!--    <div class="container-fluid">-->
        <!--        <div class="row">-->
        <!--            <div class="col-lg-12">-->
        <!--                <div class="footer-copy-right">-->
        <!--                    <p>Copyright © 2018 <a href="https://colorlib.com/wp/templates/">Colorlib</a> All rights reserved.</p>-->
        <!--                </div>-->
        <!--            </div>-->
        <!--        </div>-->
        <!--    </div>-->
        <!--</div>-->
    </div>

    <!-- jquery
        ============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/vendor/jquery-1.11.3.min.js"></script>
    <!-- bootstrap JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/bootstrap.min.js"></script>
    <!-- wow JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/wow.min.js"></script>
    <!-- price-slider JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/jquery-price-slider.js"></script>
    <!-- meanmenu JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/jquery.meanmenu.js"></script>
    <!-- owl.carousel JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/owl.carousel.min.js"></script>
    <!-- sticky JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/jquery.sticky.js"></script>
    <!-- scrollUp JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/jquery.scrollUp.min.js"></script>
    <!-- mCustomScrollbar JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/scrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="<?php echo base_url(); ?>Assets/js/scrollbar/mCustomScrollbar-active.js"></script>
    <!-- metisMenu JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/metisMenu/metisMenu.min.js"></script>
    <script src="<?php echo base_url(); ?>Assets/js/metisMenu/metisMenu-active.js"></script>
    <!-- data table JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/data-table/bootstrap-table.js"></script>
    <script src="<?php echo base_url(); ?>Assets/js/data-table/tableExport.js"></script>
    <script src="<?php echo base_url(); ?>Assets/js/data-table/data-table-active.js"></script>
    <script src="<?php echo base_url(); ?>Assets/js/data-table/bootstrap-table-editable.js"></script>
    <script src="<?php echo base_url(); ?>Assets/js/data-table/bootstrap-editable.js"></script>
    <script src="<?php echo base_url(); ?>Assets/js/data-table/bootstrap-table-resizable.js"></script>
    <script src="<?php echo base_url(); ?>Assets/js/data-table/colResizable-1.5.source.js"></script>
    <script src="<?php echo base_url(); ?>Assets/js/data-table/bootstrap-table-export.js"></script>
    <!--  editable JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/editable/jquery.mockjax.js"></script>
    <script src="<?php echo base_url(); ?>Assets/js/editable/mock-active.js"></script>
    <script src="<?php echo base_url(); ?>Assets/js/editable/select2.js"></script>
    <script src="<?php echo base_url(); ?>Assets/js/editable/moment.min.js"></script>
    <script src="<?php echo base_url(); ?>Assets/js/editable/bootstrap-datetimepicker.js"></script>
    <script src="<?php echo base_url(); ?>Assets/js/editable/bootstrap-editable.js"></script>
    <script src="<?php echo base_url(); ?>Assets/js/editable/xediable-active.js"></script>
    <!-- Chart JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/chart/jquery.peity.min.js"></script>
    <script src="<?php echo base_url(); ?>Assets/js/peity/peity-active.js"></script>
    <!-- tab JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/tab.js"></script>
    <!-- plugins JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/plugins.js"></script>
    <!-- main JS
        ============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/main.js"></script>
    <script type="text/javascript">
        $("body").delegate(".blockuser", "click", function(){
           id=$(this).data('userid');
           btn=$(this);
           $.ajax({
            url:"<?php echo base_url(); ?>users/blockuser/"+id,
            
            success:function(data){
                if(data!='')
                {
                   // alert();
                    btn.removeClass('blockuser').addClass('activeuser').html('<i class="fa fa-user-times"></i>');
                }
            }
           });
        });
        $("body").delegate(".activeuser", "click", function(){
           id=$(this).data('userid');
           btn=$(this);
           $.ajax({
            url:"<?php echo base_url(); ?>users/activeuser/"+id,
            
            success:function(data){
                if(data!='')
                {
                    btn.removeClass('activeuser').addClass('blockuser').html('<i class="fa fa-user"></i>');
                }
            }
           });
        });
    </script>
</body>

</html>
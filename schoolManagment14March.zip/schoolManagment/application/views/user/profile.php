<!doctype html>
<html class="no-js" lang="en">
<?php $this->load->view('common/head'); ?>
<body>
    <?php $this->load->view('common/sidebar'); ?>
    <!-- Start Welcome area -->
    <div class="all-content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="logo-pro">
                        <a href="<?php echo base_url(); ?>"><img class="main-logo" src="<?php echo base_url(); ?>Assets/img/logo/rsz_sv1.png" alt="" /></a>
                    </div>
                </div>
            </div>
        </div>
        <?php $this->load->view('common/header'); ?>
        <!-- Basic Form Start -->
        <div class="basic-form-area mg-tb-15">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="sparkline8-list mt-b-30">

                            <?php if(!empty($success)){ ?>

                            <div class="alert alert-dismissible alert-success">
                              <button type="button" class="close" data-dismiss="alert">&times;</button>
                              <strong>Success ! </strong> <a href="" class="alert-link"><?php echo $success; ?></a> 
                            </div>

                            <?php } ?>

                            <?php if(!empty($error)){ ?>
                            
                            <div class="alert alert-dismissible alert-danger">
                              <button type="button" class="close" data-dismiss="alert">&times;</button>
                              <strong>Faill ! </strong> <a href="" class="alert-link"><?php echo $error; ?></a>
                            </div>  
                            
                            <?php } ?>

                            <div class="sparkline8-hd">
                                <div class="main-sparkline8-hd">
                                    <h1 align="center" ><?php echo strtoupper($page_title); ?></h1>
                                </div>
                            </div>
                            <div class="sparkline8-graph">
                                <div class="basic-login-form-ad">
                                    <div class="row">
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            <div class="basic-login-inner" style="max-width: 700px;margin: auto;background-color: rgb(242, 242, 242);padding: 40px;">
                                                <br><br>
                                                <table class="table">
                                                    <tr>
                                                        <td>Role </td><td> : <?php if($user->role_id == 1 ){ echo "Superadmin"; }; ?><?php if($user->role_id == 2 ){ echo "Admin"; }; ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Comapny Name </td><td> : <?php echo $user->company; ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>CEO Name </td><td>: <?php echo $user->fname." ".$user->lname; ?> </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Username </td><td>: <?php echo $user->username; ?> </td>
                                                    </tr>
                                                    <tr>
                                                        <td>E-MAIL </td><td>: <?php echo $user->email; ?> </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Contact Number </td><td>: <?php echo $user->contact; ?> </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Address </td><td>: <?php echo $user->address; ?></td>
                                                    </tr>

                                                    <tr>
                                                        <td>Register Date</td><td>: <?php echo $user->created_date; ?></td>
                                                    </tr> 

                                                </table>

                                                <!-- <?php $attrib = array('id' => 'loginForm', "method" => "post"); echo form_open($url_second, $attrib); ?>
                                                    <div class="form-group-inner col-md-6 ">
                                                        <label>First Name</label>
                                                        <input type="text" name="fname" id="fname" class="form-control"  value="<?php if(!empty($fname)){ echo $fname; }; ?>" placeholder="user first Name" />
                                                        <?php echo form_error("fname","<div class='error text-danger'>","</div>"); ?> 
                                                    </div>

                                                    <div class="form-group-inner col-md-6">
                                                        <label>Last Name</label>
                                                        <input type="text" name="lname" id="lname" class="form-control"  value="<?php if(!empty($lname)){ echo $lname; }; ?>" placeholder="user last Name" />
                                                        <?php echo form_error("lname","<div class='error text-danger'>","</div>"); ?> 
                                                    </div>
                                                    <div class="form-group-inner col-md-6 ">
                                                        <label>Email ID</label>
                                                        <input type="email" name="email" id="email" class="form-control"  value="<?php if(!empty($email)){ echo $email; }; ?>" placeholder="user Email ID" />
                                                        <?php echo form_error("email","<div class='error text-danger'>","</div>"); ?> 
                                                    </div>

                                                    <div class="form-group-inner col-md-6">
                                                        <label>Contact Number</label>
                                                        <input type="text" name="contact" id="contact" class="form-control" value="<?php if(!empty($contact)){ echo $contact; }; ?>" placeholder="Contact" />
                                                        <?php echo form_error("contact","<div class='error text-danger'>","</div>"); ?> 
                                                    </div>

                                                    
                                                    <div class="login-btn-inner">
                                                        <div class="inline-remember-me">
                                                            <button class="btn btn-sm btn-primary pull-right login-submit-cs" type="submit">Update</button>
                                                            
                                                        </div>
                                                    </div>
                                                </form> -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Basic Form End-->
        <!--<div class="footer-copyright-area">-->
        <!--    <div class="container-fluid">-->
        <!--        <div class="row">-->
        <!--            <div class="col-lg-12">-->
        <!--                <div class="footer-copy-right">-->
        <!--                    <p>Copyright © 2018 <a href="https://colorlib.com/wp/templates/">Colorlib</a> All rights reserved.</p>-->
        <!--                </div>-->
        <!--            </div>-->
        <!--        </div>-->
        <!--    </div>-->
        <!--</div>-->
    </div>

    <!-- jquery
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/vendor/jquery-1.11.3.min.js"></script>
    <!-- bootstrap JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/bootstrap.min.js"></script>
    <!-- wow JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/wow.min.js"></script>
    <!-- price-slider JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/jquery-price-slider.js"></script>
    <!-- meanmenu JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/jquery.meanmenu.js"></script>
    <!-- owl.carousel JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/owl.carousel.min.js"></script>
    <!-- sticky JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/jquery.sticky.js"></script>
    <!-- scrollUp JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/jquery.scrollUp.min.js"></script>
    <!-- mCustomScrollbar JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/scrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="<?php echo base_url(); ?>Assets/js/scrollbar/mCustomScrollbar-active.js"></script>
    <!-- metisMenu JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/metisMenu/metisMenu.min.js"></script>
    <script src="<?php echo base_url(); ?>Assets/js/metisMenu/metisMenu-active.js"></script>
    <!-- tab JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/tab.js"></script>
    <!-- icheck JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/icheck/icheck.min.js"></script>
    <script src="<?php echo base_url(); ?>Assets/js/icheck/icheck-active.js"></script>
    <!-- plugins JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/plugins.js"></script>
    <!-- main JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/main.js"></script>
</body>

</html>
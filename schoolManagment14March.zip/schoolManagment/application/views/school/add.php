<!doctype html>
<html class="no-js" lang="en">
<?php $this->load->view('common/head'); ?>
<body>
    <?php $this->load->view('common/sidebar'); ?>
    <!-- Start Welcome area -->
    <div class="all-content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="logo-pro">
                        <a href="index.html"><img class="main-logo" src="<?php echo base_url(); ?>Assets/img/logo/logo.png" alt="" /></a>
                    </div>
                </div>
            </div>
        </div>
        <?php $this->load->view('common/header'); ?>
        <!-- Basic Form Start -->
        <div class="basic-form-area mg-tb-15">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="sparkline8-list mt-b-30">

                            <?php if(!empty($success)){ ?>

                            <div class="alert alert-dismissible alert-success">
                              <button type="button" class="close" data-dismiss="alert">&times;</button>
                              <strong>Success ! </strong> <a href="" class="alert-link"><?php echo $success; ?></a> 
                            </div>

                            <?php } ?>

                            <?php if(!empty($error)){ ?>
                            
                            <div class="alert alert-dismissible alert-danger">
                              <button type="button" class="close" data-dismiss="alert">&times;</button>
                              <strong>Faill ! </strong> <a href="" class="alert-link"><?php echo $error; ?></a>
                            </div>  
                            
                            <?php } ?>

                            <div class="sparkline8-hd">
                                <div class="main-sparkline8-hd">
                                    <h1><?php echo $page_title; ?></h1>
                                </div>
                            </div>
                            <div class="sparkline8-graph">
                                <div class="basic-login-form-ad">
                                    <div class="row">
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            <div class="basic-login-inner">
                                                <!-- <h3>Sign In</h3> -->
                                                <p>Add All Information of School </p>
                                                <?php $attrib = array('id' => 'loginForm', "method" => "post"); echo form_open($url_second, $attrib); ?>
                                                    <div class="form-group-inner col-md-6 ">
                                                        <label>
                                                        Name</label>
                                                        <input type="text" name="name" id="name" class="form-control" value="<?php if(!empty($name)){ echo $name; }?>" placeholder="Name" />
                                                        <?php echo form_error("name","<div class='error text-danger'>","</div>"); ?> 
                                                    </div>

                                                    <div class="form-group-inner col-md-6">
                                                        <label>email</label>
                                                        <input type="email" name="email" id="email" class="form-control" value="<?php if(!empty($email)){ echo $email; }?>" placeholder="email ID" />
                                                        <?php echo form_error("email","<div class='error text-danger'>","</div>"); ?> 
                                                    </div>
                                                    <div class="form-group-inner col-md-6 ">
                                                        <label>Contact No</label>
                                                        <input type="text" name="contact" id="contact" class="form-control" value="<?php if(!empty($contact)){ echo $contact; }?>" placeholder="Contact" />
                                                        <?php echo form_error("contact","<div class='error text-danger'>","</div>"); ?> 
                                                    </div>
                                                    
                                                    <div class="form-group-inner col-md-6">
                                                        <label>Principal</label>
                                                        <input type="text" name="principal" id="principal" class="form-control" value="<?php if(!empty($principal)){ echo $principal; }?>" placeholder="Principal" />
                                                        <?php echo form_error("principal","<div class='error text-danger'>","</div>"); ?> 
                                                    </div>
                                                    
                                                    <div class="form-group-inner col-md-12">
                                                        <label>Address</label>
                                                        <textarea name="address" id="address" class="form-control"  placeholder="Address" > <?php if(!empty($address)){ echo $address; }?> </textarea>
                                                        <?php echo form_error("address","<div class='error text-danger'>","</div>"); ?> 
                                                    </div>

                                                    <div class="form-group-inner col-md-6">
                                                        <label>country</label>
                                                        <select class="form-control" name="country" id="country">
                                                            <option value="">Country</option>
                                                        <?php $countrys=$this->authentication->get_country();
                                                          
                                                            foreach($countrys as $cu){ ?>
                                                                <option value="<?php echo $cu->id; ?>" <?php if($cu->id == $country ){ echo "selected"; }?> ><?php echo $cu->name; ?></option>
                                                            <?php } ?>
                                                        </select>
                                                        <?php echo form_error("country","<div class='error text-danger'>","</div>"); ?> 
                                                    </div>

                                                    <div class="form-group-inner col-md-6">
                                                        <label>State</label>
                                                        <select id='state' class="form-control" name="state">
                                                           <option value="">State</option>
                                                           <?php if(!empty($state)){?>
                                                            <?php $states=$this->authentication->get_state($country);
                                                          
                                                            foreach($states as $st){ ?>
                                                                <option value="<?php echo $st->id; ?>" <?php if($st->id == $state ){ echo "selected"; }?> ><?php echo $st->name; ?></option>
                                                            <?php } ?>
                                                           <?php } ?>
                                                        </select>
                                                        <?php echo form_error("state","<div class='error text-danger'>","</div>"); ?> 
                                                    </div>

                                                    <div class="form-group-inner col-md-6">
                                                        <label>City</label>
                                                        <select id='city' class="form-control" name="city">
                                                            <option value="">City</option> 
                                                            <?php if(!empty($city)){?>
                                                            <?php $citys=$this->authentication->get_city($state);
                                                          
                                                            foreach($citys as $ct){ ?>
                                                                <option value="<?php echo $ct->id; ?>" <?php if($ct->id == $city ){ echo "selected"; }?> ><?php echo $ct->name; ?></option>
                                                            <?php } ?>
                                                           <?php } ?>
                                                        </select>
                                                        <?php echo form_error("city","<div class='error text-danger'>","</div>"); ?> 
                                                    </div>
                                                    
                                                    <div class="form-group-inner col-md-6">
                                                        <label>Manager</label>
                                                        <input type="text" name="manager" id="manager" class="form-control" value="<?php if(!empty($manager)){ echo $manager; }?>" placeholder="Manager" />
                                                        <?php echo form_error("manager","<div class='error text-danger'>","</div>"); ?> 
                                                    </div>
                                                    <div class="login-btn-inner">
                                                        <div class="inline-remember-me">
                                                            <button class="btn btn-sm btn-primary pull-right login-submit-cs" type="submit">Add</button>
                                                            
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Basic Form End-->
        <!--<div class="footer-copyright-area">-->
        <!--    <div class="container-fluid">-->
        <!--        <div class="row">-->
        <!--            <div class="col-lg-12">-->
        <!--                <div class="footer-copy-right">-->
        <!--                    <p>Copyright © 2018 <a href="https://colorlib.com/wp/templates/">Colorlib</a> All rights reserved.</p>-->
        <!--                </div>-->
        <!--            </div>-->
        <!--        </div>-->
        <!--    </div>-->
        <!--</div>-->
    </div>

    <!-- jquery
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/vendor/jquery-1.11.3.min.js"></script>
    <!-- bootstrap JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/bootstrap.min.js"></script>
    <!-- wow JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/wow.min.js"></script>
    <!-- price-slider JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/jquery-price-slider.js"></script>
    <!-- meanmenu JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/jquery.meanmenu.js"></script>
    <!-- owl.carousel JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/owl.carousel.min.js"></script>
    <!-- sticky JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/jquery.sticky.js"></script>
    <!-- scrollUp JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/jquery.scrollUp.min.js"></script>
    <!-- mCustomScrollbar JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/scrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="<?php echo base_url(); ?>Assets/js/scrollbar/mCustomScrollbar-active.js"></script>
    <!-- metisMenu JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/metisMenu/metisMenu.min.js"></script>
    <script src="<?php echo base_url(); ?>Assets/js/metisMenu/metisMenu-active.js"></script>
    <!-- tab JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/tab.js"></script>
    <!-- icheck JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/icheck/icheck.min.js"></script>
    <script src="<?php echo base_url(); ?>Assets/js/icheck/icheck-active.js"></script>
    <!-- plugins JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/plugins.js"></script>
    <!-- main JS
		============================================ -->
    <script src="<?php echo base_url(); ?>Assets/js/main.js"></script>
    <!---Validatejs
        =================================================== -->
       
    <script type="text/javascript">
        $(document).delegate('#country','change',function(){
            id=$(this).val();
            html='<option value="">State</option>';
            $.ajax({

                url: '<?php echo site_url('home/states');?>/'+id,
                method:'GET',
                success:function(msg){
                    if(msg!=0)
                    {
                       var abc=JSON.parse(msg);           
                           
                       for(var i=0;i<abc.length;i++)
                       {            
                         html+="<option value='"+abc[i]['id']+"' >"+abc[i]['name']+"</option>";        
                       }
                    }
                    $("#state").html(html);
                }
            });
        });
         $(document).delegate('#state','change',function(){
            id=$(this).val();
            html='<option value="">City</option>';
            $.ajax({

                url: '<?php echo site_url('home/city');?>/'+id,
                method:'GET',
                success:function(msg){
                    if(msg!=0)
                    {
                       var abc=JSON.parse(msg);           
                           
                       for(var i=0;i<abc.length;i++)
                       {            
                         html+="<option value='"+abc[i]['id']+"'>"+abc[i]['name']+"</option>";        
                       }
                    }
                    $("#city").html(html);
                }
            });
        });

    </script>
</body>

</html>
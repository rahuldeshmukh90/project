<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once ('Auth_access.php');

class Product extends Auth_access {


	public function index(){
        
        if (!$this->authentication->is_logged_in()){
		 
		   redirect('login');
		   exit();
        
        }else{
           
           $data['success'] = $this->session->userdata('success');    
           $data['error']   = $this->session->userdata('error');

           $data['product']    = $this->product_model->getProduct();   

           $data['path_first']  = "Home";
           $data['path_second'] = "Product";
          
           $data['url_first']   = "home";
           $data['url_second']  = "Product";

           $data['page_title']  = "Product";
           
           $this->load->view('product/list', $data);	  

        }

	}

	public function defualt_date_time(){
        
        date_default_timezone_set('Asia/Kolkata');
        return date('Y-m-d H:i:a');
    }
  public function deleteproduct($id){
    if($id)
    {
        if($this->product_model->deleteproduct($id))
        {
          $this->session->set_flashdata('success', 'Product Successfully deleted');
        } 
        else
        {
          $this->session->set_flashdata('error', 'Product Not deleted, Some error occure..');
          
        }
        redirect('product');
    }
  }  
  public function deletassignproduct($id){
    if($id)
    {
        if($this->product_model->deletassignproduct($id))
        {
          $this->session->set_flashdata('success', 'Assign Product Successfully deleted');
        } 
        else
        {
          $this->session->set_flashdata('error', 'Assign Product Not deleted, Some error occure..');
          
        }
        redirect('assign-product_list');
    }
  }  
  public function add(){

    	if($_SERVER['REQUEST_METHOD'] == 'POST'){
    		
    	  $this->form_validation->set_rules('invoice_no', 'Invoice Number', 'required');
    	  $this->form_validation->set_rules('product_name', 'Product Name', 'required');
        $this->form_validation->set_rules('category', 'Category', 'required');
        $this->form_validation->set_rules('quantity', 'Product Quantity', 'required|integer');
        $this->form_validation->set_rules('unit_price', 'Product Unit Price', 'required|numeric');
        $this->form_validation->set_rules('total_price', 'Product Total Price', 'required|numeric');
        $this->form_validation->set_rules('description', 'Description', 'required');
        
            
            
        if ($this->form_validation->run() == true){ 
          
          $invoice_no       = ($this->input->post('invoice_no'))?$this->input->post('invoice_no'):'';
          $product_name     = ($this->input->post('product_name'))?$this->input->post('product_name'):'';
    	    $category         = ($this->input->post('category'))?$this->input->post('category'):'';
    	    $quantity         = ($this->input->post('quantity'))?$this->input->post('quantity'):'';
    	    $unit_price       = ($this->input->post('unit_price'))?$this->input->post('unit_price'):'';
    	    $total_price      = ($this->input->post('total_price'))?$this->input->post('total_price'):'';
    	    $date             = ($this->input->post('current_date'))?$this->input->post('current_date'):'';
    	    $description      = ($this->input->post('description'))?$this->input->post('description'):'';
          $datetime         =  $this->defualt_date_time(); 
          $user_id          = $this->session->userdata('id');
          $role             = $this->session->userdata('role');
          $role_id          = base64_decode($role);
          
          $productData      = array(    
              
                                  'role_id'       => $role_id, 
                                  'user_id'       => $user_id, 
                                  'invoice_no'    => $invoice_no, 
                                  'name'          => $product_name, 
                                  'category'      => $category, 
                                  'quantity'      => $quantity,
                                  'remaining_qnty' => $quantity,
                                  'unit_price'    => $unit_price, 
                                  'total_price'   => $total_price, 
          	                      'description'   => $description, 
          	                      'created_date'  => $datetime, 
          	                      'updated_date'  => $datetime  );
        
        if($this->product_model->save($productData) == true){
    	  
    	  $this->session->set_flashdata('success', 'Add Product Successfully');
    	  redirect('product');

    	  }else{

          $this->session->set_flashdata('error', 'Product Not Added, try Again');
    	  redirect('add-product');

    	  }

    	}else{
          
          $data['invoice_no']   = ($this->input->post('invoice_no'))?$this->input->post('invoice_no'):'';
          $data['product_name'] = ($this->input->post('product_name'))?$this->input->post('product_name'):'';
          $data['category']     = ($this->input->post('category'))?$this->input->post('category'):'';
          $data['quantity']     = ($this->input->post('quantity'))?$this->input->post('quantity'):'';
          $data['unit_price']   = ($this->input->post('unit_price'))?$this->input->post('unit_price'):'';
          $data['total_price']  = ($this->input->post('total_price'))?$this->input->post('total_price'):'';
          $data['current_date'] = ($this->input->post('current_date'))?$this->input->post('current_date'):'';
          $data['description']  = ($this->input->post('description'))?$this->input->post('description'):'';
          $data['page_title']   = "Add Product";
          $this->load->view('product/add', $data);	      
    	}  

    	}else{
          
          $data['success']     = $this->session->userdata('success');    
          $data['error']       = $this->session->userdata('error');    
          $data['page_title']  = "Add Product";

          $data['path_first']  = "Home";
          $data['path_second'] = "Add Product";
          
          $data['url_first']   = "home";
          $data['url_second']  = "add-product";
          
          $this->load->view('product/add', $data);	  
    	}

	}
  public function edit($id){

      if($_SERVER['REQUEST_METHOD'] == 'POST'){
        
        $this->form_validation->set_rules('invoice_no', 'Invoice Number', 'required');
        $this->form_validation->set_rules('product_name', 'Product Name', 'required');
        $this->form_validation->set_rules('category', 'Category', 'required');
        $this->form_validation->set_rules('quantity', 'Product Quantity', 'required|integer');
        $this->form_validation->set_rules('unit_price', 'Product Unit Price', 'required|numeric');
        $this->form_validation->set_rules('total_price', 'Product Total Price', 'required|numeric');
        $this->form_validation->set_rules('description', 'Description', 'required');
        
            
            
        if ($this->form_validation->run() == true){ 
          
          $invoice_no       = $this->input->post('invoice_no');
          $product_name     = $this->input->post('product_name');
          $category         = $this->input->post('category');
          $quantity         = $this->input->post('quantity');
          $unit_price       = $this->input->post('unit_price');
          $total_price      = $this->input->post('total_price');
          $date             = $this->input->post('current_date');
          $description      = $this->input->post('description');
          $datetime         = $this->defualt_date_time(); 
          $user_id          = $this->session->userdata('id');
          $role             = $this->session->userdata('role');
          $role_id          = base64_decode($role);
          
          $productData      = array(    
              
                                  'role_id'       => $role_id, 
                                  'user_id'       => $user_id, 
                                  'invoice_no'    => $invoice_no, 
                                  'name'          => $product_name, 
                                  'category'      => $category, 
                                  'quantity'      => $quantity,
                                  'remaining_qnty' => $quantity,
                                  'unit_price'    => $unit_price, 
                                  'total_price'   => $total_price, 
                                  'description'   => $description, 
                                  'updated_date'  => $datetime  );
        
        if($this->product_model->save($productData,$id)){
        
        $this->session->set_flashdata('success', 'Update Product Successfully');
        redirect('product');

        }else{

          $this->session->set_flashdata('error', 'Product Not Updated, try Again');
        redirect('update-product/'.$id);

        }

      }else{
          
          $data['invoice_no']   = $this->input->post('invoice_no');
          $data['product_name'] = $this->input->post('product_name');
          $data['category']     = $this->input->post('category');
          $data['quantity']     = $this->input->post('quantity');
          $data['unit_price']   = $this->input->post('unit_price');
          $data['total_price']  = $this->input->post('total_price');
          $data['current_date'] = $this->input->post('current_date');
          $data['description']  = $this->input->post('description');
          $data['page_title']  = "Update Product";

          $data['path_first']  = "Home";
          $data['path_second'] = "Update Product";
          
          $data['url_first']   = "home";
          $data['url_second']  = "update-product/".$id;
          $this->load->view('product/edit', $data);        
      }  

      }else{

        $product=$this->product_model->getproductinfoByID($id);
        if($product)
        {
          $data['invoice_no']   = $product->invoice_no;
          $data['product_name'] = $product->name;
          $data['category']     = $product->category;
          $data['quantity']     = $product->remaining_qnty;
          $data['unit_price']   = $product->unit_price;
          $data['total_price']  = $product->total_price;
          $data['current_date'] = '';
          $data['description']  = $product->description;
 
        }
         
          
          $data['success']     = $this->session->userdata('success');    
          $data['error']       = $this->session->userdata('error');    
          $data['page_title']  = "Update Product";

          $data['path_first']  = "Home";
          $data['path_second'] = "Update Product";
          
          $data['url_first']   = "home";
          $data['url_second']  = "update-product/".$id;
          
          $this->load->view('product/edit', $data);    
      }

  }
	
  function _more_than($str, $field=''){
      
      
      $str = intval($str);
      $min = intval($this->input->post($field));
      
      if ($str >= $min) {
          $this->form_validation->set_message('_more_than', "The %s field must be less than {$min}.");
          return false;
      }
      
      return true;
  }

	public function assign_product(){
	    
    	if($_SERVER['REQUEST_METHOD'] == 'POST'){
    		
        
    	  $this->form_validation->set_rules('school', 'School', 'required');
    	  $this->form_validation->set_rules('form_text', 'Some', 'required');
        $this->form_validation->set_rules('assign_qnty',  'Assign Quantity', 'required|numeric|callback__more_than[quantity]' ); 

        //$this->form_validation->set_rules('assign_qnty', 'Product Assign Quantity', 'required|integer|min_length[1]|max_length[quantity]',array('max_length' => 'Product Assign Quantity must less than or equal to stock quantity.'));
        

        if($this->input->post('assign_qnty') >  $this->input->post('quantity')){

          $this->form_validation->set_message('assign_qnty', 'Product Assign Quantity must less than or equal to stock quantity.');
        }    
            
        if ($this->form_validation->run() == true){ 
          
          $school       = ($this->input->post('school'))?$this->input->post('school'):'';
          $assign_qnty  = ($this->input->post('assign_qnty'))?$this->input->post('assign_qnty'):'';
          $product      = $this->input->post('form_text');
          $product_id   = base64_decode($product);
          $datetime     =  $this->defualt_date_time(); 

          $is_product   = $this->product_model->getproductinfoByID($product_id);
          
          $user_id      = $is_product->user_id;
          $role_id      = $is_product->role_id; 
          $is_company   = $this->session->userdata('id');

          // $role         = $this->session->userdata('role');
          // $role_id      = base64_decode($role);
          
          $AssignData   = array(    
              
                                  'role_id'       => $role_id, 
                                  'user_id'       => $user_id, 
                                  'is_company'    => $is_company, 
                                  'product_id'    => $product_id, 
                                  'school_id'     => $school, 
                                  'assign_qnty'   => $assign_qnty, 
                                  'created_date'  => $datetime, 
          	                      'updated_date'  => $datetime  );
        
        
        
        if($this->product_model->save_assign_product($AssignData, $assign_qnty, $product_id) == true){
    	  
    	  $this->session->set_flashdata('success', 'Add Product Successfully');
    	  redirect('assign-product_list');

    	  }else{

        $this->session->set_flashdata('error', 'Product Not Added, try Again');
    	  redirect('assign-product');

    	  }

    	}else{
          
          $data['school_id']       = $this->input->post('school');
          $data['assign_qnty']  = $this->input->post('assign_qnty');
          $data['form_text']    = $this->input->post('form_text');
          $product_id           = base64_decode($this->input->post('form_text'));
          $data['product']      = $this->product_model->getproductinfoByID($product_id);
          
          $data['address']       = $this->input->post('address');
          $data['product_name']  = $this->input->post('product_name');
          $data['quantity']      = $this->input->post('quantity');
          $data['unit_price']    = $this->input->post('unit_price');
          $data['description']   = $this->input->post('description');
          
          $data['page_title']  = "Assign Product";

          $data['path_first']  = "Home";
          $data['path_second'] = "Assign Product";
          
          $data['url_first']   = "home";
          $data['url_second']  = "assign-product";
          
          $this->load->view('product/assign_school', $data);
          
    	}  

    	}else{
          
          if($this->input->get('school')){ 
          
          $product = $this->input->get('school'); $product_id = base64_decode($product); 
          $data['success']     = $this->session->userdata('success');    
          $data['error']       = $this->session->userdata('error');    
          $data['product']     = $this->product_model->getproductinfoByID($product_id);
          $data['form_text']   = $product;
          
          $data['page_title']  = "Assign Product";

          $data['path_first']  = "Home";
          $data['path_second'] = "Assign Product";
          
          $data['url_first']   = "home";
          $data['url_second']  = "assign-product";
          
          $this->load->view('product/assign_school', $data);	  
          
          }else{
              
              redirect('assign-product_list');
          }
    	}
    	
	}
  public function edit_assign_product($id){
      
      if($_SERVER['REQUEST_METHOD'] == 'POST'){
        
      $this->form_validation->set_rules('school', 'School', 'required');
      $this->form_validation->set_rules('form_text', 'Some', 'required');
        $this->form_validation->set_rules('assign_qnty', 'Product Assign Quantity', 'required|integer|min_length[1]');
            
            
        if ($this->form_validation->run() == true){ 
          
          $school       = $this->input->post('school');
          $assign_qnty  = $this->input->post('assign_qnty');
          $product      = $this->input->post('form_text');
          $product_id   = base64_decode($product);
          
          $datetime     =  $this->defualt_date_time(); 
          $user_id      = $this->session->userdata('id');
          $role         = $this->session->userdata('role');
          $role_id      = base64_decode($role);
          
          $AssignData   = array(  
                                  'role_id'       => $role_id, 
                                  'user_id'       => $user_id, 
                                  'product_id'    => $product_id, 
                                  'school_id'     => $school, 
                                  'assign_qnty'   => $assign_qnty, 
                                  'updated_date'  => $datetime  );
        
        
        
        if($this->product_model->save_assign_product($AssignData, $assign_qnty, $product_id,$id))
        {
             $this->session->set_flashdata('success', 'Add Product Successfully');
             redirect('assign-product_list');

        }else{

          $this->session->set_flashdata('error', 'Product Not Added, try Again');
          redirect('update-assign-product/'.$id);

        }

      }else{
          
          $data['school_id']       = $this->input->post('school');
          $data['assign_qnty']  = $this->input->post('assign_qnty');
          $data['form_text']    = $this->input->post('form_text');
          $product_id           = base64_decode($this->input->post('form_text'));
          $data['product']      = $this->product_model->getproductinfoByID($product_id);
          
          $data['address']       = $this->input->post('address');
          $data['product_name']  = $this->input->post('product_name');
          $data['quantity']      = $this->input->post('quantity');
          $data['unit_price']    = $this->input->post('unit_price');
          $data['description']   = $this->input->post('description');
          
          $data['page_title']  = "Update Product";

          $data['path_first']  = "Home";
          $data['path_second'] = "Update Product";
          
          $data['url_first']   = "home";
          $data['url_second']  = "update-assign-product/".$id;
          
          $this->load->view('product/edit_assign_school', $data);
          
      }  

      }else{
          $assign_pro=$this->product_model->get_assign_productinfo($id);
          if($assign_pro)
          {
             $school=$this->school_model->getinfo($assign_pro->school_id);
              $data['school_id']       = $assign_pro->school_id;
              $data['assign_qnty']  = $assign_pro->assign_qnty;
              $data['form_text']    = base64_encode($assign_pro->product_id);
              
              $data['product']  =$product    = $this->product_model->getproductinfoByID($assign_pro->product_id);
             
              $data['address']       = $school->address;
              $data['product_name']  = $product->name;
              $data['quantity']      = $product->remaining_qnty;
              $data['unit_price']    = $product->unit_price;
              $data['description']   = $product->description;  
          }
          
          

          $data['success']     = $this->session->userdata('success');    
          $data['error']       = $this->session->userdata('error');    
                   
          $data['page_title']  = "Update Assign Product";

          $data['path_first']  = "Home";
          $data['path_second'] = "Update Assign Product";
          
          $data['url_first']   = "home";
          $data['url_second']  = "update-assign-product/".$id;
          
          $this->load->view('product/edit_assign_school', $data);    
          
      }
      
  }
  public function assign_list(){
     if (!$this->authentication->is_logged_in()){
     
       redirect('login');
       exit();
        
        }else{
           
           $data['success'] = $this->session->userdata('success');    
           $data['error']   = $this->session->userdata('error');

           $data['assign_list']    = $this->product_model->get_assign_product_list();   

           $data['path_first']  = "Home";
           $data['path_second'] = "Assign Products";
          
           $data['url_first']   = "home";
           $data['url_second']  = "assign-product_list";

           $data['page_title']  = "Assign Products";
           
           $this->load->view('product/assign_list', $data);    

        }
  }
	
	
}
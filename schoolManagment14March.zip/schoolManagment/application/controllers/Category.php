<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once ('Auth_access.php');

class Category extends Auth_access {


	public function index(){
        
        if (!$this->authentication->is_logged_in()){
		 
		   redirect('login');
		   exit();
        
        }else{
           
           $data['success'] = $this->session->userdata('success');    
           $data['error']   = $this->session->userdata('error');

           $data['category']    = $this->category_model->getCategory();   

           $data['path_first']  = "Home";
           $data['path_second'] = "Category";
          
           $data['url_first']   = "home";
           $data['url_second']  = "category";

           $data['page_title']  = "Category";
           
           $this->load->view('category/list', $data);	  

        }

	}

	public function defualt_date_time(){
        
        date_default_timezone_set('Asia/Kolkata');
        return date('Y-m-d H:i:a');
    }
    public function deletecategory($id){
    if($id)
    {
        if($this->category_model->deletecategory($id))
        {
          $this->session->set_flashdata('success', 'Category Successfully deleted');
        } 
        else
        {
          $this->session->set_flashdata('error', 'Category Not deleted, Some error occure..');
          
        }
        redirect('category');
    }
  }
    
    public function add(){

    	if($_SERVER['REQUEST_METHOD'] == 'POST'){
    		
        $this->form_validation->set_rules('category', 'Category', 'required');
        $this->form_validation->set_rules('description', 'Description', 'required');
        
        
        if ($this->form_validation->run() == true){ 
          
    	  $category     = ($this->input->post('category'))?$this->input->post('category'):'';
    	  $date         = ($this->input->post('current_date'))?$this->input->post('current_date'):'';
    	  $description  = ($this->input->post('description'))?$this->input->post('description'):'';
          $datetime     =  $this->defualt_date_time(); 
          $user_id      = $this->session->userdata('id');
          $role         = $this->session->userdata('role');
          $role_id      = base64_decode($role);
          
          $categoryData = array(    
                                  'role_id'       => $role_id, 
                                  'user_id'       => $user_id, 
                                  'category_name' => $category, 
          	                      'description'   => $description, 
          	                      'create_date'   => $datetime, 
          	                      'update_date'   => $datetime  );
          
        if($this->category_model->save($categoryData) == true){
    	  
    	  $this->session->set_flashdata('success', 'Add Category Successfully');
    	  redirect('category');

    	  }else{

        $this->session->set_flashdata('error', 'Category Not Added, try Again');
    	  redirect('add-category');

    	  }

    	}else{
          
          $data['category']     = ($this->input->post('category'))?$this->input->post('category'):'';
          $data['current_date'] = ($this->input->post('current_date'))?$this->input->post('current_date'):'';
          $data['description']  = ($this->input->post('description'))?$this->input->post('description'):'';
          $data['page_title']   = "Add Category";
          $this->load->view('category/add', $data);	      
    	}  

    	}else{
          
          $data['success']     = $this->session->userdata('success');    
          $data['error']       = $this->session->userdata('error');    
          $data['page_title']  = "Add Category";

          $data['path_first']  = "Home";
          $data['path_second'] = "Add Category";
          
          $data['url_first']   = "home";
          $data['url_second']  = "add-category";
          
          $this->load->view('category/add', $data);	  
    	}

	}
  public function edit($id){

      if($_SERVER['REQUEST_METHOD'] == 'POST'){
        
        $this->form_validation->set_rules('category', 'Category', 'required');
        $this->form_validation->set_rules('description', 'Description', 'required');
        
        
        if ($this->form_validation->run() == true){ 
          
        $category     = $this->input->post('category');
        $date         = $this->input->post('current_date');
        $description  = $this->input->post('description');
          $datetime     =  $this->defualt_date_time(); 
          $user_id      = $this->session->userdata('id');
          $role         = $this->session->userdata('role');
          $role_id      = base64_decode($role);
          
          $categoryData = array(    
                                  'role_id'       => $role_id, 
                                  'user_id'       => $user_id, 
                                  'category_name' => $category, 
                                  'description'   => $description, 
                                  'update_date'   => $datetime  );
          
        if($this->category_model->save($categoryData,$id)){
        
        $this->session->set_flashdata('success', 'Update Category Successfully');
        redirect('category');

        }else{

        $this->session->set_flashdata('error', 'Category Not Updated, try Again');
        redirect('update-category/'.$id);

        }

      }else{
          
          $data['category']     = $this->input->post('category');
          $data['current_date'] = $this->input->post('current_date');
          $data['description']  = $this->input->post('description');
          $data['page_title']  = "Update Category";

          $data['path_first']  = "Home";
          $data['path_second'] = "Update Category";
          
          $data['url_first']   = "home";
          $data['url_second']  = "update-category/".$id;
          
          $this->load->view('category/edit', $data);       
      }  

      }else{
          $category=$this->category_model->getInfo($id);
          if($category)
          {
            $data['category']     = $category->category_name;
            $data['current_date'] = '';
            $data['description']  = $category->description;
              
          }
                    
          $data['success']     = $this->session->userdata('success');    
          $data['error']       = $this->session->userdata('error');    
          $data['page_title']  = "Update Category";

          $data['path_first']  = "Home";
          $data['path_second'] = "Update Category";
          
          $data['url_first']   = "home";
          $data['url_second']  = "update-category/".$id;
          
          $this->load->view('category/edit', $data);   
      }

  }
}	
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth_access extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();

	    if (!$this->authentication->is_logged_in()){
		 
		   redirect('login');
		   exit();
        
        }
	}

}

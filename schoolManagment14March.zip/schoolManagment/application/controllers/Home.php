<?php
defined('BASEPATH') OR exit('No direct script access allowed');
//require_once ('Auth.php');

class Home extends CI_Controller {

    function __construct()
	{
		parent::__construct();
		
	}

	public function index(){
        
        if (!$this->authentication->is_logged_in()){
		 
		   redirect('login');
		   exit();
        
        }else{
           
           $data['path_first']  = "Home";
           $data['path_second'] = "Dashboard";
          
           $data['url_first']   = "home";
           $data['url_second']  = "home";
            
           $data['page_title'] = "Dashboard";
           $this->load->view('home/dashboard', $data);	  
        }

	}

	public function login(){
        
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            
            $this->form_validation->set_rules('username', 'Username', 'required');
            $this->form_validation->set_rules('password', 'Password', 'required');
            
            if ($this->form_validation->run() == true){
            
	        $USERNAME = $this->input->post('username');
	        $PASSWORD = $this->input->post('password');

            if((!empty($USERNAME)) && (!empty($PASSWORD))){
                
            $userdata = array('username' => $USERNAME, 'password' => md5($PASSWORD));
            if ($this->authentication->login($USERNAME, $PASSWORD) == true ){
            redirect('home');

            }else{ 
                
            $this->session->set_flashdata('error', 'Username & Password Incurrect');
            $data['page_title'] = "Login";
            $data['success']     = $this->session->userdata('success');    
            $data['error']       = $this->session->userdata('error');    
          
            $this->load->view('home/login', $data);
            
            }
            }else{

            $this->session->set_flashdata('error', 'Please Enter Username & Password');
            $data['page_title'] = "Login";
            $data['success']     = $this->session->userdata('success');    
            $data['error']       = $this->session->userdata('error');    
          
            $this->load->view('home/login', $data);  
            
            }

            }else{
                
            $data['page_title'] = "Login";
            $data['success']     = $this->session->userdata('success');    
            $data['error']       = $this->session->userdata('error');    
          
            $this->load->view('home/login', $data);    

            }

        }else{
            
            $data['page_title'] = "LOGIN";
            $data['success']     = $this->session->userdata('success');    
            $data['error']       = $this->session->userdata('error');    
          
            $this->load->view('home/login', $data);    
        }  
	}

	function logout(){
        
        $this->session->unset_userdata("id"); 
        $this->session->sess_destroy(); 
        
        $data['page_title'] = "Login";
        $this->load->view('home/login', $data);

	}
	
    function states($country_id)
    {
        $states=$this->authentication->get_state($country_id);
        if($states)
        {
            echo json_encode($states);die;
        }
        else
        {
            echo '0';
        }
    }
    function city($state_id)
    {
        $city=$this->authentication->get_city($state_id);
        if($city)
        {
            echo json_encode($city);die;
        }
        else
        {
            echo '0';
        }
    }
}

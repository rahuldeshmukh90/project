<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once ('Auth_access.php');

class Services extends Auth_access {


	public function index(){
        
        if (!$this->authentication->is_logged_in()){
		 
		   redirect('login');
		   exit();
        
        }else{
           
           $data['success'] = $this->session->userdata('success');    
           $data['error']   = $this->session->userdata('error');

           $data['service']    = $this->service_model->getservice();   

           $data['path_first']  = "Home";
           $data['path_second'] = "Service";
          
           $data['url_first']   = "home";
           $data['url_second']  = "services";

           $data['page_title']  = "Services";
           
           $this->load->view('service/list', $data);	  

        }

	}

	public function defualt_date_time(){
        
        date_default_timezone_set('Asia/Kolkata');
        return date('Y-m-d H:i:a');
    }
    
    public function deleteassignservice($id){
    if($id)
    {
        if($this->service_model->deleteassignservice($id))
        {
          $this->session->set_flashdata('success', 'Assign Service Successfully deleted');
        } 
        else
        {
          $this->session->set_flashdata('error', 'Assign Service Not deleted, Some error occure..');
          
        }
        redirect('assign-service');
    }
  }
    public function deleteservice($id){
    if($id)
    {
        if($this->service_model->deleteservice($id))
        {
          $this->session->set_flashdata('success', 'Service Successfully deleted');
        } 
        else
        {
          $this->session->set_flashdata('error', 'Service Not deleted, Some error occure..');
          
        }
        redirect('services');
    }
  }
    
    public function add(){

    	if($_SERVER['REQUEST_METHOD'] == 'POST'){
    		
        $this->form_validation->set_rules('name', 'Name', 'required');
        $this->form_validation->set_rules('description', 'Description', 'required');
        
        if ($this->form_validation->run() == true){ 
          
      	  $name         = ($this->input->post('name'))?$this->input->post('name'):'';
          $description  = ($this->input->post('description'))?$this->input->post('description'):'';
          $datetime     = $this->defualt_date_time(); 
          $user_id      = $this->session->userdata('id');
          $role         = $this->session->userdata('role');
          $role_id      = base64_decode($role);
            
          $servicedata = array(    
                                   'user_id'        => $user_id, 
                                   'role_id'        => $role_id, 
                                   'name'           => $name, 
            	                   'description'    => $description, 
                                   'created_date'   => $datetime, 
            	                   'updated_date'   => $datetime  );
            
          if($this->service_model->save($servicedata) == true){
      	  
      	  $this->session->set_flashdata('success', 'Add service Successfully');
      	  redirect('services');

      	  }else{

          $this->session->set_flashdata('error', 'Service Not Added, try Again');
      	  redirect('add-services');

      	  }

      	}else{
            
          $data['name']         = $this->input->post('name');
          $data['description']  = $this->input->post('description');
          
          $data['page_title']  = "Add Services";

          $data['path_first']  = "Home";
          $data['path_second'] = "Add Services";
          
          $data['url_first']   = "home";
          $data['url_second']  = "add-services";
            $this->load->view('service/add', $data);	      
      	}  

    	}else{
          
          $data['success']     = $this->session->userdata('success');    
          $data['error']       = $this->session->userdata('error');    
          $data['page_title']  = "Add Services";

          $data['path_first']  = "Home";
          $data['path_second'] = "Add Services";
          
          $data['url_first']   = "home";
          $data['url_second']  = "add-services";
          
          $this->load->view('service/add', $data);	  
    	}

	}
	public function edit($id){

      if($_SERVER['REQUEST_METHOD'] == 'POST'){
        
        $this->form_validation->set_rules('name', 'Name', 'required');
        $this->form_validation->set_rules('description', 'Description', 'required');
        
        if ($this->form_validation->run() == true){ 
          
          $name         = ($this->input->post('name'))?$this->input->post('name'):'';
          $description  = ($this->input->post('description'))?$this->input->post('description'):'';
          $datetime     = $this->defualt_date_time(); 
          $user_id      = $this->session->userdata('id');
          $role         = $this->session->userdata('role');
          $role_id      = base64_decode($role);
            
          $servicedata = array(    
                                   'user_id'        => $user_id, 
                                   'role_id'        => $role_id, 
                                   'name'           => $name, 
                                 'description'    => $description, 
                                  
                                 'updated_date'   => $datetime  );
            
          if($this->service_model->save($servicedata,$id)){
          
          $this->session->set_flashdata('success', 'Update service Successfully');
          redirect('services');

          }else{

          $this->session->set_flashdata('error', 'Service Not Updated, try Again');
          redirect('update-services/'.$id);

          }

        }else{
            
          $data['name']         = $this->input->post('name');
          $data['description']  = $this->input->post('description');
          
          $data['page_title']  = "Update Services";

          $data['path_first']  = "Home";
          $data['path_second'] = "Update Services";
          
          $data['url_first']   = "home";
          $data['url_second']  = "update-services/".$id;
            $this->load->view('service/edit', $data);        
        }  

      }else{
        $service=$this->service_model->getserviceinfo($id);
          if($service){
            $data['name']         = $service->name;
            $data['description']  = $service->description;
        
          }
        
          
          $data['success']     = $this->session->userdata('success');    
          $data['error']       = $this->session->userdata('error');    
          $data['page_title']  = "Update Services";

          $data['path_first']  = "Home";
          $data['path_second'] = "Update Services";
          
          $data['url_first']   = "home";
          $data['url_second']  = "update-services/".$id;
          
          $this->load->view('service/edit', $data);    
      }

  }
  
	/*=============ASSIGN VENDOR TO SERVICES===========*/
	
	public function assign_list(){
	    
	       $data['success'] = $this->session->userdata('success');    
           $data['error']   = $this->session->userdata('error');

           $data['service']    = $this->service_model->getAssigni();   

           $data['path_first']  = "Home";
           $data['path_second'] = "Assign services";
          
           $data['url_first']   = "home";
           $data['url_second']  = "assign-service";

           $data['page_title']  = "Assign Services";
           
           $this->load->view('service/assign_list', $data);
           
	}
	
	/*=============ASSIGN VENDOR TO SERVICES===========*/
	
	public function assign_vendor(){
	    
     
	   if($_SERVER['REQUEST_METHOD'] == 'POST'){
    		
        $this->form_validation->set_rules('vendor', 'Vendor', 'required');
        $this->form_validation->set_rules('service', 'Service', 'required');
        
        if ($this->form_validation->run() == true){ 
          
      	  $vendor       = ($this->input->post('vendor'))?$this->input->post('vendor'):'';
          $service      = ($this->input->post('form_text'))?$this->input->post('form_text'):'';
          $service_id   = base64_decode($service);
          $datetime     = $this->defualt_date_time(); 
          
          $dataService  = $this->service_model->getserviceinfo($service_id);
          
          $user_id      = $dataService->user_id; 
          $role_id      = $dataService->role_id; 
          $is_company   = $this->session->userdata('id');
          // $role         = $this->session->userdata('role');
          // $role_id      = base64_decode($role);
            
          $Assigndata = array(    
                                   'user_id'        => $user_id, 
                                   'role_id'        => $role_id, 
                                   'is_company'     => $is_company, 
                                   'vendor_id'      => $vendor, 
            	                     'service_id'     => $service_id, 
                                   'created_date'   => $datetime, 
            	                     'updated_date'   => $datetime  );
            
          if($this->service_model->save_assign_vendor($Assigndata) == true){
      	  
      	  $this->session->set_flashdata('success', 'Assign Vendor Successfully');
      	  redirect('assign-service');

      	  }else{

          $this->session->set_flashdata('error', 'Vendor Not Assigned, try Again');
      	  redirect('assign');

      	  }

      	}else{
           
          $data['vendorid']         = $this->input->post('vendor');
          $data['service']     = $this->service_model->getserviceinfo(base64_decode($this->input->post('form_text')));
          $data['form_text']   = $this->input->post('form_text');  
          $data['page_title']  = "Assign Vendor";

          $data['path_first']  = "Home";
          $data['path_second'] = "Assign Vendor";
          
          $data['url_first']   = "home";
          $data['url_second']  = "assign";
          $this->load->view('service/assign_vendor', $data);	 
          
      	}  

    	}else{

          if($this->input->get('text')){ $service = $this->input->get('text'); $service_id = base64_decode($service); }
          
          $data['success']     = $this->session->userdata('success');    
          $data['error']       = $this->session->userdata('error');   
          $data['vendorid']     = '';
          $data['service']     = $this->service_model->getserviceinfo($service_id);
          $data['form_text']   = $service;
          $data['page_title']  = "Assign Vendor";

          $data['path_first']  = "Home";
          $data['path_second'] = "Assign Vendor";
          
          $data['url_first']   = "home";
          $data['url_second']  = "assign";
          
          $this->load->view('service/assign_vendor', $data);	  
    	}
	}

  public function edit_assign_vendor($id){
      
     
     if($_SERVER['REQUEST_METHOD'] == 'POST'){
        
        $this->form_validation->set_rules('vendor', 'Vendor', 'required');
        $this->form_validation->set_rules('service', 'Service', 'required');
        
        if ($this->form_validation->run() == true){ 
          
          $vendor       = ($this->input->post('vendor'))?$this->input->post('vendor'):'';
          $service      = ($this->input->post('form_text'))?$this->input->post('form_text'):'';
          $service_id   = base64_decode($service);
          $datetime     = $this->defualt_date_time(); 
          $user_id      = $this->session->userdata('id');
          $role         = $this->session->userdata('role');
          $role_id      = base64_decode($role);
            
          $Assigndata = array(    
                                   'user_id'        => $user_id, 
                                   'role_id'        => $role_id, 
                                   'vendor_id'      => $vendor, 
                                 'service_id'     => $service_id, 
                                  'updated_date'   => $datetime  );
            
          if($this->service_model->save_assign_vendor($Assigndata,$id)){
          
          $this->session->set_flashdata('success', 'Update Assign Vendor Successfully');
          redirect('assign-service');

          }else{

          $this->session->set_flashdata('error', 'Vendor Not Assigned, try Again');
          redirect('update-assign/'.$id);

          }

        }else{
           
          $data['vendorid']    = $this->input->post('vendor');
          $data['service']     = $this->service_model->getserviceinfo(base64_decode($this->input->post('form_text')));
          $data['form_text']   = $this->input->post('form_text');  
          $data['page_title']  = "Update Assign Vendor";

          $data['path_first']  = "Home";
          $data['path_second'] = "Update Assign Vendor";
          
          $data['url_first']   = "home";
          $data['url_second']  = "update-assign/".$id;
          $this->load->view('service/edit_assign_vendor', $data);   
          
        }  

      }else{

           $assignservice=$this->service_model->getAssign_info($id);
          
          $data['success']     = $this->session->userdata('success');    
          $data['error']       = $this->session->userdata('error');   
          if($assignservice)
          {
            $data['vendorid']   = $assignservice->vendor_id;
            $data['service']     = $this->service_model->getserviceinfo($assignservice->service_id);
            $data['form_text']   =base64_encode($assignservice->service_id);
          }
          
          
          $data['page_title']  = "Update Assign Vendor";

          $data['path_first']  = "Home";
          $data['path_second'] = "Update Assign Vendor";
          
          $data['url_first']   = "home";
          $data['url_second']  = "update-assign/".$id;
          
          $this->load->view('service/edit_assign_vendor', $data);    
      }
  }
}	
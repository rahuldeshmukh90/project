<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once ('Auth_access.php');

class Schools extends Auth_access {


	public function index(){
        
        if (!$this->authentication->is_logged_in()){
		 
		   redirect('login');
		   exit();
        
        }else{
           
           $data['success'] = $this->session->userdata('success');    
           $data['error']   = $this->session->userdata('error');

           $data['school']    = $this->school_model->getschool();   

           $data['path_first']  = "Home";
           $data['path_second'] = "School";
          
           $data['url_first']   = "home";
           $data['url_second']  = "schools";

           $data['page_title']  = "Schools";
           
           $this->load->view('school/list', $data);	  

        }

	}

	public function defualt_date_time(){
        
        date_default_timezone_set('Asia/Kolkata');
        return date('Y-m-d H:i:a');
    }
    
  public function deleteschool($id){
    if($id)
    {
        if($this->school_model->deleteschool($id))
        {
          $this->session->set_flashdata('success', 'School Successfully deleted');
        } 
        else
        {
          $this->session->set_flashdata('error', 'School Not deleted, Some error occure..');
          
        }
        redirect('schools');
    }
  }
      
  public function add(){

    	if($_SERVER['REQUEST_METHOD'] == 'POST'){
    		
        $this->form_validation->set_rules('name', 'Name', 'required');
        // $this->form_validation->set_rules('email', 'Email', 'required|is_unique[school.email]');
        $this->form_validation->set_rules('email', 'Email', 'required');
        $this->form_validation->set_rules('address', 'Address', 'required');
        $this->form_validation->set_rules('contact', 'Contact No', 'required');
        $this->form_validation->set_rules('principal', 'Principal Name', 'required');
        $this->form_validation->set_rules('manager', 'Manager', 'required');
        
        $this->form_validation->set_rules('country', 'Country', 'required');
        $this->form_validation->set_rules('state', 'State', 'required');
        $this->form_validation->set_rules('city', 'City', 'required');
       
        if($this->form_validation->run() == true){ 
          
      	  
          $name         = ($this->input->post('name'))?$this->input->post('name'):'';
          $email        = ($this->input->post('email'))?$this->input->post('email'):'';
          $address      = ($this->input->post('address'))?$this->input->post('address'):'';
          $contact      = ($this->input->post('contact'))?$this->input->post('contact'):'';
      	  $principal    = ($this->input->post('principal'))?$this->input->post('principal'):'';
      	  $manager      = ($this->input->post('manager'))?$this->input->post('manager'):'';
          $country      = ($this->input->post('country'))?$this->input->post('country'):'';
          $state        = ($this->input->post('state'))?$this->input->post('state'):'';
          $city         = ($this->input->post('city'))?$this->input->post('city'):'';
          $datetime     = $this->defualt_date_time(); 
          $user_id      = $this->session->userdata('id');
          $role         = $this->session->userdata('role');
          $role_id      = base64_decode($role);
            
          $schoolData = array(      
                                    'user_id'        => $user_id, 
                                    'role_id'        => $role_id, 
                                    'name'           => $name, 
            	                      'email'          => $email, 
                                    'address'        => $address, 
                                    'contact'        => $contact, 
                                    'principal'      => $principal, 
                                    'manager'        => $manager,
                                    'city'           => $city,
                                    'state'          => $state,
                                    'country'        => $country,
                                    'created_date'   => $datetime, 
            	                      'updated_date'   => $datetime  );
            
          if($this->school_model->save($schoolData) == true){
      	  
      	  $this->session->set_flashdata('success', 'Add School Successfully');
      	  redirect('schools');

      	  }else{

          $this->session->set_flashdata('error', 'School Not Added, try Again');
      	  redirect('add-schools');

      	  }

      	}else{
            
          
          $data['name']         = $this->input->post('name');
          $data['email']        = $this->input->post('email');
          $data['address']      = $this->input->post('address');
          $data['contact']      = $this->input->post('contact');
      	  $data['principal']    = $this->input->post('principal');
      	  $data['manager']      = $this->input->post('manager');
          $data['country']      = $this->input->post('country');
          $data['state']        = $this->input->post('state');
          $data['city']         = $this->input->post('city');
          
          $data['page_title']  = "Add Schools";

          $data['path_first']  = "Home";
          $data['path_second'] = "Add Schools";
          
          $data['url_first']   = "home";
          $data['url_second']  = "add-schools";
          
          $this->load->view('school/add', $data);	      
          
      	}  

    	}else{
        
          $data['name']         = '';
          $data['email']        = '';
          $data['address']      = '';
          $data['contact']      = '';
          $data['principal']    = '';
          $data['manager']      = '';
          $data['country']      = '';
          $data['state']        = '';
          $data['city']         = '';
          
          $data['success']     = $this->session->userdata('success');    
          $data['error']       = $this->session->userdata('error');    
          $data['page_title']  = "Add Schools";

          $data['path_first']  = "Home";
          $data['path_second'] = "Add Schools";
          
          $data['url_first']   = "home";
          $data['url_second']  = "add-schools";
          
          $this->load->view('school/add', $data);	  
    	}

	}
 function email_check($str, $val)
    {
      $data['email']=$str;
      // set error message
        $this->form_validation->set_message('email_check', 'Email already Exist');
      return ($this->school_model->checkemailunquie($data,$val));
    }
  public function edit($id){

      if($_SERVER['REQUEST_METHOD'] == 'POST'){
        
        $this->form_validation->set_rules('name', 'Name', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|callback_email_check['.$id.']');
        $this->form_validation->set_rules('address', 'Address', 'required');
        $this->form_validation->set_rules('contact', 'Contact No', 'required');
        $this->form_validation->set_rules('principal', 'Principal Name', 'required');
        $this->form_validation->set_rules('manager', 'Manager', 'required');
        
        $this->form_validation->set_rules('country', 'Country', 'required');
        $this->form_validation->set_rules('state', 'State', 'required');
        $this->form_validation->set_rules('city', 'City', 'required');
       
        if ($this->form_validation->run() == true){ 
          
          
          $name         = $this->input->post('name');
          $email        = $this->input->post('email');
          $address      = $this->input->post('address');
          $contact      = $this->input->post('contact');
          $principal    = $this->input->post('principal');
          $manager      = $this->input->post('manager');
          $country      = $this->input->post('country');
          $state        = $this->input->post('state');
          $city         = $this->input->post('city');
          $datetime     = $this->defualt_date_time(); 
          $user_id      = $this->session->userdata('id');
          $role         = $this->session->userdata('role');
          $role_id      = base64_decode($role);
            
          $schoolData = array(      
                                    'user_id'        => $user_id, 
                                    'role_id'        => $role_id, 
                                    'name'           => $name, 
                                    'email'          => $email, 
                                    'address'        => $address, 
                                    'contact'        => $contact, 
                                    'principal'      => $principal, 
                                    'manager'        => $manager,
                                    'city'           => $city,
                                    'state'          => $state,
                                    'country'        => $country,
                                    'updated_date'   => $datetime  );
            
          if($this->school_model->save($schoolData,$id)){
          
          $this->session->set_flashdata('success', 'Update School Successfully');
          redirect('schools');

          }else{

          $this->session->set_flashdata('error', 'School Not Updated, try Again');
          redirect('update-schools/'.$id);

          }

        }else{
            
          
          $data['name']         = $this->input->post('name');
          $data['email']        = $this->input->post('email');
          $data['address']      = $this->input->post('address');
          $data['contact']      = $this->input->post('contact');
          $data['principal']    = $this->input->post('principal');
          $data['manager']      = $this->input->post('manager');
          $data['country']      = $this->input->post('country');
          $data['state']        = $this->input->post('state');
          $data['city']         = $this->input->post('city');
          
          $data['page_title']  = "Update Schools";

          $data['path_first']  = "Home";
          $data['path_second'] = "Update Schools";
          
          $data['url_first']   = "home";
          $data['url_second']  = "update-schools/".$id;
          
          $this->load->view('school/edit', $data);       
          
        }  

      }else{
        $school=$this->school_model->getinfo($id);
          if($school){
            $data['name']         = $school->name;
            $data['email']        = $school->email;
            $data['address']      = $school->address;
            $data['contact']      = $school->contact;
            $data['principal']    = $school->principal;
            $data['manager']      = $school->manager;
            $data['country']      = $school->country;
            $data['state']        = $school->state;
            $data['city']         = $school->city;
            
          }
          
          $data['success']     = $this->session->userdata('success');    
          $data['error']       = $this->session->userdata('error');    
          $data['page_title']  = "Update Schools";

          $data['path_first']  = "Home";
          $data['path_second'] = "Update Schools";
          
          $data['url_first']   = "home";
          $data['url_second']  = "update-schools/".$id;
          
          $this->load->view('school/edit', $data);   
      }

  }




}	
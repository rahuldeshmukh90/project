<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once ('Auth_access.php');

class Type extends Auth_access {


	public function index(){
        
        if (!$this->authentication->is_logged_in()){
		 
		   redirect('login');
		   exit();
        
        }else{
           
           $data['success'] = $this->session->userdata('success');    
           $data['error']   = $this->session->userdata('error');

           $data['type']    = $this->type_model->getall();   

           $data['path_first']  = "Home";
           $data['path_second'] = "Type";
          
           $data['url_first']   = "home";
           $data['url_second']  = "type";

           $data['page_title']  = "Type";
           
           $this->load->view('type/list', $data);	  

        }

	}

	public function defualt_date_time(){
        
        date_default_timezone_set('Asia/Kolkata');
        return date('Y-m-d H:i:a');
    }
    
    public function add(){

    	if($_SERVER['REQUEST_METHOD'] == 'POST'){
    		
        $this->form_validation->set_rules('category_id', 'Category', 'required');
        $this->form_validation->set_rules('name', 'Name', 'required');
        
            
        if ($this->form_validation->run() == true){ 
          
    	  $category_id     = $this->input->post('category_id');
    	  $name            = $this->input->post('name');
    	  $datetime        =  $this->defualt_date_time(); 
          $user_id         = $this->session->userdata('id');
          $role            = $this->session->userdata('role');
          $role_id         = base64_decode($role);
          
        $typeData = array(   
                              'user_id'       => $user_id, 
                              'role_id'       => $role_id, 
                              'name'          => $category, 
      	                      'category_id'   => $category_id, 
      	                      'create_date'   => $datetime, 
      	                      'update_date'   => $datetime  );
          
        if($this->type_model->save($typeData) == true){
    	  
    	  $this->session->set_flashdata('success', 'Add Type Successfully');
    	  redirect('type');

    	  }else{

        $this->session->set_flashdata('error', 'Type Not Added, try Again');
    	  redirect('add-type');

    	  }

    	}else{
          
          $data['category_id']     = ($this->input->post('category_id'))?$this->input->post('category_id'):'';
          $data['name'] = ($this->input->post('name'))?$this->input->post('name'):'';
          
          $data['page_title']   = "Add Type";
          $this->load->view('type/add', $data);	      
    	}  

    	}else{
          
          $data['success']     = $this->session->userdata('success');    
          $data['error']       = $this->session->userdata('error');    
          $data['page_title']  = "Add Type";

          $data['path_first']  = "Home";
          $data['path_second'] = "Add Type";
          
          $data['url_first']   = "home";
          $data['url_second']  = "add-type";
          
          $this->load->view('type/add', $data);	  
    	}

	}
}	
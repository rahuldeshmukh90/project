<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once ('Auth_access.php');

class users extends Auth_access {


	public function index(){
        
        if (!$this->authentication->is_logged_in()){
		 
		   redirect('login');
		   exit();
        
        }else{
           
           $data['success'] = $this->session->userdata('success');    
           $data['error']   = $this->session->userdata('error');

           $data['user']    = $this->user_model->getadminuser();   

           $data['path_first']  = "Home";
           $data['path_second'] = "Admin List";
          
           $data['url_first']   = "home";
           $data['url_second']  = "users";

           $data['page_title']  = "Users";
           
           $this->load->view('user/list', $data);	  

        }

	}

	public function defualt_date_time(){
        
        date_default_timezone_set('Asia/Kolkata');
        return date('Y-m-d H:i:a');
    }
    
    public function add(){

    	if($_SERVER['REQUEST_METHOD'] == 'POST'){
    		
        $this->form_validation->set_rules('fname', 'First Name', 'required');
        $this->form_validation->set_rules('lname', 'Last Name', 'required');
        $this->form_validation->set_rules('email', 'Email ID', 'required|valid_email');
        $this->form_validation->set_rules('contact', 'Contact No', 'required|integer|min_length[10]|max_length[10]');
        $this->form_validation->set_rules('company', 'Company', 'required|is_unique[be_owner.company]');
        $this->form_validation->set_rules('address', 'Address', 'required');
        $this->form_validation->set_rules('username', 'username', 'required|is_unique[be_owner.username]');
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[4]');
        $this->form_validation->set_rules('confirm_password', 'Confirm Password', 'required|matches[password]');
        $this->form_validation->set_rules('user_type', 'User Type', 'required');    
        if ($this->form_validation->run() == true){ 
          
      	  $fname      = ($this->input->post('fname'))?$this->input->post('fname'):'';
          $lname      = ($this->input->post('lname'))?$this->input->post('lname'):'';
          $email      = ($this->input->post('email'))?$this->input->post('email'):'';
          $contact    = ($this->input->post('contact'))?$this->input->post('contact'):'';
          $company    = ($this->input->post('company'))?$this->input->post('company'):'';
          $address    = ($this->input->post('address'))?$this->input->post('address'):'';
      	  $username   = ($this->input->post('username'))?$this->input->post('username'):'';
      	  $password   = ($this->input->post('password'))? md5($this->input->post('password')):'';
          $user_type  = ($this->input->post('user_type'))?$this->input->post('user_type'):'';
          $datetime   =  $this->defualt_date_time(); 
          
          
          $categoryData = array(    
                                    'role_id'      => $user_type, 
                                    'fname'        => $fname, 
            	                      'lname'        => $lname, 
                                    'email'        => $email, 
                                    'contact'      => $contact, 
                                    'company'      => $company, 
                                    'address'      => $address, 
                                    'username'     => $username, 
                                    'password'     => $password, 
                                    'group_id'     => $user_type, 
            	                      'created_date' => $datetime, 
            	                      'updated_date' => $datetime  );
            
          if($this->user_model->save($categoryData) == true){
      	  
      	  $this->session->set_flashdata('success', 'Add Admin Successfully');
      	  redirect('users');

      	  }else{

          $this->session->set_flashdata('error', 'Admin Not Added, try Again');
      	  redirect('add-users');

      	  }

      	}else{
            
          $data['fname']      = ($this->input->post('fname'))?$this->input->post('fname'):'';
          $data['lname']      = ($this->input->post('lname'))?$this->input->post('lname'):'';
          $data['email']      = ($this->input->post('email'))?$this->input->post('email'):'';
          $data['contact']    = ($this->input->post('contact'))?$this->input->post('contact'):'';
      	  $data['username']   = ($this->input->post('username'))?$this->input->post('username'):'';
          $data['company']    = ($this->input->post('company'))?$this->input->post('company'):'';
          $data['address']    = ($this->input->post('address'))?$this->input->post('address'):'';
      	 
          $data['user_type']  = ($this->input->post('user_type'))?$this->input->post('user_type'):'';
          
          $data['page_title']  = "Add Admin";

          $data['path_first']  = "Home";
          $data['path_second'] = "Add Admin";
          
          $data['url_first']   = "home";
          $data['url_second']  = "add-users";
            $this->load->view('user/add', $data);	      
      	}  

    	}else{
          
          $data['success']     = $this->session->userdata('success');    
          $data['error']       = $this->session->userdata('error');    
          $data['page_title']  = "Add Admin";

          $data['path_first']  = "Home";
          $data['path_second'] = "Add Admin";
          
          $data['url_first']   = "home";
          $data['url_second']  = "add-users";
          
          $this->load->view('user/add', $data);	  
    	}

	  }
    public function profile(){
      
      if (!$this->authentication->is_logged_in()){
      
        redirect('login');
        exit();
        
      }else{

         $id = $this->authentication->get_login_id();
       
         if($_SERVER['REQUEST_METHOD'] == 'POST'){
          
          $this->form_validation->set_rules('fname', 'First Name', 'required');
          $this->form_validation->set_rules('lname', 'Last Name', 'required');
          $this->form_validation->set_rules('email', 'Email ID', 'required|valid_email');
          $this->form_validation->set_rules('contact', 'Contact No', 'required|integer|min_length[10]|max_length[10]');

          $this->form_validation->set_rules('company', 'Company', 'required');
          $this->form_validation->set_rules('address', 'Address', 'required');

          if ($this->form_validation->run() == true){ 
           // echo 'dfdgdfgfg';die;
            $fname      = ($this->input->post('fname'))?$this->input->post('fname'):'';
            $lname      = ($this->input->post('lname'))?$this->input->post('lname'):'';
            $email      = ($this->input->post('email'))?$this->input->post('email'):'';
            $contact    = ($this->input->post('contact'))?$this->input->post('contact'):'';
            $company    = ($this->input->post('company'))?$this->input->post('company'):'';
            $address    = ($this->input->post('contact'))?$this->input->post('address'):'';
            $datetime   =  $this->defualt_date_time(); 
            
            
            $categoryData = array(    
                                  'fname'        => $fname, 
                                  'lname'        => $lname, 
                                  'email'        => $email, 
                                  'contact'      => $contact, 
                                  'company'      => $company, 
                                  'address'      => $address, 
                                  'updated_date' => $datetime  
                                );
              
            if($this->user_model->save($categoryData,$id)){
            
            $this->session->set_flashdata('success', 'Update profile Successfully');
            redirect('profile');

            }else{

            $this->session->set_flashdata('error', 'Profile Not Updated, try Again');
            redirect('profile');

            }

          }else{
              
            $data['fname']       = $this->input->post('fname');
            $data['lname']       = $this->input->post('lname');
            $data['email']       = $this->input->post('email');
            $data['contact']     = $this->input->post('contact');
            $data['company']     = $this->input->post('company');
            $data['address']     = $this->input->post('address');
            $data['page_title']  = "Update Profile";

            $data['path_first']  = "Home";
            $data['path_second'] = "Update Profile";
            
            $data['url_first']   = "home";
            $data['url_second']  = "profile";
            $this->load->view('user/profile', $data);       
          }  

        }else{

            $data['user'] = $this->user_model->getuserinfo($id);
            
            $data['success']     = $this->session->userdata('success');    
            $data['error']       = $this->session->userdata('error');    
            $data['page_title']  = "Profile";

            $data['path_first']  = "Home";
            $data['path_second'] = "Profile";
            
            $data['url_first']   = "home";
            $data['url_second']  = "profile";
            
            $this->load->view('user/profile', $data);   
        }

      }
    }
    function oldpassword_check($str, $val)
    {
      $data['password']=md5($str);
      // set error message
        $this->form_validation->set_message('oldpassword_check', 'Old password not match');
      return ($this->user_model->oldpassword_check($data,$val));
    }
    public function changepassword(){
      if (!$this->authentication->is_logged_in()){
        redirect('login');
        exit();
        
      }else{
        $id=$this->authentication->get_login_id();
       
         if($_SERVER['REQUEST_METHOD'] == 'POST'){
           $this->form_validation->set_rules('oldpassword', 'oldpassword', 'required|min_length[4]|callback_oldpassword_check['.$id.']');
           $this->form_validation->set_rules('newpassword', 'newpassword', 'required|min_length[3]');
          $this->form_validation->set_rules('confirm_password', 'Confirm Password', 'required|matches[newpassword]');


          if ($this->form_validation->run() == true){ 
           // echo 'dfdgdfgfg';die;
            $password      = md5($this->input->post('newpassword'));
           
            $datetime   =  $this->defualt_date_time(); 
            
            
            $categoryData = array(    
                                  'password'        => $password, 
                                  'updated_date' => $datetime  
                                );
              
            if($this->user_model->save($categoryData,$id)){
            
            $this->session->set_flashdata('success', 'Change password Successfully');
            redirect('change-password');

            }else{

            $this->session->set_flashdata('error', 'password Not Changed, try Again');
            redirect('change-password');

            }

          }

        }

            $data['success']     = $this->session->userdata('success');    
            $data['error']       = $this->session->userdata('error');    
            $data['page_title']  = "Change Password";

            $data['path_first']  = "Home";
            $data['path_second'] = "Change Password";
            
            $data['url_first']   = "home";
            $data['url_second']  = "change-password";
            
            $this->load->view('user/password', $data);   
        

      }
    }
    function username_check($str, $val)
    {
      $data['username']=$str;
      // set error message
        $this->form_validation->set_message('username_check', 'Username Already Exist..');
      return ($this->user_model->checkuserunquie($data,$val));
    }

    public function checkOldPassword($pass='', $id=''){
        
        $Query    = $this->db->get_where('be_owner', array('id' => $id, 'password' => md5($pass) ));
        //$Query->num_rows(); die;
        if($Query->num_rows() =='1')
        {
            return true;

        }else{
             if($pass !=''){ 
                
                $this->form_validation->set_message('checkOldPassword', 'wrong old password.');
                return false;

             }else{
                
                return true; 
             }
            
        }
      }

    public function edit($id)
    {

      if($_SERVER['REQUEST_METHOD'] == 'POST'){
        
        $this->form_validation->set_rules('fname', 'First Name', 'required');
        $this->form_validation->set_rules('lname', 'Last Name', 'required');
        $this->form_validation->set_rules('email', 'Email ID', 'required|valid_email');
        $this->form_validation->set_rules('contact', 'Contact No', 'required|integer|min_length[10]|max_length[10]');
        $this->form_validation->set_rules('username', 'username', 'required|callback_username_check['.$id.']');
        $this->form_validation->set_rules('user_type', 'User Type', 'required');    
        $this->form_validation->set_rules('company', 'Company Name', 'required');
        $this->form_validation->set_rules('address', 'Address', 'required');
        // Check old Pass and Matched 
        //$this->form_validation->set_rules('opass','Old Password','trim|min_length[3]|max_length[30]|callback_checkOldPassword['.$id.']');
        
        $this->form_validation->set_rules('pass', 'Password', 'min_length[3]');
        $this->form_validation->set_rules('cpass', 'Confirm Password', 'matches[pass]');

        if ($this->form_validation->run() == true){ 
         
          $fname      = ($this->input->post('fname'))?$this->input->post('fname'):'';
          $lname      = ($this->input->post('lname'))?$this->input->post('lname'):'';
          $email      = ($this->input->post('email'))?$this->input->post('email'):'';
          $contact    = ($this->input->post('contact'))?$this->input->post('contact'):'';
          $username   = ($this->input->post('username'))?$this->input->post('username'):'';
          $user_type  = ($this->input->post('user_type'))?$this->input->post('user_type'):'';
          $company    = ($this->input->post('user_type'))?$this->input->post('company'):'';
          $address    = ($this->input->post('address'))?$this->input->post('address'):'';
          $datetime   =  $this->defualt_date_time(); 
          $password   = ($this->input->post('pass'))?$this->input->post('pass'):'';
          
          

          $userdata = array(    
                                    'role_id'      => $user_type, 
                                    'fname'        => $fname, 
                                    'lname'        => $lname, 
                                    'email'        => $email, 
                                    'contact'      => $contact, 
                                    'company'      => $company, 
                                    'address'      => $address, 
                                    'username'     => $username, 
                                    'group_id'     => $user_type, 
                                    'created_date' => $datetime, 
                                    'updated_date' => $datetime  );
          
          
          if($this->user_model->save($userdata,$id)){
          if(!empty($password)) { 

            $userPassword = array('password' => md5($password) ); 
            $this->user_model->save($userPassword, $id);

          }
          
          
          $this->session->set_flashdata('success', 'Update Admin Successfully');
          redirect('users');

          }else{

          $this->session->set_flashdata('error', 'Admin Not Updated, try Again');
          redirect('update-users/'.$id);

          }

        }else{
            
          $data['fname']      = ($this->input->post('fname'))?$this->input->post('fname'):'';
          $data['lname']      = ($this->input->post('lname'))?$this->input->post('lname'):'';
          $data['email']      = ($this->input->post('email'))?$this->input->post('email'):'';
          $data['contact']    = ($this->input->post('contact'))?$this->input->post('contact'):'';
          $data['username']   = ($this->input->post('username'))?$this->input->post('username'):'';
          $data['company']    = ($this->input->post('company'))?$this->input->post('company'):'';
          $data['address']    = ($this->input->post('address'))?$this->input->post('address'):'';
         
          $data['user_type']  = ($this->input->post('user_type'))?$this->input->post('user_type'):'';
          
          $data['page_title']  = "Update Admin";

          $data['path_first']  = "Home";
          $data['path_second'] = "Update Admin";
          
          $data['url_first']   = "home";
          $data['url_second']  = "update-users/".$id;
            $this->load->view('user/edit', $data);       
        }  

      }else{

        $user=$this->user_model->getuserinfo($id);
          if($user){
           
            $data['fname']      = $user->fname;
            $data['lname']      = $user->lname;
            $data['email']      = $user->email;
            $data['contact']    = $user->contact;
            $data['username']   = $user->username;
            $data['user_type']  = $user->role_id;   
            $data['company']    = $user->company;   
            $data['address']    = $user->address;   

          }

          $data['success']     = $this->session->userdata('success');    
          $data['error']       = $this->session->userdata('error');    
          $data['page_title']  = "Update Admin";

          $data['path_first']  = "Home";
          $data['path_second'] = "Update Admin";
          
          $data['url_first']   = "home";
          $data['url_second']  = "update-users/".$id;
          
          $this->load->view('user/edit', $data);   
      }

    }
  function blockuser($user_id)
  {
    if($user_id)
    {
      $data=array('active_status' =>'0');
      if($this->user_model->save($data,$user_id))
      {
        echo '1';die;
      }
      else
      {
        echo '';die;
      }
    }
  }
  function activeuser($user_id)
  {
    if($user_id)
    {
      $data=array('active_status' =>'1');
      if($this->user_model->save($data,$user_id))
      {
        echo '1';die;
      }
      else
      {
        echo '';die;
      }
    }
  }

   function register_email_exists()
    {
      echo true;
   } 
}	
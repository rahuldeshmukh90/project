<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once ('Auth_access.php');

class Vendor extends Auth_access {


	public function index(){
        
        if (!$this->authentication->is_logged_in()){
		 
		   redirect('login');
		   exit();
        
        }else{
           
           $data['success'] = $this->session->userdata('success');    
           $data['error']   = $this->session->userdata('error');

           $data['vendor']    = $this->vendor_model->getvendor();   

           $data['path_first']  = "Home";
           $data['path_second'] = "Vendor";
          
           $data['url_first']   = "home";
           $data['url_second']  = "vendor";

           $data['page_title']  = "Vendor";
           
           $this->load->view('vendor/list', $data);	  

        }

	}

	  public function defualt_date_time(){
        
        date_default_timezone_set('Asia/Kolkata');
        return date('Y-m-d H:i:a');
    }
    public function deletevendor($id){
    if($id)
    {
        if($this->vendor_model->deletevendor($id))
        {
          $this->session->set_flashdata('success', 'Vendor Successfully deleted');
        } 
        else
        {
          $this->session->set_flashdata('error', 'Vendor Not deleted, Some error occure..');
          
        }
        redirect('vendor');
    }
  }
    
    public function add(){

    	if($_SERVER['REQUEST_METHOD'] == 'POST'){
    		
        $this->form_validation->set_rules('name', 'Full Name', 'required');
        $this->form_validation->set_rules('contact', 'Mobile Number', 'required|integer|min_length[10]|max_length[10]');
        $this->form_validation->set_rules('service', 'Service', 'required');
        // $this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[vendor.email]');
        $this->form_validation->set_rules('email', 'Email', 'required');
        $this->form_validation->set_rules('address', 'Address', 'required');
        
        if ($this->form_validation->run() == true){ 
          
          $name      = ($this->input->post('name'))?$this->input->post('name'):'';
      	  $contact   = ($this->input->post('contact'))?$this->input->post('contact'):'';
          $email     = ($this->input->post('email'))?$this->input->post('email'):'';
          $service   = ($this->input->post('service'))?$this->input->post('service'):''; 
          $address   = ($this->input->post('address'))?$this->input->post('address'):'';
          $datetime  =  $this->defualt_date_time(); 
          $user_id   = $this->session->userdata('id');
          $role      = $this->session->userdata('role');
          $role_id   = base64_decode($role);
          
          $vendordata = array(    
                                   'user_id'        => $user_id, 
                                   'role_id'        => $role_id, 
                                   'name'           => $name, 
            	                   'contact'        => $contact, 
            	                   'service'        => $service, 
                                   'email'          => $email, 
                                   'address'        => $address, 
            	                   'created_date'   => $datetime,
            	                   'updated_date'   => $datetime  );
            
          if($this->vendor_model->save($vendordata) == true){
      	  
      	  $this->session->set_flashdata('success', 'Add Vendor Successfully');
      	  redirect('vendor');

      	  }else{

          $this->session->set_flashdata('error', 'Vendor Not Added, try Again');
      	  redirect('add-vendor');

      	  }

      	}else{
            
          $data['name']      = ($this->input->post('name'))?$this->input->post('name'):'';
      	  $data['contact']   = ($this->input->post('contact'))?$this->input->post('contact'):'';
          $data['email']     = ($this->input->post('email'))?$this->input->post('name'):'';
          $data['service']   = ($this->input->post('service'))?$this->input->post('service'):''; 
          $data['address']   = ($this->input->post('address'))?$this->input->post('address'):'';
          
          $data['page_title']  = "Add Vendor";

          $data['path_first']  = "Home";
          $data['path_second'] = "Add Vendor";
          
          $data['url_first']   = "home";
          $data['url_second']  = "add-vendor";
            $this->load->view('vendor/add', $data);	      
      	}  

    	}else{
          
          $data['success']     = $this->session->userdata('success');    
          $data['error']       = $this->session->userdata('error');    
          $data['page_title']  = "Add Vendor";

          $data['path_first']  = "Home";
          $data['path_second'] = "Add Vendor";
          
          $data['url_first']   = "home";
          $data['url_second']  = "add-vendor";
          
          $this->load->view('vendor/add', $data);	  
    	}

	}
  function email_check($str, $val)
    {
      $data['email']=$str;
      // set error message
        $this->form_validation->set_message('username_check', 'email Already Exist..');
      return ($this->vendor_model->checkemailunquie($data,$val));
    }
  public function edit($id){

      if($_SERVER['REQUEST_METHOD'] == 'POST'){
        
        $this->form_validation->set_rules('name', 'Full Name', 'required');
        $this->form_validation->set_rules('contact', 'Mobile Number', 'required|integer|min_length[10]|max_length[10]');
        $this->form_validation->set_rules('service', 'Service', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email|callback_email_check['.$id.']');
        $this->form_validation->set_rules('address', 'Address', 'required');
        
        if ($this->form_validation->run() == true){ 
          
          $name      = $this->input->post('name');
          $contact   = $this->input->post('contact');
          $email     = $this->input->post('email');
          $service   = $this->input->post('service'); 
          $address   = $this->input->post('address');
          $datetime  =  $this->defualt_date_time(); 
          $user_id   = $this->session->userdata('id');
          $role      = $this->session->userdata('role');
          $role_id   = base64_decode($role);
          
          $vendordata = array(    
                                'user_id'        => $user_id, 
                                'role_id'        => $role_id, 
                                'name'           => $name, 
                                'contact'        => $contact, 
                                'service'        => $service, 
                                'email'          => $email, 
                                'address'        => $address, 
                                'updated_date'   => $datetime  
                              );
            
          if($this->vendor_model->save($vendordata,$id)){
          
          $this->session->set_flashdata('success', 'Update Vendor Successfully');
          redirect('vendor');

          }else{

          $this->session->set_flashdata('error', 'Vendor Not Updated, try Again');
          redirect('update-vendor/'.$id);

          }

        }else{
            
          $data['name']      = $this->input->post('name');
          $data['contact']   = $this->input->post('contact');
          $data['email']     = $this->input->post('email');
          $data['service']   = $this->input->post('service'); 
          $data['address']   = $this->input->post('address');
          
          $data['page_title']  = "Update Vendor";

          $data['path_first']  = "Home";
          $data['path_second'] = "Update Vendor";
          
          $data['url_first']   = "home";
          $data['url_second']  = "update-vendor/".$id;
          $this->load->view('vendor/edit', $data);       
        }  

      }else{
          $vendor =$this->vendor_model->getVenderinfo($id);
          if($vendor)
          {
            $data['name']      = $vendor->name;
            $data['contact']   = $vendor->contact;
            $data['email']     = $vendor->email;
            $data['service']   = $vendor->service; 
            $data['address']   = $vendor->address;
          
          }
          
          $data['success']     = $this->session->userdata('success');    
          $data['error']       = $this->session->userdata('error');    
          $data['page_title']  = "Update Vendor";

          $data['path_first']  = "Home";
          $data['path_second'] = "Update Vendor";
          
          $data['url_first']   = "home";
          $data['url_second']  = "update-vendor/".$id;
          
          $this->load->view('vendor/edit', $data);   
      }

  }

  /*============= ASSIGN VENDOR TO SCHOOL ===========*/
  
  public function assign_school(){
      
     
     if($_SERVER['REQUEST_METHOD'] == 'POST'){
        
        $this->form_validation->set_rules('school', 'School', 'required');
        $this->form_validation->set_rules('vendor', 'Vendor', 'required');
        
        if ($this->form_validation->run() == true){ 
          
          $school       = ($this->input->post('school'))?$this->input->post('school'):'';
          $vendor       = ($this->input->post('form_text'))?$this->input->post('form_text'):'';

          $vendor_id    = base64_decode($vendor);
          $datetime     = $this->defualt_date_time(); 
          
          $dataVendor   = $this->vendor_model->getVenderinfo($vendor_id);
          
          $user_id      = $dataVendor->user_id; 
          $role_id      = $dataVendor->role_id; 
          $is_company   = $this->session->userdata('id');
          // $role         = $this->session->userdata('role');
          // $role_id      = base64_decode($role);
            
          $Assigndata = array(    
                                   'user_id'        => $user_id, 
                                   'role_id'        => $role_id, 
                                   'is_company'     => $is_company, 
                                   'school_id'      => $school, 
                                   'vendor_id'      => $vendor_id, 
                                   'created_date'   => $datetime, 
                                   'updated_date'   => $datetime  );
            
          if($this->vendor_model->save_assign_school($Assigndata) == true){
          
          $this->session->set_flashdata('success', 'Assign School Successfully');
          // redirect('assign-school');
          redirect('assign-list');

          }else{

          $this->session->set_flashdata('error', 'School Not Assigned, try Again');
          //redirect('assign');
          redirect('assign-list');

          }

        }else{
           
          $vendor              = $this->input->post('form_text');
          $vendor_id           = base64_decode($vendor);
          $data['schl']        = $this->school_model->getinfo(base64_decode($this->input->post('form_text')));
          $data['vendor']      = $this->vendor_model->getVenderinfo($vendor_id);

          $data['form_text']   = $this->input->post('form_text');  
          $data['page_title']  = "Assign School";

          $data['path_first']  = "Home";
          $data['path_second'] = "Assign School";
          
          $data['url_first']   = "home";
          $data['url_second']  = "assign-school";

          $this->load->view('vendor/assign_school', $data);   
          
        }  

      }else{
          
          if($this->input->get('text')){ 

          $vender = $this->input->get('text'); $vendor_id = base64_decode($vender); 
          
          $data['success']     = $this->session->userdata('success');    
          $data['error']       = $this->session->userdata('error');   
          $data['vendorid']    = '';

          $data['vendor']      = $this->vendor_model->getVenderinfo($vendor_id);
          $data['form_text']   = $vender;
          $data['page_title']  = "Assign School";

          $data['path_first']  = "Home";
          $data['path_second'] = "Assign School";
          
          $data['url_first']   = "home";
          $data['url_second']  = "assign-school";
          
          $this->load->view('vendor/assign_school', $data);    

          }else{
          redirect('vendor');  
          }
      }
  }

  	/*=============ASSIGN VENDOR TO SERVICES===========*/
	
	public function assign_list(){
	    
	       $data['success'] = $this->session->userdata('success');    
           $data['error']   = $this->session->userdata('error');

           $data['service']    = $this->vendor_model->getSchoolAssigni();   

           $data['path_first']  = "Home";
           $data['path_second'] = "Assign School";
          
           $data['url_first']   = "home";
           $data['url_second']  = "assign-school";

           $data['page_title']  = "Assign School";
           
           $this->load->view('vendor/assign_list', $data);
           
	}

	/*===============REMOVE ASSIGN SCHOOL==============*/

	public function remove_assign_school(){

        if($this->input->get('remove')){ $asg_id = $this->input->get('remove'); 
        $id = base64_decode($asg_id); 
        if($this->vendor_model->remove_assign($id) == true ){
        
        $this->session->set_flashdata('success', 'Assign Delete Successfully');
        redirect('assign-list');

        }else{

        $this->session->set_flashdata('error', 'Assign Delete Successfully');
        redirect('assign-list');

        }   
        }else{
        redirect('assign-list'); 
        }
	}
}	